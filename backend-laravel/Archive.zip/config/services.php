<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Resend, Postmark, AWS, and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'key' => env('POSTMARK_API_KEY'),
    ],

    'resend' => [
        'key' => env('RESEND_API_KEY'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    'geolocation' => [
        'enabled' => env('GEOLOCATION_ENABLED', true),
        'driver' => env('GEOLOCATION_DRIVER', 'ip-api'),
        'api_key' => env('GEOLOCATION_API_KEY', null),
        'endpoint' => env('GEOLOCATION_ENDPOINT', null),
        'cache_ttl' => (int) env('GEOLOCATION_CACHE_TTL', 86400),
        'timeout' => (int) env('GEOLOCATION_TIMEOUT', 3),
    ],

    'google_analytics' => [
        'id' => env('GOOGLE_ANALYTICS_ID', env('GA_MEASUREMENT_ID')),
    ],

    /*
    | SSLCOMMERZ hosted checkout. Values saved from the admin panel (encrypted
    | in the database) take precedence; these env values are the fallback.
    | SSLCOMMERZ_ENABLED=false acts as a server-level kill switch.
    */
    'sslcommerz' => [
        'enabled' => env('SSLCOMMERZ_ENABLED', true),
        'store_id' => env('SSLCOMMERZ_STORE_ID'),
        'store_password' => env('SSLCOMMERZ_STORE_PASSWORD'),
        'sandbox' => env('SSLCOMMERZ_SANDBOX', true),
        'currency' => env('SSLCOMMERZ_CURRENCY', 'BDT'),
        'timeout' => (int) env('SSLCOMMERZ_TIMEOUT', 30),
        'sandbox_url' => 'https://sandbox.sslcommerz.com',
        'live_url' => 'https://securepay.sslcommerz.com',
    ],

    'payment_settings' => [
        'unlock_pin' => env('PAYMENT_SETTINGS_UNLOCK_PIN'),
        'unlock_minutes' => (int) env('PAYMENT_SETTINGS_UNLOCK_MINUTES', 10),
    ],

];
