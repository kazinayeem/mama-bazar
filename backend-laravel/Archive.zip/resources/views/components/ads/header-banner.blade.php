{{-- Header Responsive Ad Banner --}}
<div class="ad-banner-header w-full overflow-hidden flex justify-center items-center py-1 sm:py-2 bg-slate-50/50 border-b border-brand-green-50">
    <div class="store-container flex justify-center items-center overflow-hidden">
        {{-- Desktop: 728x90 --}}
        <div class="hidden lg:flex justify-center items-center min-h-[90px] w-[728px] max-w-full overflow-hidden">
            <script>
                atOptions = {
                    'key' : '6a9de319fbb456fc0b67501d4e53f6be',
                    'format' : 'iframe',
                    'height' : 90,
                    'width' : 728,
                    'params' : {}
                };
            </script>
            <script src="https://bicea.org/22/6a9de319fbb456fc0b67501d4e53f6be"></script>
        </div>

        {{-- Tablet: 468x60 --}}
        <div class="hidden sm:flex lg:hidden justify-center items-center min-h-[60px] w-[468px] max-w-full overflow-hidden">
            <script>
                atOptions = {
                    'key' : '70a61910a4e9ead809bab62f298837af',
                    'format' : 'iframe',
                    'height' : 60,
                    'width' : 468,
                    'params' : {}
                };
            </script>
            <script src="https://bicea.org/22/70a61910a4e9ead809bab62f298837af"></script>
        </div>

        {{-- Mobile: 320x50 --}}
        <div class="flex sm:hidden justify-center items-center min-h-[50px] w-[320px] max-w-full overflow-hidden">
            <script>
                atOptions = {
                    'key' : 'a6e2c4bc4192ba4bcbaf54d2554192cc',
                    'format' : 'iframe',
                    'height' : 50,
                    'width' : 320,
                    'params' : {}
                };
            </script>
            <script src="https://bicea.org/22/a6e2c4bc4192ba4bcbaf54d2554192cc"></script>
        </div>
    </div>
</div>
