{{-- Footer Responsive Ad Unit --}}
<div class="store-container my-6 sm:my-8 overflow-hidden">
    <div class="flex flex-col items-center justify-center gap-2 rounded-xl border border-slate-100 bg-white p-3 shadow-xs">
        <span class="text-[10px] uppercase font-bold tracking-wider text-slate-400">Sponsored</span>
        
        {{-- Desktop: 728x90 --}}
        <div class="hidden sm:flex justify-center items-center min-h-[90px] w-[728px] max-w-full overflow-hidden">
            <script>
                atOptions = {
                    'key' : '6a9de319fbb456fc0b67501d4e53f6be',
                    'format' : 'iframe',
                    'height' : 90,
                    'width' : 728,
                    'params' : {}
                };
            </script>
            <script src="https://bicea.org/22/6a9de319fbb456fc0b67501d4e53f6be"></script>
        </div>

        {{-- Mobile: 320x50 --}}
        <div class="flex sm:hidden justify-center items-center min-h-[50px] w-[320px] max-w-full overflow-hidden">
            <script>
                atOptions = {
                    'key' : 'a6e2c4bc4192ba4bcbaf54d2554192cc',
                    'format' : 'iframe',
                    'height' : 50,
                    'width' : 320,
                    'params' : {}
                };
            </script>
            <script src="https://bicea.org/22/a6e2c4bc4192ba4bcbaf54d2554192cc"></script>
        </div>
    </div>
</div>
