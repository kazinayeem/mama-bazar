{{-- Native Ad Banner Container --}}
<div class="store-container my-4 sm:my-6 overflow-hidden">
    <div class="rounded-xl border border-slate-100 bg-white p-2.5 sm:p-4 shadow-xs overflow-hidden">
        <div id="container-162c2f578ce2b6f885153aff22251529" class="w-full max-w-full overflow-hidden flex justify-center"></div>
    </div>
</div>
