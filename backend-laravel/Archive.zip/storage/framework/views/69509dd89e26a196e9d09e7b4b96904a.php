<?php $__env->startSection('content'); ?>
<div class="admin-page max-w-5xl">
    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Email Automation','subtitle' => 'Choose which events send emails automatically. Every email is queued after the database commit, so checkout never waits on SMTP.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Email Automation','subtitle' => 'Choose which events send emails automatically. Every email is queued after the database commit, so checkout never waits on SMTP.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
    <?php echo $__env->make('admin.email.partials.tabs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php if (! ($settings['mail_enabled'])): ?>
        <div class="rounded-[8px] border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800">Outgoing email is disabled in SMTP Settings — these rules have no effect until it is enabled.</div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.email.automation.update')); ?>" method="POST" class="space-y-4">
        <?php echo csrf_field(); ?>
        <div class="grid gap-4 md:grid-cols-2">
            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="admin-surface p-5 space-y-3">
                    <h2 class="text-sm font-bold text-slate-900"><?php echo e($group); ?></h2>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="flex items-start gap-3 rounded-[6px] p-2 hover:bg-slate-50 cursor-pointer">
                            <input type="checkbox" name="<?php echo e($item['key']); ?>" value="1" <?php if($item['enabled']): echo 'checked'; endif; ?> class="mt-0.5 rounded border-slate-300 text-brand-green-600">
                            <span class="text-xs">
                                <span class="block font-semibold text-slate-800"><?php echo e($item['label']); ?></span>
                                <span class="text-slate-500"><?php echo e($item['description']); ?></span>
                            </span>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="admin-surface p-5 space-y-3">
            <h2 class="text-sm font-bold text-slate-900">Account policies</h2>
            <label class="flex items-start gap-3 text-xs cursor-pointer">
                <input type="checkbox" name="email_require_registration_email" value="1" <?php if($settings['email_require_registration_email']): echo 'checked'; endif; ?> class="mt-0.5 rounded border-slate-300 text-brand-green-600">
                <span><span class="block font-semibold text-slate-800">Require an email address at registration</span><span class="text-slate-500">New accounts must provide an email (existing accounts are not affected).</span></span>
            </label>
            <label class="flex items-start gap-3 text-xs cursor-pointer">
                <input type="checkbox" name="email_verification_enforced" value="1" <?php if($settings['email_verification_enforced']): echo 'checked'; endif; ?> class="mt-0.5 rounded border-slate-300 text-brand-green-600">
                <span><span class="block font-semibold text-slate-800">Require verified email to write reviews</span><span class="text-slate-500">Applies only to accounts created after email verification launched. Older accounts and guest checkout are never blocked.</span></span>
            </label>
            <div class="max-w-md">
                <label class="mb-1 block text-xs font-semibold text-slate-700">Internal notification inbox</label>
                <input type="email" name="email_admin_notification_address" value="<?php echo e(old('email_admin_notification_address', $settings['email_admin_notification_address'])); ?>" class="admin-control w-full" placeholder="Defaults to the support email in Business Information">
                <p class="mt-1 text-[11px] text-slate-400">Receives contact form alerts.</p>
            </div>
            <p class="text-[11px] text-slate-500">OTP: <?php echo e(config('email_system.otp.length')); ?> digits, valid <?php echo e(config('email_system.otp.expires_minutes')); ?> min, <?php echo e(config('email_system.otp.max_attempts')); ?> attempts, <?php echo e(config('email_system.otp.resend_cooldown_seconds')); ?>s resend cooldown, max <?php echo e(config('email_system.otp.max_per_hour')); ?> codes/hour. Review invitations are sent <?php echo e(config('email_system.review_invitation_delay_days')); ?> days after delivery. (Configured in <code>config/email_system.php</code>.)</p>
        </div>

        <div class="flex justify-end">
            <?php if (isset($component)) { $__componentOriginal60a020e5340f3f52bbc4501dc9f93102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.button','data' => ['type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?>Save automation rules <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $attributes = $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $component = $__componentOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', ['headerTitle' => 'Email Automation'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/admin/email/automation.blade.php ENDPATH**/ ?>