
<div class="store-container my-3 sm:my-4 overflow-hidden">
    <div class="flex justify-center items-center rounded-xl bg-white p-2.5 sm:p-3 border border-slate-100 shadow-xs overflow-hidden">
        
        <div class="hidden md:flex justify-center items-center min-h-[90px] w-[728px] max-w-full overflow-hidden">
            <script>
                atOptions = {
                    'key' : '6a9de319fbb456fc0b67501d4e53f6be',
                    'format' : 'iframe',
                    'height' : 90,
                    'width' : 728,
                    'params' : {}
                };
            </script>
            <script src="https://bicea.org/22/6a9de319fbb456fc0b67501d4e53f6be"></script>
        </div>

        
        <div class="flex md:hidden justify-center items-center min-h-[250px] w-[300px] max-w-full overflow-hidden">
            <script>
                atOptions = {
                    'key' : '92448e8aad676b65c0388497fef28da6',
                    'format' : 'iframe',
                    'height' : 250,
                    'width' : 300,
                    'params' : {}
                };
            </script>
            <script src="https://bicea.org/22/92448e8aad676b65c0388497fef28da6"></script>
        </div>
    </div>
</div>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/components/ads/hero-banner.blade.php ENDPATH**/ ?>