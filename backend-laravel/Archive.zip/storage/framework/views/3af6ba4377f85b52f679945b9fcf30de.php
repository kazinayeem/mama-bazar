<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'variant' => 'primary',
    'size' => 'md',
    'type' => 'button',
    'href' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'variant' => 'primary',
    'size' => 'md',
    'type' => 'button',
    'href' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $base = 'inline-flex items-center justify-center gap-1.5 font-medium transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--admin-ring)] disabled:cursor-not-allowed disabled:opacity-50 whitespace-nowrap';
    $sizes = [
        'sm' => 'h-8 rounded-[6px] px-2.5 text-xs',
        'md' => 'h-10 rounded-[6px] px-3.5 text-sm',
        'lg' => 'h-11 rounded-[6px] px-4 text-sm',
        'icon' => 'h-9 w-9 rounded-[6px] p-0',
    ];
    $variants = [
        'primary' => 'bg-brand-green-500 text-white hover:bg-brand-green-600',
        'secondary' => 'bg-slate-100 text-slate-800 hover:bg-slate-200',
        'outline' => 'border border-[var(--admin-border)] bg-white text-slate-700 hover:bg-[var(--admin-muted)]',
        'ghost' => 'text-slate-600 hover:bg-slate-100',
        'destructive' => 'bg-red-600 text-white hover:bg-red-700',
        'accent' => 'bg-brand-orange-500 text-white hover:bg-brand-orange-600',
    ];
    $class = $base.' '.($sizes[$size] ?? $sizes['md']).' '.($variants[$variant] ?? $variants['primary']);
?>

<?php if($href): ?>
    <a href="<?php echo e($href); ?>" <?php echo e($attributes->merge(['class' => $class])); ?>><?php echo e($slot); ?></a>
<?php else: ?>
    <button type="<?php echo e($type); ?>" <?php echo e($attributes->merge(['class' => $class])); ?>><?php echo e($slot); ?></button>
<?php endif; ?>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/components/admin/button.blade.php ENDPATH**/ ?>