<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'label',
    'value',
    'hint' => null,
    'tone' => 'default',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'label',
    'value',
    'hint' => null,
    'tone' => 'default',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $valueClass = match($tone) {
        'success' => 'text-brand-green-700',
        'warning' => 'text-amber-600',
        'danger' => 'text-red-600',
        'accent' => 'text-brand-orange-600',
        default => 'text-slate-900',
    };
?>

<div <?php echo e($attributes->merge(['class' => 'admin-surface p-4'])); ?>>
    <p class="text-xs font-medium text-slate-500"><?php echo e($label); ?></p>
    <p class="mt-1 text-xl font-bold tracking-tight <?php echo e($valueClass); ?>"><?php echo e($value); ?></p>
    <?php if($hint): ?>
        <p class="mt-1 text-[11px] text-slate-400"><?php echo e($hint); ?></p>
    <?php endif; ?>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/components/admin/metric-card.blade.php ENDPATH**/ ?>