<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['seo' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['seo' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $biz = app(\App\Services\BusinessSettingService::class)->all();
    $siteName = $biz['site_name'] ?? 'Mama Bazar';
    $tagline = $biz['tagline'] ?? 'Online Grocery & Lifestyle Essentials';
    
    // Fallbacks if $seo is not passed or only partial
    $pageTitle = $seo['title'] ?? ($seo['meta_title'] ?? ($title ?? ($siteName . ' - ' . $tagline)));
    $metaDescription = $seo['meta_description'] ?? ($biz['business_description'] ?? '');
    $rawUrl = $seo['canonical_url'] ?? url()->current();
    if (config('app.env') === 'production' || str_contains($rawUrl, 'mama-bazar.com')) {
        $parsed = parse_url($rawUrl);
        $host = preg_replace('/^www\./i', '', $parsed['host'] ?? 'mama-bazar.com');
        $path = $parsed['path'] ?? '/';
        $canonicalUrl = 'https://' . $host . (empty($path) || $path === '/' ? '/' : rtrim($path, '/'));
    } else {
        $canonicalUrl = $rawUrl;
    }
    $robots = $seo['robots'] ?? 'index, follow';
    
    $ogType = $seo['og_type'] ?? 'website';
    $ogTitle = $seo['og_title'] ?? $pageTitle;
    $ogDescription = $seo['og_description'] ?? $metaDescription;
    $ogImage = $seo['og_image'] ?? url($biz['logo_url'] ?? '/brandlogo.png');
    $ogUrl = $seo['og_url'] ?? $canonicalUrl;

    $twitterCard = $seo['twitter_card'] ?? 'summary_large_image';
    $twitterTitle = $seo['twitter_title'] ?? $ogTitle;
    $twitterDescription = $seo['twitter_description'] ?? $ogDescription;
    $twitterImage = $seo['twitter_image'] ?? $ogImage;

    $schemas = $seo['schemas'] ?? [];
?>

<title><?php echo e($pageTitle); ?></title>

<?php if(!empty($metaDescription)): ?>
    <meta name="description" content="<?php echo e($metaDescription); ?>">
<?php endif; ?>

<?php if(!empty($metaKeywords)): ?>
    <meta name="keywords" content="<?php echo e($metaKeywords); ?>">
<?php endif; ?>

<meta name="robots" content="<?php echo e($robots); ?>">

<?php if(!empty($canonicalUrl)): ?>
    <link rel="canonical" href="<?php echo e($canonicalUrl); ?>">
<?php endif; ?>


<meta property="og:site_name" content="<?php echo e($siteName); ?>">
<meta property="og:type" content="<?php echo e($ogType); ?>">
<meta property="og:title" content="<?php echo e($ogTitle); ?>">
<?php if(!empty($ogDescription)): ?>
    <meta property="og:description" content="<?php echo e($ogDescription); ?>">
<?php endif; ?>
<?php if(!empty($ogUrl)): ?>
    <meta property="og:url" content="<?php echo e($ogUrl); ?>">
<?php endif; ?>
<?php if(!empty($ogImage)): ?>
    <meta property="og:image" content="<?php echo e($ogImage); ?>">
<?php endif; ?>
<meta property="og:locale" content="en_US">


<meta name="twitter:card" content="<?php echo e($twitterCard); ?>">
<meta name="twitter:title" content="<?php echo e($twitterTitle); ?>">
<?php if(!empty($twitterDescription)): ?>
    <meta name="twitter:description" content="<?php echo e($twitterDescription); ?>">
<?php endif; ?>
<?php if(!empty($twitterImage)): ?>
    <meta name="twitter:image" content="<?php echo e($twitterImage); ?>">
<?php endif; ?>


<?php if(!empty($schemas)): ?>
    <?php $__currentLoopData = $schemas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script type="application/ld+json">
<?php echo json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); ?>

        </script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/components/seo-head.blade.php ENDPATH**/ ?>