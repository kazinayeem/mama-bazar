<?php $__env->startSection('content'); ?>
<div class="pb-12">
    <?php echo $__env->make('web.homepage.sections', [
        'homepageData' => $homepageData,
        'config' => $config ?? [],
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/web/home.blade.php ENDPATH**/ ?>