<?php $__env->startSection('content'); ?>
<div class="admin-page" x-data="advancedAnalyticsDashboard()">

    
    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Advanced Analytics & Inventory Intelligence','subtitle' => 'Real-time stock valuation, sales performance, profit margins, and inventory health']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Advanced Analytics & Inventory Intelligence','subtitle' => 'Real-time stock valuation, sales performance, profit margins, and inventory health']); ?>
         <?php $__env->slot('actions', null, []); ?> 
            <div class="flex flex-wrap items-center gap-2">
                
                <a href="<?php echo e(route('admin.advanced-analytics.export.csv', request()->query())); ?>"
                   class="inline-flex h-9 items-center gap-2 rounded-[6px] border border-[var(--admin-border)] bg-white px-3 text-xs font-semibold text-slate-700 shadow-sm transition hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-[var(--admin-ring)]">
                    <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                    </svg>
                    <span>Export CSV</span>
                </a>

                
                <button type="button"
                        @click="pdfModalOpen = true"
                        class="inline-flex h-9 items-center gap-2 rounded-[6px] bg-[#0f4d2c] px-4 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0a3820] focus:outline-none focus:ring-2 focus:ring-[var(--admin-ring)]">
                    <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"/>
                    </svg>
                    <span>Export PDF Report</span>
                </button>
            </div>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    
    <div class="admin-surface p-4">
        <form method="GET" action="<?php echo e(route('admin.advanced-analytics.index')); ?>" id="analyticsFilterForm">
            <div class="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6">
                
                <div>
                    <label class="block text-[11px] font-semibold uppercase tracking-wider text-slate-500">Date Range</label>
                    <select name="preset"
                            class="admin-control mt-1 w-full text-xs font-medium"
                            x-model="preset"
                            @change="if(preset !== 'custom' && preset !== 'month_year') $el.form.submit()">
                        <option value="today">Today</option>
                        <option value="yesterday">Yesterday</option>
                        <option value="7d">Last 7 Days</option>
                        <option value="30d">Last 30 Days</option>
                        <option value="this_month">This Month</option>
                        <option value="last_month">Last Month</option>
                        <option value="this_quarter">This Quarter</option>
                        <option value="this_year">This Year</option>
                        <option value="month_year">Specific Month/Year</option>
                        <option value="custom">Custom Date Range</option>
                    </select>
                </div>

                
                <div>
                    <label class="block text-[11px] font-semibold uppercase tracking-wider text-slate-500">Category</label>
                    <select name="category_id" class="admin-control mt-1 w-full text-xs" onchange="this.form.submit()">
                        <option value="">All Categories</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php if($filters['category_id'] == $category->id): echo 'selected'; endif; ?>>
                                <?php echo e($category->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div>
                    <label class="block text-[11px] font-semibold uppercase tracking-wider text-slate-500">Brand</label>
                    <select name="brand_id" class="admin-control mt-1 w-full text-xs" onchange="this.form.submit()">
                        <option value="">All Brands</option>
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($brand->id); ?>" <?php if($filters['brand_id'] == $brand->id): echo 'selected'; endif; ?>>
                                <?php echo e($brand->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div>
                    <label class="block text-[11px] font-semibold uppercase tracking-wider text-slate-500">Stock Status</label>
                    <select name="stock_status" class="admin-control mt-1 w-full text-xs" onchange="this.form.submit()">
                        <option value="all" <?php if($filters['stock_status'] === 'all'): echo 'selected'; endif; ?>>All Inventory</option>
                        <option value="in_stock" <?php if($filters['stock_status'] === 'in_stock'): echo 'selected'; endif; ?>>In Stock (>10 units)</option>
                        <option value="low_stock" <?php if($filters['stock_status'] === 'low_stock'): echo 'selected'; endif; ?>>Low Stock (≤10 units)</option>
                        <option value="out_of_stock" <?php if($filters['stock_status'] === 'out_of_stock'): echo 'selected'; endif; ?>>Out of Stock (0 units)</option>
                        <option value="overstock" <?php if($filters['stock_status'] === 'overstock'): echo 'selected'; endif; ?>>Overstocked (≥100 units)</option>
                    </select>
                </div>

                
                <div>
                    <label class="block text-[11px] font-semibold uppercase tracking-wider text-slate-500">Catalog Status</label>
                    <select name="product_status" class="admin-control mt-1 w-full text-xs" onchange="this.form.submit()">
                        <option value="all" <?php if($filters['product_status'] === 'all'): echo 'selected'; endif; ?>>All Statuses</option>
                        <option value="published" <?php if($filters['product_status'] === 'published'): echo 'selected'; endif; ?>>Published</option>
                        <option value="draft" <?php if($filters['product_status'] === 'draft'): echo 'selected'; endif; ?>>Draft</option>
                        <option value="archived" <?php if($filters['product_status'] === 'archived'): echo 'selected'; endif; ?>>Archived</option>
                    </select>
                </div>

                
                <div>
                    <label class="block text-[11px] font-semibold uppercase tracking-wider text-slate-500">Sort By</label>
                    <select name="sort_by" class="admin-control mt-1 w-full text-xs" onchange="this.form.submit()">
                        <option value="revenue_desc" <?php if($filters['sort_by'] === 'revenue_desc'): echo 'selected'; endif; ?>>Highest Revenue</option>
                        <option value="units_desc" <?php if($filters['sort_by'] === 'units_desc'): echo 'selected'; endif; ?>>Most Units Sold</option>
                        <option value="stock_desc" <?php if($filters['sort_by'] === 'stock_desc'): echo 'selected'; endif; ?>>Stock: High to Low</option>
                        <option value="stock_asc" <?php if($filters['sort_by'] === 'stock_asc'): echo 'selected'; endif; ?>>Stock: Low to High</option>
                        <option value="retail_val_desc" <?php if($filters['sort_by'] === 'retail_val_desc'): echo 'selected'; endif; ?>>Retail Value</option>
                        <option value="price_desc" <?php if($filters['sort_by'] === 'price_desc'): echo 'selected'; endif; ?>>Price: High to Low</option>
                        <option value="price_asc" <?php if($filters['sort_by'] === 'price_asc'): echo 'selected'; endif; ?>>Price: Low to High</option>
                        <option value="title_asc" <?php if($filters['sort_by'] === 'title_asc'): echo 'selected'; endif; ?>>Product Name</option>
                    </select>
                </div>
            </div>

            
            <div x-show="preset === 'custom' || preset === 'month_year'" x-cloak class="mt-3 grid grid-cols-1 gap-3 border-t border-slate-100 pt-3 sm:grid-cols-2 lg:grid-cols-4">
                <template x-if="preset === 'custom'">
                    <div class="col-span-full grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
                        <div>
                            <label class="block text-[11px] font-semibold uppercase tracking-wider text-slate-500">Start Date</label>
                            <input type="date" name="start_date" value="<?php echo e($filters['start_date']->format('Y-m-d')); ?>" class="admin-control mt-1 w-full text-xs">
                        </div>
                        <div>
                            <label class="block text-[11px] font-semibold uppercase tracking-wider text-slate-500">End Date</label>
                            <input type="date" name="end_date" value="<?php echo e($filters['end_date']->format('Y-m-d')); ?>" class="admin-control mt-1 w-full text-xs">
                        </div>
                        <div class="flex items-end">
                            <button type="submit" class="inline-flex h-[40px] w-full items-center justify-center rounded-[6px] bg-[#0f4d2c] px-4 text-xs font-semibold text-white shadow-sm hover:bg-[#0a3820]">
                                Apply Custom Dates
                            </button>
                        </div>
                    </div>
                </template>

                <template x-if="preset === 'month_year'">
                    <div class="col-span-full grid grid-cols-1 gap-3 sm:grid-cols-3">
                        <div>
                            <label class="block text-[11px] font-semibold uppercase tracking-wider text-slate-500">Month</label>
                            <select name="month" class="admin-control mt-1 w-full text-xs">
                                <?php for($m = 1; $m <= 12; $m++): ?>
                                    <option value="<?php echo e($m); ?>" <?php if($filters['month'] == $m): echo 'selected'; endif; ?>>
                                        <?php echo e(\Carbon\Carbon::create(2026, $m, 1)->format('F')); ?>

                                    </option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div>
                            <label class="block text-[11px] font-semibold uppercase tracking-wider text-slate-500">Year</label>
                            <select name="year" class="admin-control mt-1 w-full text-xs">
                                <?php for($y = 2024; $y <= 2028; $y++): ?>
                                    <option value="<?php echo e($y); ?>" <?php if($filters['year'] == $y): echo 'selected'; endif; ?>><?php echo e($y); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="flex items-end">
                            <button type="submit" class="inline-flex h-[40px] w-full items-center justify-center rounded-[6px] bg-[#0f4d2c] px-4 text-xs font-semibold text-white shadow-sm hover:bg-[#0a3820]">
                                Load Month Analytics
                            </button>
                        </div>
                    </div>
                </template>
            </div>

            
            <div class="mt-3 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-3">
                <div class="relative min-w-[260px] flex-1 max-w-md">
                    <svg class="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                    </svg>
                    <input type="text"
                           name="search"
                           value="<?php echo e($filters['search']); ?>"
                           placeholder="Search product name, SKU, or barcode..."
                           class="admin-control w-full pl-9 text-xs">
                </div>

                <div class="flex items-center gap-2">
                    <select name="per_page" class="admin-control text-xs" onchange="this.form.submit()">
                        <option value="15" <?php if($filters['per_page'] == 15): echo 'selected'; endif; ?>>15 rows</option>
                        <option value="25" <?php if($filters['per_page'] == 25): echo 'selected'; endif; ?>>25 rows</option>
                        <option value="50" <?php if($filters['per_page'] == 50): echo 'selected'; endif; ?>>50 rows</option>
                        <option value="100" <?php if($filters['per_page'] == 100): echo 'selected'; endif; ?>>100 rows</option>
                    </select>

                    <button type="submit" class="inline-flex h-[40px] items-center gap-1.5 rounded-[6px] bg-slate-900 px-4 text-xs font-semibold text-white hover:bg-slate-800">
                        <span>Apply</span>
                    </button>

                    <a href="<?php echo e(route('admin.advanced-analytics.index')); ?>" class="inline-flex h-[40px] items-center rounded-[6px] border border-slate-200 bg-white px-3 text-xs font-medium text-slate-600 hover:bg-slate-50">
                        Reset
                    </a>
                </div>
            </div>
        </form>

        
        <?php
            $hasActiveFilters = $filters['preset'] !== '30d' || !empty($filters['category_id']) || !empty($filters['brand_id']) || !empty($filters['search']) || $filters['stock_status'] !== 'all' || $filters['product_status'] !== 'all';
        ?>
        <?php if($hasActiveFilters): ?>
            <div class="mt-3 flex flex-wrap items-center gap-1.5 border-t border-slate-100 pt-2.5 text-xs">
                <span class="font-semibold text-slate-400">Active Filters:</span>
                <?php if($filters['preset'] !== '30d'): ?>
                    <span class="inline-flex items-center gap-1 rounded bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-700">
                        Period: <?php echo e($filters['start_date']->format('d M')); ?> — <?php echo e($filters['end_date']->format('d M')); ?>

                    </span>
                <?php endif; ?>
                <?php if(!empty($filters['category_id'])): ?>
                    <?php $activeCategory = $categories->firstWhere('id', $filters['category_id']); ?>
                    <span class="inline-flex items-center gap-1 rounded bg-emerald-50 px-2 py-0.5 text-[11px] font-medium text-emerald-800">
                        Category: <?php echo e($activeCategory?->name ?? $filters['category_id']); ?>

                    </span>
                <?php endif; ?>
                <?php if(!empty($filters['brand_id'])): ?>
                    <?php $activeBrand = $brands->firstWhere('id', $filters['brand_id']); ?>
                    <span class="inline-flex items-center gap-1 rounded bg-blue-50 px-2 py-0.5 text-[11px] font-medium text-blue-800">
                        Brand: <?php echo e($activeBrand?->name ?? $filters['brand_id']); ?>

                    </span>
                <?php endif; ?>
                <?php if($filters['stock_status'] !== 'all'): ?>
                    <span class="inline-flex items-center gap-1 rounded bg-amber-50 px-2 py-0.5 text-[11px] font-medium text-amber-800">
                        Stock: <?php echo e(ucfirst(str_replace('_', ' ', $filters['stock_status']))); ?>

                    </span>
                <?php endif; ?>
                <?php if($filters['product_status'] !== 'all'): ?>
                    <span class="inline-flex items-center gap-1 rounded bg-purple-50 px-2 py-0.5 text-[11px] font-medium text-purple-800">
                        Status: <?php echo e(ucfirst($filters['product_status'])); ?>

                    </span>
                <?php endif; ?>
                <?php if(!empty($filters['search'])): ?>
                    <span class="inline-flex items-center gap-1 rounded bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-700">
                        Query: "<?php echo e($filters['search']); ?>"
                    </span>
                <?php endif; ?>
                <a href="<?php echo e(route('admin.advanced-analytics.index')); ?>" class="ml-1 text-[11px] text-red-600 underline hover:text-red-800">Clear all</a>
            </div>
        <?php endif; ?>
    </div>

    
    <div>
        
        <div class="mb-2 flex items-center justify-between">
            <h2 class="text-xs font-bold uppercase tracking-wider text-slate-500">
                1. Inventory Intelligence & Valuation (Snapshot: <?php echo e($inventoryKpis['snapshot_date']); ?>)
            </h2>
            <span class="text-[11px] text-slate-400">Values calculated from active product catalog</span>
        </div>

        <div class="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            
            <div class="admin-surface relative overflow-hidden p-4">
                <div class="flex items-start justify-between">
                    <div>
                        <p class="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Active Products</p>
                        <p class="mt-1 text-2xl font-bold text-slate-900"><?php echo e(number_format($inventoryKpis['active_products'])); ?></p>
                    </div>
                    <div class="rounded-lg bg-emerald-50 p-2 text-emerald-700">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                    </div>
                </div>
                <div class="mt-2 flex items-center gap-2 text-xs text-slate-500">
                    <span><?php echo e(number_format($inventoryKpis['total_products'])); ?> total in catalog</span>
                    <span class="h-1 w-1 rounded-full bg-slate-300"></span>
                    <span class="font-medium text-slate-600"><?php echo e(number_format($inventoryKpis['active_variants'])); ?> active variants</span>
                </div>
            </div>

            
            <div class="admin-surface relative overflow-hidden p-4">
                <div class="flex items-start justify-between">
                    <div>
                        <p class="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Units in Stock</p>
                        <p class="mt-1 text-2xl font-bold text-slate-900"><?php echo e(number_format($inventoryKpis['total_units_in_stock'])); ?></p>
                    </div>
                    <div class="rounded-lg bg-blue-50 p-2 text-blue-700">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
                    </div>
                </div>
                <div class="mt-2 flex items-center gap-3 text-xs">
                    <span class="inline-flex items-center gap-1 font-semibold text-amber-600">
                        <span class="h-1.5 w-1.5 rounded-full bg-amber-500"></span> <?php echo e($inventoryKpis['low_stock_count']); ?> Low
                    </span>
                    <span class="inline-flex items-center gap-1 font-semibold text-rose-600">
                        <span class="h-1.5 w-1.5 rounded-full bg-rose-500"></span> <?php echo e($inventoryKpis['out_of_stock_count']); ?> Out
                    </span>
                    <span class="inline-flex items-center gap-1 text-slate-500">
                        <?php echo e($inventoryKpis['overstocked_count']); ?> Overstock
                    </span>
                </div>
            </div>

            
            <div class="admin-surface relative overflow-hidden p-4">
                <div class="flex items-start justify-between">
                    <div>
                        <p class="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Potential Retail Valuation</p>
                        <p class="mt-1 text-2xl font-bold text-slate-900">৳<?php echo e(number_format($inventoryKpis['retail_valuation'], 0)); ?></p>
                    </div>
                    <div class="rounded-lg bg-emerald-50 p-2 text-[#0f4d2c]">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    </div>
                </div>
                <div class="mt-2 text-xs text-slate-500">
                    <span>Retail value across all present inventory units</span>
                </div>
            </div>

            
            <?php if($financialAccess->canViewCostValuation): ?>
            <div class="admin-surface relative overflow-hidden p-4">
                <div class="flex items-start justify-between">
                    <div>
                        <p class="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Valuation at Cost</p>
                        <?php if($inventoryKpis['cost_valuation'] !== null): ?>
                            <p class="mt-1 text-2xl font-bold text-slate-900">৳<?php echo e(number_format($inventoryKpis['cost_valuation'], 0)); ?></p>
                        <?php else: ?>
                            <p class="mt-1 text-lg font-bold text-slate-400">Cost data unavailable</p>
                        <?php endif; ?>
                    </div>
                    <div class="rounded-lg bg-amber-50 p-2 text-amber-700">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
                    </div>
                </div>
                <div class="mt-2 flex items-center justify-between text-xs">
                    <?php if($inventoryKpis['cost_data_status'] === 'unavailable'): ?>
                        <span class="text-slate-400">Requires cost_price on products</span>
                    <?php elseif($inventoryKpis['cost_data_status'] === 'partial'): ?>
                        <span class="rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-semibold text-amber-800">Partial: <?php echo e($inventoryKpis['cost_coverage_pct']); ?>% products</span>
                    <?php else: ?>
                        <span class="text-emerald-700 font-semibold">100% cost verified</span>
                    <?php endif; ?>

                    <?php if($inventoryKpis['unrealized_margin'] !== null): ?>
                        <span class="font-bold text-emerald-700">Margin: <?php echo e($inventoryKpis['unrealized_margin']); ?>%</span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>

        
        <div class="mt-4 mb-2 flex items-center justify-between">
            <h2 class="text-xs font-bold uppercase tracking-wider text-slate-500">
                2. Sales, Revenue & Profit Performance (<?php echo e($filters['start_date']->format('d M')); ?> — <?php echo e($filters['end_date']->format('d M, Y')); ?>)
            </h2>
            <span class="text-[11px] text-slate-400">Comparing with previous equivalent period</span>
        </div>

        <div class="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            
            <div class="admin-surface p-4">
                <div class="flex items-start justify-between">
                    <div>
                        <p class="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Gross Sales</p>
                        <p class="mt-1 text-2xl font-bold text-slate-900">৳<?php echo e(number_format($salesKpis['gross_sales'], 0)); ?></p>
                    </div>
                    <?php if($salesKpis['gross_sales_growth'] !== null): ?>
                        <span class="inline-flex items-center gap-0.5 rounded px-2 py-0.5 text-xs font-bold <?php echo e($salesKpis['gross_sales_growth'] >= 0 ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'); ?>">
                            <?php echo e($salesKpis['gross_sales_growth'] > 0 ? '+' : ''); ?><?php echo e($salesKpis['gross_sales_growth']); ?>%
                        </span>
                    <?php endif; ?>
                </div>
                <div class="mt-2 text-xs text-slate-500">
                    <span><?php echo e(number_format($salesKpis['all_orders_count'])); ?> total orders placed in period</span>
                </div>
            </div>

            
            <div class="admin-surface p-4">
                <div class="flex items-start justify-between">
                    <div>
                        <p class="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Net Sales</p>
                        <p class="mt-1 text-2xl font-bold text-emerald-700">৳<?php echo e(number_format($salesKpis['net_sales'], 0)); ?></p>
                    </div>
                    <?php if($salesKpis['sales_growth'] !== null): ?>
                        <span class="inline-flex items-center gap-0.5 rounded px-2 py-0.5 text-xs font-bold <?php echo e($salesKpis['sales_growth'] >= 0 ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'); ?>">
                            <?php echo e($salesKpis['sales_growth'] > 0 ? '+' : ''); ?><?php echo e($salesKpis['sales_growth']); ?>%
                        </span>
                    <?php endif; ?>
                </div>
                <div class="mt-2 text-xs text-slate-500">
                    <span>Excludes cancelled (৳<?php echo e(number_format($salesKpis['cancelled_sales'], 0)); ?>) & refunds</span>
                </div>
            </div>

            
            <div class="admin-surface p-4">
                <div class="flex items-start justify-between">
                    <div>
                        <p class="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Orders & Units Sold</p>
                        <p class="mt-1 text-2xl font-bold text-slate-900">
                            <?php echo e(number_format($salesKpis['orders_count'])); ?> <span class="text-sm font-normal text-slate-400">orders</span> / <?php echo e(number_format($salesKpis['units_sold'])); ?> <span class="text-sm font-normal text-slate-400">units</span>
                        </p>
                    </div>
                    <?php if($salesKpis['orders_growth'] !== null): ?>
                        <span class="inline-flex items-center gap-0.5 rounded px-2 py-0.5 text-xs font-bold <?php echo e($salesKpis['orders_growth'] >= 0 ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'); ?>">
                            <?php echo e($salesKpis['orders_growth'] > 0 ? '+' : ''); ?><?php echo e($salesKpis['orders_growth']); ?>%
                        </span>
                    <?php endif; ?>
                </div>
                <div class="mt-2 text-xs text-slate-500">
                    <span>AOV: <strong class="text-slate-800">৳<?php echo e(number_format($salesKpis['avg_order_value'], 0)); ?></strong></span>
                </div>
            </div>

            
            <?php if($financialAccess->canViewProfitMargin): ?>
            <div class="admin-surface p-4">
                <div class="flex items-start justify-between">
                    <div>
                        <p class="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Gross Profit & Margin</p>
                        <?php if($salesKpis['gross_profit'] !== null): ?>
                            <p class="mt-1 text-2xl font-bold text-emerald-700">
                                ৳<?php echo e(number_format($salesKpis['gross_profit'], 0)); ?>

                                <span class="text-sm font-semibold text-slate-500">(<?php echo e($salesKpis['gross_margin_pct']); ?>%)</span>
                            </p>
                        <?php else: ?>
                            <p class="mt-1 text-lg font-bold text-slate-400">Cost data unavailable</p>
                        <?php endif; ?>
                    </div>
                    <div class="rounded-lg bg-slate-50 p-2 text-slate-500">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>
                    </div>
                </div>
                <div class="mt-2 text-xs text-slate-500">
                    <?php if($salesKpis['profit_status'] === 'unavailable'): ?>
                        <span>Set product cost price to calculate profit</span>
                    <?php elseif($salesKpis['profit_status'] === 'partial'): ?>
                        <span class="rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-semibold text-amber-800">
                            Based on <?php echo e($salesKpis['items_with_cost']); ?> of <?php echo e($salesKpis['total_items_sold_count']); ?> sold items
                        </span>
                    <?php else: ?>
                        <span class="text-emerald-700 font-semibold">100% of sold items verified</span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="grid grid-cols-1 gap-4 xl:grid-cols-3">
        
        <div class="admin-surface p-5 xl:col-span-2">
            <div class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div>
                    <h3 class="font-bold text-slate-900">Sales & Revenue Trends</h3>
                    <p class="text-xs text-slate-500">Daily gross and net revenue performance across selected date range</p>
                </div>
                <div class="flex items-center gap-4 text-xs font-semibold">
                    <span class="inline-flex items-center gap-1.5 text-slate-600">
                        <span class="h-2.5 w-2.5 rounded-sm bg-[#176B3A]"></span> Net Sales
                    </span>
                    <span class="inline-flex items-center gap-1.5 text-slate-600">
                        <span class="h-2.5 w-2.5 rounded-sm bg-[#94A3B8]"></span> Gross Sales
                    </span>
                </div>
            </div>

            
            <div class="mt-4">
                <?php if(count($chartsData['sales_trend']) > 0): ?>
                    <?php
                        $maxRev = max(1, collect($chartsData['sales_trend'])->max('gross_sales'));
                    ?>
                    <div class="flex h-56 items-end gap-1 overflow-x-auto pt-6 pb-2" style="scrollbar-width: thin;">
                        <?php $__currentLoopData = $chartsData['sales_trend']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $grossHeight = max(2, min(100, ($point['gross_sales'] / $maxRev) * 100));
                                $netHeight = max(2, min(100, ($point['net_sales'] / $maxRev) * 100));
                            ?>
                            <div class="group relative flex flex-1 min-w-[28px] flex-col items-center justify-end h-full">
                                
                                <div class="pointer-events-none absolute -top-14 z-20 hidden w-36 rounded-md bg-slate-900 p-2 text-center text-[10px] text-white shadow-lg group-hover:block">
                                    <div class="font-bold"><?php echo e($point['label']); ?></div>
                                    <div class="text-emerald-400">Net: ৳<?php echo e(number_format($point['net_sales'], 0)); ?></div>
                                    <div class="text-slate-300">Gross: ৳<?php echo e(number_format($point['gross_sales'], 0)); ?></div>
                                    <div class="text-slate-400"><?php echo e($point['orders']); ?> orders (<?php echo e($point['units']); ?> pcs)</div>
                                </div>

                                
                                <div class="flex items-end gap-0.5 w-full justify-center h-full">
                                    <div class="w-2.5 rounded-t bg-slate-300 transition-all hover:bg-slate-400"
                                         style="height: <?php echo e($grossHeight); ?>%"></div>
                                    <div class="w-2.5 rounded-t bg-[#176B3A] transition-all hover:bg-[#0f4d2c]"
                                         style="height: <?php echo e($netHeight); ?>%"></div>
                                </div>

                                <span class="mt-2 block truncate text-[9px] text-slate-400 group-hover:text-slate-700">
                                    <?php echo e($point['label']); ?>

                                </span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <div class="flex h-48 items-center justify-center text-xs text-slate-400">
                        No sales activity recorded in this period.
                    </div>
                <?php endif; ?>
            </div>
        </div>

        
        <div class="admin-surface p-5">
            <div class="border-b border-slate-100 pb-3">
                <h3 class="font-bold text-slate-900">Stock Status Distribution</h3>
                <p class="text-xs text-slate-500">Breakdown of products by inventory availability</p>
            </div>

            <?php $dist = $chartsData['stock_distribution']; ?>
            <div class="mt-4 space-y-3.5">
                
                <div>
                    <div class="flex items-center justify-between text-xs">
                        <span class="font-medium text-slate-700">In Stock (>10 units)</span>
                        <span class="font-bold text-emerald-700"><?php echo e($dist['in_stock']); ?> (<?php echo e($dist['in_stock_pct']); ?>%)</span>
                    </div>
                    <div class="mt-1 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                        <div class="h-full rounded-full bg-emerald-600" style="width: <?php echo e($dist['in_stock_pct']); ?>%"></div>
                    </div>
                </div>

                
                <div>
                    <div class="flex items-center justify-between text-xs">
                        <span class="font-medium text-amber-700">Low Stock (≤10 units)</span>
                        <span class="font-bold text-amber-800"><?php echo e($dist['low_stock']); ?> (<?php echo e($dist['low_stock_pct']); ?>%)</span>
                    </div>
                    <div class="mt-1 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                        <div class="h-full rounded-full bg-amber-500" style="width: <?php echo e($dist['low_stock_pct']); ?>%"></div>
                    </div>
                </div>

                
                <div>
                    <div class="flex items-center justify-between text-xs">
                        <span class="font-medium text-rose-700">Out of Stock (0 units)</span>
                        <span class="font-bold text-rose-800"><?php echo e($dist['out_of_stock']); ?> (<?php echo e($dist['out_of_stock_pct']); ?>%)</span>
                    </div>
                    <div class="mt-1 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                        <div class="h-full rounded-full bg-rose-600" style="width: <?php echo e($dist['out_of_stock_pct']); ?>%"></div>
                    </div>
                </div>

                
                <div>
                    <div class="flex items-center justify-between text-xs">
                        <span class="font-medium text-indigo-700">Overstocked (≥100 units)</span>
                        <span class="font-bold text-indigo-800"><?php echo e($dist['overstock']); ?> (<?php echo e($dist['overstock_pct']); ?>%)</span>
                    </div>
                    <div class="mt-1 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                        <div class="h-full rounded-full bg-indigo-600" style="width: <?php echo e($dist['overstock_pct']); ?>%"></div>
                    </div>
                </div>

                <div class="rounded-lg bg-slate-50 p-3 mt-4 text-[11px] text-slate-600">
                    <p class="font-semibold text-slate-900">Slow-Moving Inventory Exposure:</p>
                    <p class="mt-0.5">৳<?php echo e(number_format($inventoryKpis['slow_moving_valuation'], 0)); ?> tied in <?php echo e($inventoryKpis['slow_moving_count']); ?> products with zero sales in period.</p>
                </div>
            </div>
        </div>
    </div>

    
    <div class="grid grid-cols-1 gap-4 xl:grid-cols-2">
        
        <div class="admin-surface p-5">
            <div class="border-b border-slate-100 pb-3">
                <h3 class="font-bold text-slate-900">Stock & Retail Valuation by Category</h3>
                <p class="text-xs text-slate-500">Total units and potential retail valuation across top categories</p>
            </div>

            <div class="mt-4 space-y-3">
                <?php $__empty_1 = true; $__currentLoopData = $chartsData['category_inventory']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $maxCatVal = max(1, collect($chartsData['category_inventory'])->max('retail_value'));
                        $w = min(100, ($cat['retail_value'] / $maxCatVal) * 100);
                    ?>
                    <div>
                        <div class="flex items-center justify-between text-xs">
                            <span class="font-semibold text-slate-800"><?php echo e($cat['category']); ?></span>
                            <span class="text-slate-500">
                                <strong><?php echo e(number_format($cat['stock'])); ?></strong> units | <strong class="text-slate-900">৳<?php echo e(number_format($cat['retail_value'], 0)); ?></strong>
                            </span>
                        </div>
                        <div class="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                            <div class="h-full rounded-full bg-[#176B3A]" style="width: <?php echo e($w); ?>%"></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-xs text-slate-400 py-6 text-center">No category inventory recorded.</p>
                <?php endif; ?>
            </div>
        </div>

        
        <div class="admin-surface p-5">
            <div class="border-b border-slate-100 pb-3">
                <h3 class="font-bold text-slate-900">Pricing & Discount Analysis</h3>
                <p class="text-xs text-slate-500">Distribution of products by selling price and discount brackets</p>
            </div>

            <div class="mt-4 grid grid-cols-2 gap-4">
                
                <div>
                    <h4 class="text-[11px] font-bold uppercase tracking-wider text-slate-400">Price Tiers</h4>
                    <div class="mt-2 space-y-2">
                        <?php $__currentLoopData = $chartsData['pricing_analysis']['price_tiers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tier => $cnt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex items-center justify-between rounded bg-slate-50 px-2.5 py-1.5 text-xs">
                                <span class="font-medium text-slate-700"><?php echo e($tier); ?></span>
                                <span class="font-bold text-slate-900"><?php echo e($cnt); ?> items</span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                
                <div>
                    <h4 class="text-[11px] font-bold uppercase tracking-wider text-slate-400">Discount Levels</h4>
                    <div class="mt-2 space-y-2">
                        <?php $__currentLoopData = $chartsData['pricing_analysis']['discount_tiers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disc => $cnt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex items-center justify-between rounded bg-slate-50 px-2.5 py-1.5 text-xs">
                                <span class="font-medium text-slate-700"><?php echo e($disc); ?></span>
                                <span class="font-bold text-slate-900"><?php echo e($cnt); ?> items</span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <?php if(!empty($chartsData['pricing_analysis']['highest_discounts'])): ?>
                <div class="mt-4 border-t border-slate-100 pt-3">
                    <h4 class="text-[11px] font-bold uppercase tracking-wider text-slate-400">Highest Discounted Products</h4>
                    <div class="mt-2 space-y-1.5">
                        <?php $__currentLoopData = $chartsData['pricing_analysis']['highest_discounts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex items-center justify-between text-xs">
                                <span class="truncate max-w-[220px] text-slate-700"><?php echo e($hd['title']); ?></span>
                                <span class="rounded bg-rose-50 px-1.5 py-0.5 text-[10px] font-bold text-rose-700">
                                    <?php echo e($hd['discount_pct']); ?>% OFF (৳<?php echo e(number_format($hd['sale_price'], 0)); ?>)
                                </span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="grid grid-cols-1 gap-4 lg:grid-cols-3" x-data="{ perfTab: 'best_sellers' }">
        
        <div class="admin-surface p-5 lg:col-span-2">
            <div class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <h3 class="font-bold text-slate-900">Product Performance Intelligence</h3>
                <div class="flex items-center gap-1 rounded-[6px] bg-slate-100 p-1 text-xs">
                    <button type="button" @click="perfTab = 'best_sellers'" :class="perfTab === 'best_sellers' ? 'bg-white shadow text-slate-900 font-bold' : 'text-slate-600'" class="rounded px-2.5 py-1 transition">Top Sellers</button>
                    <button type="button" @click="perfTab = 'highest_revenue'" :class="perfTab === 'highest_revenue' ? 'bg-white shadow text-slate-900 font-bold' : 'text-slate-600'" class="rounded px-2.5 py-1 transition">Highest Revenue</button>
                    <button type="button" @click="perfTab = 'slow_moving'" :class="perfTab === 'slow_moving' ? 'bg-white shadow text-slate-900 font-bold' : 'text-slate-600'" class="rounded px-2.5 py-1 transition">Slow Moving</button>
                    <button type="button" @click="perfTab = 'low_demand'" :class="perfTab === 'low_demand' ? 'bg-white shadow text-slate-900 font-bold' : 'text-slate-600'" class="rounded px-2.5 py-1 transition">Low Stock Demand</button>
                </div>
            </div>

            <div class="mt-4">
                
                <div x-show="perfTab === 'best_sellers'">
                    <table class="w-full text-left text-xs">
                        <thead>
                            <tr class="text-slate-400 uppercase text-[10px] border-b">
                                <th class="pb-2">Product</th>
                                <th class="pb-2 text-center">Stock</th>
                                <th class="pb-2 text-center">Units Sold</th>
                                <th class="pb-2 text-right">Revenue</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            <?php $__empty_1 = true; $__currentLoopData = $chartsData['product_performance']['best_sellers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="py-2.5 font-medium text-slate-800"><?php echo e($prod->title); ?></td>
                                    <td class="py-2.5 text-center text-slate-600"><?php echo e($prod->stock); ?></td>
                                    <td class="py-2.5 text-center font-bold text-emerald-700"><?php echo e($prod->units_sold); ?></td>
                                    <td class="py-2.5 text-right font-bold text-slate-900">৳<?php echo e(number_format($prod->revenue, 0)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="4" class="py-4 text-center text-slate-400">No sales recorded yet.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                
                <div x-show="perfTab === 'highest_revenue'" x-cloak>
                    <table class="w-full text-left text-xs">
                        <thead>
                            <tr class="text-slate-400 uppercase text-[10px] border-b">
                                <th class="pb-2">Product</th>
                                <th class="pb-2 text-center">Stock</th>
                                <th class="pb-2 text-center">Units</th>
                                <th class="pb-2 text-right">Revenue</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            <?php $__empty_1 = true; $__currentLoopData = $chartsData['product_performance']['highest_revenue']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="py-2.5 font-medium text-slate-800"><?php echo e($prod->title); ?></td>
                                    <td class="py-2.5 text-center text-slate-600"><?php echo e($prod->stock); ?></td>
                                    <td class="py-2.5 text-center text-slate-600"><?php echo e($prod->units_sold); ?></td>
                                    <td class="py-2.5 text-right font-bold text-emerald-700">৳<?php echo e(number_format($prod->revenue, 0)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="4" class="py-4 text-center text-slate-400">No revenue records found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                
                <div x-show="perfTab === 'slow_moving'" x-cloak>
                    <table class="w-full text-left text-xs">
                        <thead>
                            <tr class="text-slate-400 uppercase text-[10px] border-b">
                                <th class="pb-2">Product</th>
                                <th class="pb-2 text-center">Stock</th>
                                <th class="pb-2 text-right">Price</th>
                                <th class="pb-2 text-right">Capital Tied</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            <?php $__empty_1 = true; $__currentLoopData = $chartsData['product_performance']['slow_moving']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="py-2.5 font-medium text-slate-800"><?php echo e($prod->title); ?></td>
                                    <td class="py-2.5 text-center font-bold text-amber-600"><?php echo e($prod->stock); ?></td>
                                    <td class="py-2.5 text-right text-slate-600">৳<?php echo e(number_format($prod->sale_price ?: $prod->price, 0)); ?></td>
                                    <td class="py-2.5 text-right font-bold text-slate-900">৳<?php echo e(number_format($prod->tied_capital, 0)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="4" class="py-4 text-center text-slate-400">No slow moving inventory identified.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                
                <div x-show="perfTab === 'low_demand'" x-cloak>
                    <table class="w-full text-left text-xs">
                        <thead>
                            <tr class="text-slate-400 uppercase text-[10px] border-b">
                                <th class="pb-2">Product</th>
                                <th class="pb-2 text-center">Current Stock</th>
                                <th class="pb-2 text-center">Units Sold</th>
                                <th class="pb-2 text-right">Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            <?php $__empty_1 = true; $__currentLoopData = $chartsData['product_performance']['low_stock_high_demand']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="py-2.5 font-medium text-slate-800"><?php echo e($prod->title); ?></td>
                                    <td class="py-2.5 text-center font-bold text-rose-600"><?php echo e($prod->stock); ?></td>
                                    <td class="py-2.5 text-center font-bold text-emerald-700"><?php echo e($prod->units_sold); ?></td>
                                    <td class="py-2.5 text-right">
                                        <span class="rounded bg-rose-50 px-2 py-0.5 text-[10px] font-bold text-rose-700">Reorder Alert</span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="4" class="py-4 text-center text-slate-400">No low stock items with high demand found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        
        <div class="admin-surface p-5">
            <div class="border-b border-slate-100 pb-3">
                <h3 class="font-bold text-slate-900">Variant Inventory Health</h3>
                <p class="text-xs text-slate-500">SKU variant metrics across active catalog</p>
            </div>

            <?php $vData = $chartsData['variant_analytics']; ?>
            <div class="mt-4 space-y-3">
                <div class="flex items-center justify-between rounded bg-slate-50 p-2.5 text-xs">
                    <span class="text-slate-600 font-medium">Total Tracked Variants</span>
                    <span class="font-bold text-slate-900"><?php echo e(number_format($vData['total_variants'])); ?></span>
                </div>
                <div class="flex items-center justify-between rounded bg-emerald-50 p-2.5 text-xs">
                    <span class="text-emerald-800 font-medium">In Stock Variants</span>
                    <span class="font-bold text-emerald-900"><?php echo e(number_format($vData['in_stock'])); ?></span>
                </div>
                <div class="flex items-center justify-between rounded bg-rose-50 p-2.5 text-xs">
                    <span class="text-rose-800 font-medium">Out of Stock Variants</span>
                    <span class="font-bold text-rose-900"><?php echo e(number_format($vData['out_of_stock'])); ?></span>
                </div>

                <?php if(!empty($vData['top_variants']) && count($vData['top_variants']) > 0): ?>
                    <div class="mt-4 border-t border-slate-100 pt-3">
                        <h4 class="text-[11px] font-bold uppercase tracking-wider text-slate-400">Top Sold Variants</h4>
                        <div class="mt-2 space-y-2">
                            <?php $__currentLoopData = $vData['top_variants']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tVar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex items-center justify-between text-xs">
                                    <span class="truncate max-w-[170px] text-slate-700"><?php echo e($tVar->name); ?></span>
                                    <span class="font-bold text-slate-900"><?php echo e($tVar->units_sold); ?> pcs</span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <div class="admin-surface overflow-hidden">
        
        <div class="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 p-4">
            <div>
                <h3 class="font-bold text-slate-900">Product & Stock Intelligence Table</h3>
                <p class="text-xs text-slate-500">Showing <?php echo e($products->firstItem() ?? 0); ?>–<?php echo e($products->lastItem() ?? 0); ?> of <?php echo e($products->total()); ?> matching products</p>
            </div>

            <div class="flex items-center gap-2">
                
                <div class="relative" x-data="{ colOpen: false }" @click.outside="colOpen = false">
                    <button type="button" @click="colOpen = !colOpen" class="inline-flex h-8 items-center gap-1.5 rounded-[6px] border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700 hover:bg-slate-50">
                        <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17V7m0 10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h2a2 2 0 012 2m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 10V7m0 10a2 2 0 002 2h2a2 2 0 002-2V7a2 2 0 00-2-2h-2a2 2 0 00-2 2"/></svg>
                        <span>Columns</span>
                    </button>
                    <div x-show="colOpen" x-cloak class="absolute right-0 z-30 mt-1 w-48 rounded-md border border-slate-200 bg-white p-2 shadow-lg text-xs space-y-1">
                        <label class="flex items-center gap-2 px-2 py-1 hover:bg-slate-50 cursor-pointer">
                            <input type="checkbox" x-model="cols.sku" class="rounded text-emerald-600"> <span>SKU</span>
                        </label>
                        <label class="flex items-center gap-2 px-2 py-1 hover:bg-slate-50 cursor-pointer">
                            <input type="checkbox" x-model="cols.category" class="rounded text-emerald-600"> <span>Category</span>
                        </label>
                        <label class="flex items-center gap-2 px-2 py-1 hover:bg-slate-50 cursor-pointer">
                            <input type="checkbox" x-model="cols.price" class="rounded text-emerald-600"> <span>Selling Price</span>
                        </label>
                        <label class="flex items-center gap-2 px-2 py-1 hover:bg-slate-50 cursor-pointer">
                            <input type="checkbox" x-model="cols.retail_val" class="rounded text-emerald-600"> <span>Retail Value</span>
                        </label>
                        <label class="flex items-center gap-2 px-2 py-1 hover:bg-slate-50 cursor-pointer">
                            <input type="checkbox" x-model="cols.sales" class="rounded text-emerald-600"> <span>Period Sales</span>
                        </label>
                        <?php if($financialAccess->canViewProductProfit()): ?>
                        <label class="flex items-center gap-2 px-2 py-1 hover:bg-slate-50 cursor-pointer">
                            <input type="checkbox" x-model="cols.cost" class="rounded text-emerald-600"> <span>Cost & Margin</span>
                        </label>
                        <?php endif; ?>
                        <label class="flex items-center gap-2 px-2 py-1 hover:bg-slate-50 cursor-pointer">
                            <input type="checkbox" x-model="cols.last_sale" class="rounded text-emerald-600"> <span>Last Sale Date</span>
                        </label>
                    </div>
                </div>

                
                <a href="<?php echo e(route('admin.advanced-analytics.export.csv', request()->query())); ?>"
                   class="inline-flex h-8 items-center gap-1.5 rounded-[6px] border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-700 hover:bg-slate-50">
                    <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                    <span>Export CSV</span>
                </a>
            </div>
        </div>

        
        <div class="overflow-x-auto" style="scrollbar-width: thin;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th class="w-12">Thumbnail</th>
                        <th>Product Name</th>
                        <th x-show="cols.sku">SKU</th>
                        <th x-show="cols.category">Category</th>
                        <th class="text-center">Stock</th>
                        <th>Stock Status</th>
                        <th x-show="cols.price" class="text-right">Price</th>
                        <th x-show="cols.retail_val" class="text-right">Retail Valuation</th>
                        <th x-show="cols.sales" class="text-center">Units Sold</th>
                        <th x-show="cols.sales" class="text-right">Revenue</th>
                        <?php if($financialAccess->canViewProductProfit()): ?>
                        <th x-show="cols.cost" class="text-right">Profit</th>
                        <?php endif; ?>
                        <th x-show="cols.last_sale">Last Sale</th>
                        <th class="text-right">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $stock = (int) $p->stock;
                            $sellPrice = (float) ($p->sale_price ?: $p->price);
                            $regPrice = (float) $p->price;
                            $costPrice = (float) $p->cost_price;
                            $unitsSold = (int) $p->period_units_sold;
                            $revenue = (float) $p->period_revenue;
                            $retailVal = $stock * $sellPrice;
                            $profit = ($costPrice > 0) ? round($revenue - ($unitsSold * $costPrice), 0) : null;

                            // Badging
                            $badgeVariant = 'success';
                            $statusLabel = 'In Stock';
                            if ($stock <= 0) {
                                $badgeVariant = 'destructive';
                                $statusLabel = 'Out of Stock';
                            } elseif ($stock <= (int) ($p->low_stock_alert ?? 10)) {
                                $badgeVariant = 'warning';
                                $statusLabel = 'Low Stock';
                            } elseif ($stock >= 100) {
                                $badgeVariant = 'neutral';
                                $statusLabel = 'Overstocked';
                            }

                            // Images
                            $firstImg = null;
                            if (is_array($p->images) && count($p->images) > 0) {
                                $firstImg = $p->images[0];
                            }
                        ?>
                        <tr>
                            
                            <td>
                                <div class="h-10 w-10 overflow-hidden rounded-[6px] border border-slate-200 bg-slate-50 flex items-center justify-center">
                                    <?php if($firstImg): ?>
                                        <img src="<?php echo e($firstImg); ?>" alt="" class="h-full w-full object-cover" onerror="this.src='/brandlogo.png'">
                                    <?php else: ?>
                                        <svg class="text-slate-300" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                                    <?php endif; ?>
                                </div>
                            </td>

                            
                            <td class="max-w-[280px]">
                                <a href="<?php echo e(route('admin.products.edit', $p->id)); ?>" class="font-semibold text-slate-900 hover:text-[#0f4d2c] line-clamp-2">
                                    <?php echo e($p->title); ?>

                                </a>
                                <div class="mt-0.5 flex items-center gap-2 text-[11px] text-slate-400">
                                    <span>ID: #<?php echo e($p->id); ?></span>
                                    <?php if($p->variants->isNotEmpty()): ?>
                                        <span class="inline-flex items-center rounded bg-slate-100 px-1.5 py-0.2 text-[10px] font-semibold text-slate-700">
                                            <?php echo e($p->variants->count()); ?> Variants
                                        </span>
                                    <?php endif; ?>
                                    <?php if($regPrice > $sellPrice): ?>
                                        <span class="text-rose-600 font-semibold">
                                            -<?php echo e(round((($regPrice - $sellPrice) / $regPrice) * 100)); ?>%
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </td>

                            
                            <td x-show="cols.sku" class="font-mono text-xs text-slate-600">
                                <?php echo e($p->sku ?: '—'); ?>

                            </td>

                            
                            <td x-show="cols.category" class="text-xs text-slate-600">
                                <?php echo e($p->category?->name ?? 'Uncategorized'); ?>

                            </td>

                            
                            <td class="text-center font-bold text-slate-900">
                                <?php echo e(number_format($stock)); ?>

                            </td>

                            
                            <td>
                                <?php if (isset($component)) { $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.badge','data' => ['variant' => $badgeVariant]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($badgeVariant)]); ?>
                                    <?php echo e($statusLabel); ?>

                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $attributes = $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $component = $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
                            </td>

                            
                            <td x-show="cols.price" class="text-right">
                                <span class="font-bold text-slate-900">৳<?php echo e(number_format($sellPrice, 0)); ?></span>
                                <?php if($regPrice > $sellPrice): ?>
                                    <div class="text-[10px] text-slate-400 line-through">৳<?php echo e(number_format($regPrice, 0)); ?></div>
                                <?php endif; ?>
                            </td>

                            
                            <td x-show="cols.retail_val" class="text-right font-medium text-slate-800">
                                ৳<?php echo e(number_format($retailVal, 0)); ?>

                            </td>

                            
                            <td x-show="cols.sales" class="text-center">
                                <?php if($unitsSold > 0): ?>
                                    <span class="font-bold text-emerald-700"><?php echo e(number_format($unitsSold)); ?></span>
                                <?php else: ?>
                                    <span class="text-slate-400">0</span>
                                <?php endif; ?>
                            </td>

                            
                            <td x-show="cols.sales" class="text-right">
                                <?php if($revenue > 0): ?>
                                    <span class="font-bold text-slate-900">৳<?php echo e(number_format($revenue, 0)); ?></span>
                                <?php else: ?>
                                    <span class="text-slate-400">—</span>
                                <?php endif; ?>
                            </td>

                            
                            <?php if($financialAccess->canViewProductProfit()): ?>
                            <td x-show="cols.cost" class="text-right">
                                <?php if($profit !== null): ?>
                                    <span class="<?php echo e($profit >= 0 ? 'text-emerald-700' : 'text-rose-700'); ?> font-bold">
                                        ৳<?php echo e(number_format($profit, 0)); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="text-[11px] text-slate-400" title="Cost price not specified on product">Unavailable</span>
                                <?php endif; ?>
                            </td>
                            <?php endif; ?>

                            
                            <td x-show="cols.last_sale" class="text-xs text-slate-500">
                                <?php if($p->last_sale_at): ?>
                                    <?php echo e(\Carbon\Carbon::parse($p->last_sale_at)->format('d M, Y')); ?>

                                <?php else: ?>
                                    <span class="text-slate-400">No sales</span>
                                <?php endif; ?>
                            </td>

                            
                            <td class="text-right">
                                <div class="inline-flex items-center gap-1">
                                    <?php if($p->variants->isNotEmpty()): ?>
                                        <button type="button"
                                                @click="openVariantDrilldown(<?php echo e($p->id); ?>)"
                                                class="rounded-[4px] border border-slate-200 bg-white px-2 py-1 text-[11px] font-semibold text-slate-700 hover:bg-slate-50"
                                                title="View Variant Details">
                                            Variants
                                        </button>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('admin.products.edit', $p->id)); ?>"
                                       class="rounded-[4px] p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                                       title="Edit Product">
                                        <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="13" class="py-12 text-center text-slate-400">
                                <div class="mx-auto max-w-sm">
                                    <svg class="mx-auto text-slate-300" width="36" height="36" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"/></svg>
                                    <p class="mt-2 font-semibold text-slate-700">No matching products found</p>
                                    <p class="mt-1 text-xs text-slate-500">Try adjusting your filters, stock status, or search terms.</p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        
        <?php if($products->hasPages()): ?>
            <div class="border-t border-slate-100 p-4">
                <?php echo e($products->links()); ?>

            </div>
        <?php endif; ?>
    </div>

    
    <div class="admin-surface p-5">
        <div class="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
                <h3 class="font-bold text-slate-900">Monthly & Historical Sales Analysis</h3>
                <p class="text-xs text-slate-500">12-Month performance breakdown for Year <?php echo e($monthlyAnalysis['year']); ?></p>
            </div>
            <form method="GET" action="<?php echo e(route('admin.advanced-analytics.index')); ?>" class="flex items-center gap-2">
                <input type="hidden" name="preset" value="month_year">
                <select name="year" class="admin-control text-xs" onchange="this.form.submit()">
                    <?php for($y = 2024; $y <= 2028; $y++): ?>
                        <option value="<?php echo e($y); ?>" <?php if($monthlyAnalysis['year'] == $y): echo 'selected'; endif; ?>><?php echo e($y); ?></option>
                    <?php endfor; ?>
                </select>
            </form>
        </div>

        <div class="mt-4 overflow-x-auto" style="scrollbar-width: thin;">
            <table class="w-full text-left text-xs">
                <thead>
                    <tr class="text-slate-400 uppercase text-[10px] border-b">
                        <th class="pb-2">Month</th>
                        <th class="pb-2 text-right">Gross Sales</th>
                        <th class="pb-2 text-right">Net Sales</th>
                        <th class="pb-2 text-center">Orders</th>
                        <th class="pb-2 text-center">Units Sold</th>
                        <th class="pb-2 text-right">MoM Growth</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__currentLoopData = $monthlyAnalysis['months']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="<?php echo e($mo['is_current'] ? 'bg-emerald-50/40 font-semibold' : ''); ?>">
                            <td class="py-2.5">
                                <?php echo e($mo['month_name']); ?>

                                <?php if($mo['is_current']): ?>
                                    <span class="ml-1 text-[10px] font-bold text-emerald-700">(Current)</span>
                                <?php endif; ?>
                            </td>
                            <td class="py-2.5 text-right text-slate-600">৳<?php echo e(number_format($mo['gross_sales'], 0)); ?></td>
                            <td class="py-2.5 text-right font-bold text-slate-900">৳<?php echo e(number_format($mo['net_sales'], 0)); ?></td>
                            <td class="py-2.5 text-center text-slate-700"><?php echo e(number_format($mo['orders_count'])); ?></td>
                            <td class="py-2.5 text-center text-slate-700"><?php echo e(number_format($mo['units_sold'])); ?></td>
                            <td class="py-2.5 text-right">
                                <?php if($mo['mom_growth'] !== null): ?>
                                    <span class="<?php echo e($mo['mom_growth'] >= 0 ? 'text-emerald-700' : 'text-rose-700'); ?> font-bold">
                                        <?php echo e($mo['mom_growth'] > 0 ? '+' : ''); ?><?php echo e($mo['mom_growth']); ?>%
                                    </span>
                                <?php else: ?>
                                    <span class="text-slate-400">—</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <?php if (isset($component)) { $__componentOriginal883972b03e56cea0994a1aaccc5761f0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal883972b03e56cea0994a1aaccc5761f0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.modal','data' => ['name' => 'pdfModalOpen','title' => 'Generate PDF Analytics Report','subtitle' => 'Configure report contents, layout, and filters']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'pdfModalOpen','title' => 'Generate PDF Analytics Report','subtitle' => 'Configure report contents, layout, and filters']); ?>
        <form id="analytics-pdf-report-form"
              x-ref="pdfReportForm"
              method="POST"
              action="<?php echo e(route('admin.advanced-analytics.export.pdf')); ?>"
              class="space-y-4"
              @submit.prevent="generatePdfReport()">
            <?php echo csrf_field(); ?>
            
            <input type="hidden" name="preset" value="<?php echo e($filters['preset']); ?>">
            <input type="hidden" name="start_date" value="<?php echo e($filters['start_date']->format('Y-m-d')); ?>">
            <input type="hidden" name="end_date" value="<?php echo e($filters['end_date']->format('Y-m-d')); ?>">
            <input type="hidden" name="month" value="<?php echo e($filters['month']); ?>">
            <input type="hidden" name="year" value="<?php echo e($filters['year']); ?>">
            <input type="hidden" name="category_id" value="<?php echo e($filters['category_id']); ?>">
            <input type="hidden" name="brand_id" value="<?php echo e($filters['brand_id']); ?>">
            <input type="hidden" name="product_id" value="<?php echo e($filters['product_id']); ?>">
            <input type="hidden" name="stock_status" value="<?php echo e($filters['stock_status']); ?>">
            <input type="hidden" name="product_status" value="<?php echo e($filters['product_status']); ?>">
            <input type="hidden" name="sort_by" value="<?php echo e($filters['sort_by']); ?>">
            <input type="hidden" name="search" value="<?php echo e($filters['search']); ?>">

            
            <div>
                <label for="pdf-report-type" class="block text-xs font-semibold text-slate-700">Report Type</label>
                <select id="pdf-report-type" name="report_type" required class="admin-control mt-1 w-full text-xs" :disabled="isGeneratingPdf">
                    <option value="complete">Complete Advanced Analytics Report</option>
                    <option value="executive">Executive Summary Report</option>
                    <option value="inventory">Inventory & Stock Valuation Report</option>
                    <option value="sales">Sales & Revenue Report</option>
                    <option value="pricing">Product Pricing & Discount Report</option>
                    <?php if($financialAccess->forExport()->canViewProfitMargin): ?>
                    <option value="profitability">Profitability & Margin Report</option>
                    <?php endif; ?>
                    <option value="reorder">Low Stock & Reorder Alert Report</option>
                    <option value="variants">Product & Variant Stock Report</option>
                </select>
            </div>

            
            <fieldset>
                <legend class="block text-xs font-semibold text-slate-700">Page Orientation</legend>
                <div class="mt-1 flex flex-wrap gap-x-4 gap-y-2 text-xs">
                    <label class="inline-flex items-center gap-2 cursor-pointer">
                        <input type="radio" name="orientation" value="landscape" checked required class="text-emerald-600" :disabled="isGeneratingPdf">
                        <span>Landscape (Recommended for wide tables)</span>
                    </label>
                    <label class="inline-flex items-center gap-2 cursor-pointer">
                        <input type="radio" name="orientation" value="portrait" class="text-emerald-600" :disabled="isGeneratingPdf">
                        <span>Portrait</span>
                    </label>
                </div>
            </fieldset>

            
            <div class="rounded-md bg-slate-50 p-3 text-xs text-slate-600">
                <p class="font-semibold text-slate-800">Applied Filter Context:</p>
                <p class="mt-1">Date Range: <?php echo e($filters['start_date']->format('d M, Y')); ?> — <?php echo e($filters['end_date']->format('d M, Y')); ?></p>
                <?php if($filters['category_id']): ?><p>Category: <?php echo e($categories->firstWhere('id', $filters['category_id'])?->name ?? '#'.$filters['category_id']); ?></p><?php endif; ?>
                <?php if($filters['brand_id']): ?><p>Brand: <?php echo e($brands->firstWhere('id', $filters['brand_id'])?->name ?? '#'.$filters['brand_id']); ?></p><?php endif; ?>
                <?php if($filters['stock_status'] !== 'all'): ?><p>Stock Status: <?php echo e(\Illuminate\Support\Str::headline($filters['stock_status'])); ?></p><?php endif; ?>
                <?php if($filters['product_status'] !== 'all'): ?><p>Catalog Status: <?php echo e(ucfirst($filters['product_status'])); ?></p><?php endif; ?>
                <?php if($filters['search'] !== ''): ?><p>Search: “<?php echo e($filters['search']); ?>”</p><?php endif; ?>
                <p class="text-[11px] text-slate-400 mt-1">Full Bengali text support (Hind Siliguri Unicode font) included.</p>
            </div>

            <p x-show="pdfError" x-cloak role="alert"
               class="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-xs font-medium text-red-700"
               x-text="pdfError"></p>
        </form>

         <?php $__env->slot('footer', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal60a020e5340f3f52bbc4501dc9f93102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.button','data' => ['variant' => 'outline','size' => 'sm','@click' => 'cancelPdfReport()']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'outline','size' => 'sm','@click' => 'cancelPdfReport()']); ?>
                Cancel
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $attributes = $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $component = $__componentOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal60a020e5340f3f52bbc4501dc9f93102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.button','data' => ['type' => 'submit','size' => 'sm','form' => 'analytics-pdf-report-form','xBind:disabled' => 'isGeneratingPdf','xBind:ariaBusy' => 'isGeneratingPdf ? \'true\' : \'false\'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','size' => 'sm','form' => 'analytics-pdf-report-form','x-bind:disabled' => 'isGeneratingPdf','x-bind:aria-busy' => 'isGeneratingPdf ? \'true\' : \'false\'']); ?>
                <svg x-show="isGeneratingPdf" x-cloak class="h-4 w-4 animate-spin" fill="none" viewBox="0 0 24 24" aria-hidden="true"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path></svg>
                <svg x-show="!isGeneratingPdf" width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
                <span x-text="isGeneratingPdf ? 'Generating PDF...' : 'Generate PDF Report'">Generate PDF Report</span>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $attributes = $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $component = $__componentOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal883972b03e56cea0994a1aaccc5761f0)): ?>
<?php $attributes = $__attributesOriginal883972b03e56cea0994a1aaccc5761f0; ?>
<?php unset($__attributesOriginal883972b03e56cea0994a1aaccc5761f0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal883972b03e56cea0994a1aaccc5761f0)): ?>
<?php $component = $__componentOriginal883972b03e56cea0994a1aaccc5761f0; ?>
<?php unset($__componentOriginal883972b03e56cea0994a1aaccc5761f0); ?>
<?php endif; ?>

    
    <div x-show="variantModalOpen" x-cloak
         class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
         x-transition.opacity>
        <div class="w-full max-w-2xl rounded-lg bg-white p-6 shadow-xl"
             @click.outside="variantModalOpen = false">
            <div class="flex items-start justify-between border-b pb-3">
                <div>
                    <h3 class="font-bold text-slate-900" x-text="selectedProduct?.title || 'Product Variants'"></h3>
                    <p class="text-xs text-slate-500">Live variant stock, price, and attributes breakdown</p>
                </div>
                <button type="button" @click="variantModalOpen = false" class="text-slate-400 hover:text-slate-600">
                    <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
            </div>

            <div class="mt-4">
                <div x-show="loadingVariants" class="py-8 text-center text-xs text-slate-400">
                    Loading variant data...
                </div>
                <div x-show="!loadingVariants">
                    <table class="w-full text-left text-xs">
                        <thead>
                            <tr class="text-slate-400 uppercase text-[10px] border-b">
                                <th class="pb-2">Variant</th>
                                <th class="pb-2">SKU</th>
                                <th class="pb-2 text-center">Stock</th>
                                <th class="pb-2 text-right">Price</th>
                                <th class="pb-2 text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            <template x-for="v in activeVariants" :key="v.id">
                                <tr>
                                    <td class="py-2.5 font-medium text-slate-800" x-text="v.name"></td>
                                    <td class="py-2.5 font-mono text-slate-600" x-text="v.sku"></td>
                                    <td class="py-2.5 text-center font-bold" :class="v.stock <= 0 ? 'text-rose-600' : 'text-slate-900'" x-text="v.stock"></td>
                                    <td class="py-2.5 text-right font-bold text-slate-900" x-text="'৳' + Number(v.price).toLocaleString()"></td>
                                    <td class="py-2.5 text-center">
                                        <span class="rounded px-2 py-0.5 text-[10px] font-bold"
                                              :class="v.stock > 0 ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'"
                                              x-text="v.stock > 0 ? 'In Stock' : 'Out of Stock'"></span>
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="mt-4 border-t pt-3 flex justify-end">
                <button type="button" @click="variantModalOpen = false" class="rounded-[6px] border px-4 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50">
                    Close
                </button>
            </div>
        </div>
    </div>

</div>

<script>
function advancedAnalyticsDashboard() {
    return {
        preset: '<?php echo e($filters['preset']); ?>',
        pdfModalOpen: false,
        isGeneratingPdf: false,
        pdfError: '',
        pdfAbortController: null,
        pdfReportTypes: <?php echo \Illuminate\Support\Js::from(array_keys(\App\Services\AdvancedAnalyticsReportService::REPORT_TITLES))->toHtml() ?>,
        variantModalOpen: false,
        loadingVariants: false,
        selectedProduct: null,
        activeVariants: [],
        cols: {
            sku: true,
            category: true,
            price: true,
            retail_val: true,
            sales: true,
            cost: true,
            last_sale: false,
        },
        init() {
            this.$watch('pdfModalOpen', (open) => {
                if (open) {
                    this.pdfError = '';
                } else {
                    this.pdfAbortController?.abort();
                }
            });
        },
        cancelPdfReport() {
            this.pdfAbortController?.abort();
            this.pdfModalOpen = false;
        },
        notify(message, type = 'success') {
            window.dispatchEvent(new CustomEvent('admin-toast', { detail: { message, type } }));
        },
        async pdfErrorMessage(response) {
            if (response.status === 419) {
                return 'Your session has expired. Refresh the page and try again.';
            }
            if (response.status === 403) {
                return 'You do not have permission to export this report.';
            }
            if (response.status === 422) {
                try {
                    const payload = await response.json();
                    const firstError = Object.values(payload.errors || {}).flat()[0];
                    return firstError || 'Please check the report options and try again.';
                } catch (e) {
                    return 'Please check the report options and try again.';
                }
            }
            return 'The PDF report could not be generated. Please try again.';
        },
        async generatePdfReport() {
            if (this.isGeneratingPdf) {
                return;
            }

            const form = this.$refs.pdfReportForm;
            const formData = new FormData(form);
            const reportType = formData.get('report_type');
            const orientation = formData.get('orientation');

            if (!this.pdfReportTypes.includes(reportType)) {
                this.pdfError = 'Choose a valid report type.';
                return;
            }
            if (!['landscape', 'portrait'].includes(orientation)) {
                this.pdfError = 'Choose a page orientation.';
                return;
            }

            this.pdfError = '';
            this.isGeneratingPdf = true;
            const controller = new AbortController();
            this.pdfAbortController = controller;

            try {
                const response = await fetch(form.action, {
                    method: 'POST',
                    body: formData,
                    credentials: 'same-origin',
                    signal: controller.signal,
                    headers: { 'Accept': 'application/pdf, application/json', 'X-Requested-With': 'XMLHttpRequest' },
                });

                if (!response.ok) {
                    this.pdfError = await this.pdfErrorMessage(response);
                    return;
                }

                const blob = await response.blob();
                const signature = await blob.slice(0, 5).text();
                if (!(response.headers.get('Content-Type') || '').includes('application/pdf') || signature !== '%PDF-') {
                    this.pdfError = 'The server returned an invalid PDF. Please try again.';
                    return;
                }

                const disposition = response.headers.get('Content-Disposition') || '';
                const filenameMatch = disposition.match(/filename\*?=(?:UTF-8'')?"?([^";]+)"?/i);
                const filename = filenameMatch ? decodeURIComponent(filenameMatch[1]) : `mamabazar-${reportType}-report.pdf`;

                const url = URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = filename;
                document.body.appendChild(link);
                link.click();
                link.remove();
                setTimeout(() => URL.revokeObjectURL(url), 60000);

                this.pdfModalOpen = false;
                this.notify(`PDF report download started: ${filename}`);
            } catch (error) {
                if (error.name !== 'AbortError') {
                    this.pdfError = 'The PDF report could not be generated. Check your connection and try again.';
                }
            } finally {
                if (this.pdfAbortController === controller) {
                    this.pdfAbortController = null;
                }
                this.isGeneratingPdf = false;
            }
        },
        openVariantDrilldown(productId) {
            this.variantModalOpen = true;
            this.loadingVariants = true;
            fetch(`/admin/advanced-analytics/products/${productId}/variants`, {
                headers: { 'Accept': 'application/json' }
            })
            .then(res => res.json())
            .then(data => {
                this.selectedProduct = data.product;
                this.activeVariants = data.variants;
                this.loadingVariants = false;
            })
            .catch(() => {
                this.loadingVariants = false;
            });
        }
    };
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', [
    'headerTitle' => 'Advanced Analytics & Inventory Intelligence',
    'title' => 'Advanced Analytics'
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/admin/advanced-analytics/index.blade.php ENDPATH**/ ?>