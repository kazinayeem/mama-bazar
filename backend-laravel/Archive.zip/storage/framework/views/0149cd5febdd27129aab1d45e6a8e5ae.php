<?php $__env->startSection('content'); ?>
<div class="admin-page" x-data="{
    editModalOpen: false,
    editingItem: {},
    openEdit(item) {
        this.editingItem = { ...item };
        this.editModalOpen = true;
    }
}">
    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Marketing','subtitle' => 'Pixels, tags, and campaign integrations']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Marketing','subtitle' => 'Pixels, tags, and campaign integrations']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <?php if($errors->any()): ?>
        <div role="alert" class="rounded-[8px] border border-red-200 bg-red-50 px-4 py-3 text-xs text-red-700">
            <p class="font-bold">Please fix the following:</p>
            <ul class="mt-1 list-disc pl-5"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
        </div>
    <?php endif; ?>

    <!-- Edit Integration Modal -->
    <?php if (isset($component)) { $__componentOriginal883972b03e56cea0994a1aaccc5761f0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal883972b03e56cea0994a1aaccc5761f0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.modal','data' => ['name' => 'editModalOpen','xTitle' => '\'Edit Integration: \' + (editingItem ? editingItem.name : \'\')','subtitle' => 'Update tracking ID, credentials, and script tags']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'editModalOpen','x-title' => '\'Edit Integration: \' + (editingItem ? editingItem.name : \'\')','subtitle' => 'Update tracking ID, credentials, and script tags']); ?>
        <form :action="'<?php echo e(url('admin/marketing')); ?>/' + (editingItem && editingItem.id ? editingItem.id : '')" method="POST" class="space-y-4">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="space-y-3">
                <div>
                    <label class="mb-1 block text-xs font-bold text-slate-700">Name *</label>
                    <input name="name" x-model="editingItem.name" required class="admin-control w-full text-sm">
                </div>
                <div>
                    <label class="mb-1 block text-xs font-bold text-slate-700">Type *</label>
                    <select name="type" x-model="editingItem.type" required class="admin-control w-full text-sm">
                        <option value="facebook_pixel">Facebook Pixel</option>
                        <option value="facebook_conversion_api">Facebook Conversions API (server)</option>
                        <option value="google_tag">Google Tag / GA</option>
                        <option value="google_tag_manager">Google Tag Manager</option>
                        <option value="google_analytics">Google Analytics 4</option>
                        <option value="tiktok_pixel">TikTok Pixel</option>
                        <option value="custom">Custom Script</option>
                    </select>
                </div>
                <div>
                    <label class="mb-1 block text-xs font-bold text-slate-700">Pixel / Tag ID</label>
                    <input name="pixel_id" x-model="editingItem.pixel_id" class="admin-control w-full text-sm font-mono">
                </div>
                <div>
                    <label class="mb-1 block text-xs font-bold text-slate-700">Script Code</label>
                    <textarea name="script_code" x-model="editingItem.script_code" rows="4" class="w-full rounded-[6px] border border-[var(--admin-border)] px-3 py-2.5 font-mono text-xs"></textarea>
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                        <label class="mb-1 block text-xs font-bold text-slate-700">Access Token</label>
                        <input name="access_token" x-model="editingItem.access_token" class="admin-control w-full text-sm">
                    </div>
                    <div>
                        <label class="mb-1 block text-xs font-bold text-slate-700">Test Event Code</label>
                        <input name="test_event_code" x-model="editingItem.test_event_code" class="admin-control w-full text-sm">
                    </div>
                </div>
                <div>
                    <label class="mb-1 block text-xs font-bold text-slate-700">Status</label>
                    <select name="status" x-model="editingItem.status" class="admin-control w-full text-sm">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
            </div>
            <div class="mt-6 flex items-center justify-end gap-3 border-t border-slate-100 pt-4">
                <?php if (isset($component)) { $__componentOriginal60a020e5340f3f52bbc4501dc9f93102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.button','data' => ['type' => 'button','variant' => 'outline','size' => 'sm','@click' => 'editModalOpen = false']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'button','variant' => 'outline','size' => 'sm','@click' => 'editModalOpen = false']); ?>Cancel <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $attributes = $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $component = $__componentOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal60a020e5340f3f52bbc4501dc9f93102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.button','data' => ['type' => 'submit','size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','size' => 'sm']); ?>Save Changes <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $attributes = $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $component = $__componentOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
            </div>
        </form>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal883972b03e56cea0994a1aaccc5761f0)): ?>
<?php $attributes = $__attributesOriginal883972b03e56cea0994a1aaccc5761f0; ?>
<?php unset($__attributesOriginal883972b03e56cea0994a1aaccc5761f0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal883972b03e56cea0994a1aaccc5761f0)): ?>
<?php $component = $__componentOriginal883972b03e56cea0994a1aaccc5761f0; ?>
<?php unset($__componentOriginal883972b03e56cea0994a1aaccc5761f0); ?>
<?php endif; ?>

    <div class="grid gap-4 lg:grid-cols-3">
        <div class="admin-surface p-4 h-fit">
            <h3 class="mb-4 text-sm font-bold">Add Integration</h3>
            <form action="<?php echo e(route('admin.marketing.store')); ?>" method="POST" class="space-y-3">
                <?php echo csrf_field(); ?>
                <div><label class="mb-1 block text-xs font-bold">Name *</label><input name="name" required class="admin-control w-full text-sm" placeholder="e.g. Meta Pixel Main"></div>
                <div>
                    <label class="mb-1 block text-xs font-bold">Type *</label>
                    <select name="type" required class="admin-control w-full text-sm">
                        <option value="facebook_pixel">Facebook Pixel</option>
                        <option value="facebook_conversion_api">Facebook Conversions API (server)</option>
                        <option value="google_tag">Google Tag / GA</option>
                        <option value="google_tag_manager">Google Tag Manager</option>
                        <option value="google_analytics">Google Analytics 4</option>
                        <option value="tiktok_pixel">TikTok Pixel</option>
                        <option value="custom">Custom Script</option>
                    </select>
                    <p class="mt-1 text-[11px] text-slate-400">For server Conversions API: set Pixel ID + Access Token on a <code>facebook_conversion_api</code> row.</p>
                </div>
                <div><label class="mb-1 block text-xs font-bold">Pixel / Tag ID</label><input name="pixel_id" class="admin-control w-full text-sm font-mono" placeholder="e.g. 1234567890"></div>
                <div><label class="mb-1 block text-xs font-bold">Script Code</label><textarea name="script_code" rows="3" class="w-full rounded-[6px] border border-[var(--admin-border)] px-3 py-2 font-mono text-xs"></textarea></div>
                <div><label class="mb-1 block text-xs font-bold">Access Token</label><input name="access_token" class="admin-control w-full text-sm"></div>
                <div><label class="mb-1 block text-xs font-bold">Test Event Code</label><input name="test_event_code" class="admin-control w-full text-sm"></div>
                <div>
                    <label class="mb-1 block text-xs font-bold">Status</label>
                    <select name="status" class="admin-control w-full text-sm">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
                <button class="inline-flex h-10 w-full items-center justify-center rounded-[6px] bg-brand-green-500 px-3.5 text-sm font-medium text-white hover:bg-brand-green-600">Save Integration</button>
            </form>
        </div>

        <div class="lg:col-span-2 admin-table-wrap">
            <div class="border-b px-4 py-3 text-xs font-bold uppercase tracking-wider text-slate-700">Active Integrations (<?php echo e($integrations->count()); ?>)</div>
            <table class="admin-table">
                <thead><tr><th>Name</th><th>Type</th><th>Pixel ID</th><th>Status</th><th class="text-right">Actions</th></tr></thead>
                <tbody class="divide-y">
                    <?php $__empty_1 = true; $__currentLoopData = $integrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="px-4 py-3 font-semibold"><?php echo e($item->name); ?></td>
                            <td class="px-4 py-3 text-xs uppercase text-slate-500"><?php echo e($item->type); ?></td>
                            <td class="px-4 py-3 font-mono text-xs"><?php echo e($item->pixel_id ?: '—'); ?></td>
                            <td class="px-4 py-3"><span class="inline-flex items-center rounded-[6px] border px-1.5 py-0.5 text-[10px] font-bold <?php echo e($item->status==='active' ? 'bg-brand-green-50 text-brand-green-700' : 'bg-slate-100 text-slate-500'); ?>"><?php echo e($item->status); ?></span></td>
                            <td class="px-4 py-3 text-right">
                                <div class="inline-flex items-center justify-end gap-1.5">
                                    <button type="button" @click="openEdit(<?php echo \Illuminate\Support\Js::from($item)->toHtml() ?>)" class="inline-flex items-center gap-1 rounded px-2 py-1 text-xs font-medium text-slate-600 hover:bg-slate-100 hover:text-slate-900">
                                        <svg class="h-3.5 w-3.5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                                        </svg>
                                        Edit
                                    </button>
                                    <form action="<?php echo e(route('admin.marketing.destroy', $item->id)); ?>" method="POST" onsubmit="return confirm('Delete?')" class="inline">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button class="rounded px-2 py-1 text-xs font-semibold text-red-600 hover:bg-red-50">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="px-4 py-12 text-center text-slate-500">No marketing integrations yet</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', ['headerTitle' => 'Marketing'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/admin/marketing/index.blade.php ENDPATH**/ ?>