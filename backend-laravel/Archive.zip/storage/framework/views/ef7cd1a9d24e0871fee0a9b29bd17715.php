<?php $__env->startSection('content'); ?>
<div class="admin-page max-w-3xl">
    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Email #'.$log->id,'subtitle' => $log->subject]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Email #'.$log->id),'subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($log->subject)]); ?>
         <?php $__env->slot('actions', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal60a020e5340f3f52bbc4501dc9f93102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.button','data' => ['href' => route('admin.email.logs.index'),'variant' => 'outline','size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.email.logs.index')),'variant' => 'outline','size' => 'sm']); ?>← Back to logs <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $attributes = $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $component = $__componentOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
            <?php if($log->isRetryable()): ?>
                <form action="<?php echo e(route('admin.email.logs.retry', $log->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php if (isset($component)) { $__componentOriginal60a020e5340f3f52bbc4501dc9f93102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.button','data' => ['type' => 'submit','size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','size' => 'sm']); ?>Retry <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $attributes = $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $component = $__componentOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
                </form>
            <?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <div class="admin-surface p-5">
        <dl class="grid grid-cols-1 gap-3 text-sm sm:grid-cols-3">
            <dt class="text-slate-500">Status</dt><dd class="sm:col-span-2"><?php echo $__env->make('admin.email.partials.status-badge', ['status' => $log->status], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></dd>
            <dt class="text-slate-500">Recipient</dt><dd class="sm:col-span-2"><?php echo e($log->recipient_name ? $log->recipient_name.' · ' : ''); ?><?php echo e($log->recipient_email); ?></dd>
            <dt class="text-slate-500">Type</dt><dd class="sm:col-span-2"><?php echo e(\App\Models\EmailLog::TYPES[$log->email_type] ?? $log->email_type); ?></dd>
            <dt class="text-slate-500">Template</dt><dd class="sm:col-span-2 font-mono text-xs"><?php echo e($log->template_key ?: '—'); ?></dd>
            <?php if($log->order): ?>
                <dt class="text-slate-500">Order</dt><dd class="sm:col-span-2"><a href="<?php echo e(route('admin.orders.show', $log->order_id)); ?>" class="text-brand-green-700 hover:underline"><?php echo e($log->order->order_id); ?></a></dd>
            <?php endif; ?>
            <?php if($log->campaign): ?>
                <dt class="text-slate-500">Campaign</dt><dd class="sm:col-span-2"><a href="<?php echo e(route('admin.email.campaigns.show', $log->campaign_id)); ?>" class="text-brand-green-700 hover:underline"><?php echo e($log->campaign->name); ?></a></dd>
            <?php endif; ?>
            <dt class="text-slate-500">Created</dt><dd class="sm:col-span-2"><?php echo e($log->created_at?->format('d M Y, h:i:s A')); ?></dd>
            <dt class="text-slate-500">Last attempt</dt><dd class="sm:col-span-2"><?php echo e($log->last_attempt_at?->format('d M Y, h:i:s A') ?? '—'); ?></dd>
            <dt class="text-slate-500">Accepted by SMTP</dt><dd class="sm:col-span-2"><?php echo e($log->sent_at?->format('d M Y, h:i:s A') ?? '—'); ?></dd>
            <dt class="text-slate-500">Attempts</dt><dd class="sm:col-span-2"><?php echo e($log->attempts); ?></dd>
            <dt class="text-slate-500">Message ID</dt><dd class="sm:col-span-2 font-mono text-xs break-all"><?php echo e($log->message_id ?: '—'); ?></dd>
            <?php if(! empty($log->metadata['attachments'])): ?>
                <dt class="text-slate-500">Attachments</dt><dd class="sm:col-span-2 text-xs"><?php echo e(implode(', ', (array) $log->metadata['attachments'])); ?></dd>
            <?php endif; ?>
            <?php if(! empty($log->metadata['invoice_attachment_failed'])): ?>
                <dt class="text-slate-500">Invoice PDF</dt><dd class="sm:col-span-2 text-xs text-amber-700">PDF generation failed — the email was sent without the attachment. Use “Email Invoice” on the order to resend.</dd>
            <?php endif; ?>
        </dl>
        <?php if($log->error_message): ?>
            <div class="mt-4 rounded-[6px] border border-red-200 bg-red-50 p-3 text-xs text-red-700 break-words">
                <strong>Error:</strong> <?php echo e($log->error_message); ?>

            </div>
        <?php endif; ?>
        <p class="mt-4 text-[11px] text-slate-400">Email bodies are not stored. Errors are sanitized — credentials, OTP codes and reset links are never recorded.</p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', ['headerTitle' => 'Email Log'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/admin/email/log-show.blade.php ENDPATH**/ ?>