<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title><?php echo e($reportTitle); ?> — MamaBazar</title>
<style>
    @page {
        size: A4 <?php echo e($options['orientation'] ?? 'landscape'); ?>;
        margin: 10mm 10mm 12mm 10mm;
    }
    body {
        font-family: 'Hind Siliguri', 'DejaVu Sans', sans-serif;
        font-size: 10px;
        color: #1e293b;
        line-height: 1.4;
        margin: 0;
        padding: 0;
    }
    .header-table {
        width: 100%;
        border-bottom: 2px solid #0f4d2c;
        padding-bottom: 8px;
        margin-bottom: 12px;
    }
    .header-table td {
        vertical-align: top;
    }
    .brand-title {
        font-size: 18px;
        font-weight: bold;
        color: #0f4d2c;
    }
    .brand-meta {
        font-size: 9px;
        color: #64748b;
        margin-top: 2px;
    }
    .report-title-box {
        text-align: right;
    }
    .report-title {
        font-size: 16px;
        font-weight: bold;
        color: #0f4d2c;
        margin: 0;
    }
    .report-badge {
        display: inline-block;
        background: #f1f5f9;
        color: #334155;
        padding: 2px 6px;
        border-radius: 4px;
        font-size: 8.5px;
        font-weight: 600;
        margin-top: 3px;
    }
    .section-title {
        font-size: 11px;
        font-weight: bold;
        color: #0f4d2c;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border-bottom: 1px solid #cbd5e1;
        padding-bottom: 4px;
        margin-top: 14px;
        margin-bottom: 6px;
    }
    .kpi-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 10px;
    }
    .kpi-table td {
        padding: 6px 8px;
        border: 1px solid #e2e8f0;
        background: #ffffff;
        vertical-align: top;
    }
    .kpi-label {
        font-size: 8.5px;
        color: #64748b;
        text-transform: uppercase;
        letter-spacing: 0.4px;
        font-weight: 600;
    }
    .kpi-value {
        font-size: 14px;
        font-weight: bold;
        color: #0f172a;
        margin-top: 2px;
    }
    .kpi-sub {
        font-size: 8px;
        color: #94a3b8;
        margin-top: 1px;
    }
    .data-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 6px;
        margin-bottom: 12px;
        font-size: 9px;
    }
    .data-table thead th {
        background: #0f4d2c;
        color: #ffffff;
        padding: 5px 6px;
        font-size: 8.5px;
        text-transform: uppercase;
        letter-spacing: 0.3px;
        text-align: left;
    }
    .data-table tbody td {
        padding: 5px 6px;
        border-bottom: 1px solid #e2e8f0;
        vertical-align: middle;
    }
    .data-table tbody tr:nth-child(even) td {
        background: #f8fafc;
    }
    .text-right { text-align: right; }
    .text-center { text-align: center; }
    .text-emerald { color: #15803d; font-weight: 600; }
    .text-amber { color: #b45309; font-weight: 600; }
    .text-rose { color: #be123c; font-weight: 600; }
    .badge {
        display: inline-block;
        padding: 2px 5px;
        border-radius: 3px;
        font-size: 8px;
        font-weight: bold;
    }
    .badge-in { background: #dcfce7; color: #15803d; }
    .badge-low { background: #fef3c7; color: #b45309; }
    .badge-out { background: #fee2e2; color: #b91c1c; }
    .badge-over { background: #e0e7ff; color: #4338ca; }
    .notes-box {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-left: 3px solid #0f4d2c;
        padding: 6px 10px;
        font-size: 8px;
        color: #475569;
        margin-top: 10px;
        line-height: 1.4;
    }
    .footer {
        position: fixed;
        bottom: -8mm;
        left: 0;
        right: 0;
        font-size: 8px;
        color: #94a3b8;
        border-top: 1px solid #e2e8f0;
        padding-top: 4px;
        text-align: center;
    }
    thead { display: table-header-group; }
    tr { page-break-inside: avoid; }
</style>
</head>
<body>

<div class="footer">
    MamaBazar Enterprise Analytics & Inventory Intelligence — Generated on <?php echo e($generatedAt); ?> by <?php echo e($generatedBy); ?>

</div>

<table class="header-table">
    <tr>
        <td style="width: 55%;">
            <?php if(!empty($store['logo_base64'])): ?>
                <img src="<?php echo e($store['logo_base64']); ?>" style="height: 32px; width: 32px; vertical-align: middle; margin-right: 6px;" alt="">
            <?php endif; ?>
            <span class="brand-title"><?php echo e($store['name'] ?? 'MamaBazar'); ?></span>
            <div class="brand-meta">
                <?php echo e($store['address'] ?? 'Online E-Commerce Platform'); ?> | Phone: <?php echo e($store['phone'] ?? '+880'); ?> | Email: <?php echo e($store['email'] ?? 'support@mama-bazar.com'); ?>

            </div>
        </td>
        <td class="report-title-box" style="width: 45%;">
            <h1 class="report-title"><?php echo e($reportTitle); ?></h1>
            <div class="report-badge">
                Period: <?php echo e($filters['start_date']->format('d M, Y')); ?> — <?php echo e($filters['end_date']->format('d M, Y')); ?> (<?php echo e($filters['preset']); ?>)
            </div>
            <?php if(!empty($appliedFilters)): ?>
                <div style="font-size: 8px; color: #334155; margin-top: 3px;">
                    Filters: <?php echo e(implode(' | ', $appliedFilters)); ?>

                </div>
            <?php endif; ?>
            <div style="font-size: 8px; color: #64748b; margin-top: 3px;">
                Generated: <?php echo e($generatedAt); ?> | Admin: <?php echo e($generatedBy); ?>

            </div>
        </td>
    </tr>
</table>


<div class="section-title">1. Executive Overview & Inventory Valuation</div>
<table class="kpi-table">
    <tr>
        <td style="width: 25%;">
            <div class="kpi-label">Active Products & Variants</div>
            <div class="kpi-value"><?php echo e(number_format($inventoryKpis['active_products'])); ?> / <?php echo e(number_format($inventoryKpis['total_products'])); ?></div>
            <div class="kpi-sub">Variants: <?php echo e(number_format($inventoryKpis['active_variants'])); ?> active</div>
        </td>
        <td style="width: 25%;">
            <div class="kpi-label">Units in Stock</div>
            <div class="kpi-value"><?php echo e(number_format($inventoryKpis['total_units_in_stock'])); ?></div>
            <div class="kpi-sub">
                Low: <span class="text-amber"><?php echo e($inventoryKpis['low_stock_count']); ?></span> | 
                Out: <span class="text-rose"><?php echo e($inventoryKpis['out_of_stock_count']); ?></span>
            </div>
        </td>
        <td style="width: 25%;">
            <div class="kpi-label">Potential Retail Valuation</div>
            <div class="kpi-value">৳<?php echo e(number_format($inventoryKpis['retail_valuation'], 0)); ?></div>
            <div class="kpi-sub">Based on present selling prices</div>
        </td>
        <td style="width: 25%;">
            <div class="kpi-label">Inventory Valuation at Cost</div>
            <?php if(! $financialAccess->canViewCostValuation): ?>
            <div class="kpi-value"><span style="font-size: 10px; color: #94a3b8;">Not included</span></div>
            <div class="kpi-sub">Requires cost report permission</div>
            <?php else: ?>
            <div class="kpi-value">
                <?php if($inventoryKpis['cost_valuation'] !== null): ?>
                    ৳<?php echo e(number_format($inventoryKpis['cost_valuation'], 0)); ?>

                <?php else: ?>
                    <span style="font-size: 10px; color: #94a3b8;">Cost data unavailable</span>
                <?php endif; ?>
            </div>
            <div class="kpi-sub">
                <?php if($inventoryKpis['unrealized_margin'] !== null): ?>
                    Est. Margin: <span class="text-emerald"><?php echo e($inventoryKpis['unrealized_margin']); ?>%</span>
                <?php else: ?>
                    Coverage: <?php echo e($inventoryKpis['cost_coverage_pct']); ?>% of products
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </td>
    </tr>
    <tr>
        <td>
            <div class="kpi-label">Gross Sales (Period)</div>
            <div class="kpi-value">৳<?php echo e(number_format($salesKpis['gross_sales'], 0)); ?></div>
            <div class="kpi-sub">
                Growth: 
                <?php if($salesKpis['gross_sales_growth'] !== null): ?>
                    <span class="<?php echo e($salesKpis['gross_sales_growth'] >= 0 ? 'text-emerald' : 'text-rose'); ?>"><?php echo e($salesKpis['gross_sales_growth'] > 0 ? '+' : ''); ?><?php echo e($salesKpis['gross_sales_growth']); ?>%</span>
                <?php else: ?>
                    —
                <?php endif; ?>
            </div>
        </td>
        <td>
            <div class="kpi-label">Net Sales (Valid Orders)</div>
            <div class="kpi-value">৳<?php echo e(number_format($salesKpis['net_sales'], 0)); ?></div>
            <div class="kpi-sub">
                Growth: 
                <?php if($salesKpis['sales_growth'] !== null): ?>
                    <span class="<?php echo e($salesKpis['sales_growth'] >= 0 ? 'text-emerald' : 'text-rose'); ?>"><?php echo e($salesKpis['sales_growth'] > 0 ? '+' : ''); ?><?php echo e($salesKpis['sales_growth']); ?>%</span>
                <?php else: ?>
                    —
                <?php endif; ?>
            </div>
        </td>
        <td>
            <div class="kpi-label">Orders & Units Sold</div>
            <div class="kpi-value"><?php echo e(number_format($salesKpis['orders_count'])); ?> / <?php echo e(number_format($salesKpis['units_sold'])); ?></div>
            <div class="kpi-sub">AOV: ৳<?php echo e(number_format($salesKpis['avg_order_value'], 0)); ?></div>
        </td>
        <td>
            <div class="kpi-label">Gross Profit & Margin</div>
            <?php if(! $financialAccess->canViewProfitMargin): ?>
            <div class="kpi-value"><span style="font-size: 10px; color: #94a3b8;">Not included</span></div>
            <div class="kpi-sub">Requires profit report permission</div>
            <?php else: ?>
            <div class="kpi-value">
                <?php if($salesKpis['gross_profit'] !== null): ?>
                    ৳<?php echo e(number_format($salesKpis['gross_profit'], 0)); ?>

                    <span style="font-size: 10px; color: #15803d;">(<?php echo e($salesKpis['gross_margin_pct']); ?>%)</span>
                <?php else: ?>
                    <span style="font-size: 10px; color: #94a3b8;">Cost data unavailable</span>
                <?php endif; ?>
            </div>
            <div class="kpi-sub">
                <?php if($salesKpis['profit_status'] === 'partial'): ?>
                    Partial: <?php echo e($salesKpis['items_with_cost']); ?> of <?php echo e($salesKpis['total_items_sold_count']); ?> items
                <?php elseif($salesKpis['profit_status'] === 'exact'): ?>
                    100% item cost verified
                <?php else: ?>
                    COGS missing on products
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </td>
    </tr>
</table>


<?php if(!empty($chartsData['category_inventory'])): ?>
<div class="section-title">2. Category Inventory & Valuation Breakdown</div>
<table class="data-table">
    <thead>
        <tr>
            <th>Category Name</th>
            <th class="text-center">Products</th>
            <th class="text-center">Current Stock</th>
            <th class="text-right">Potential Retail Value</th>
            <?php if($financialAccess->canViewCostValuation): ?>
            <th class="text-right">Inventory Cost Value</th>
            <?php endif; ?>
            <?php if($financialAccess->canViewCostValuation && $financialAccess->canViewProfitMargin): ?>
            <th class="text-right">Est. Margin</th>
            <?php endif; ?>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $chartsData['category_inventory']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $costValue = (float) ($cat['cost_value'] ?? 0);
                $margin = ($cat['retail_value'] > 0 && $costValue > 0)
                    ? round((($cat['retail_value'] - $costValue) / $cat['retail_value']) * 100, 1)
                    : null;
            ?>
            <tr>
                <td><strong><?php echo e($cat['category']); ?></strong></td>
                <td class="text-center"><?php echo e(number_format($cat['products'])); ?></td>
                <td class="text-center font-bold"><?php echo e(number_format($cat['stock'])); ?></td>
                <td class="text-right">৳<?php echo e(number_format($cat['retail_value'], 0)); ?></td>
                <?php if($financialAccess->canViewCostValuation): ?>
                <td class="text-right">
                    <?php echo e($costValue > 0 ? '৳'.number_format($costValue, 0) : '—'); ?>

                </td>
                <?php endif; ?>
                <?php if($financialAccess->canViewCostValuation && $financialAccess->canViewProfitMargin): ?>
                <td class="text-right">
                    <?php echo e($margin !== null ? $margin.'%' : '—'); ?>

                </td>
                <?php endif; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php endif; ?>


<div class="section-title">3. Product Performance & Stock Status (<?php echo e(count($products)); ?> Records)</div>
<table class="data-table">
    <thead>
        <tr>
            <th style="width: 28%;">Product Name</th>
            <th>SKU</th>
            <th>Category</th>
            <th class="text-center">Stock</th>
            <th>Status</th>
            <th class="text-right">Selling Price</th>
            <?php if($financialAccess->canViewCostPrice): ?>
            <th class="text-right">Cost Price</th>
            <?php endif; ?>
            <th class="text-center">Units Sold</th>
            <th class="text-right">Revenue</th>
            <?php if($financialAccess->canViewProductProfit()): ?>
            <th class="text-right">Profit</th>
            <?php endif; ?>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $stock = (int) $p->stock;
                $sellPrice = (float) ($p->sale_price ?: $p->price);
                $costPrice = (float) $p->cost_price;
                $units = (int) $p->period_units_sold;
                $revenue = (float) $p->period_revenue;
                $profit = ($costPrice > 0) ? round($revenue - ($units * $costPrice), 0) : null;

                $badgeClass = 'badge-in';
                $badgeText = 'In Stock';
                if ($stock <= 0) {
                    $badgeClass = 'badge-out';
                    $badgeText = 'Out of Stock';
                } elseif ($stock <= (int) ($p->low_stock_alert ?? 10)) {
                    $badgeClass = 'badge-low';
                    $badgeText = 'Low Stock';
                } elseif ($stock >= 100) {
                    $badgeClass = 'badge-over';
                    $badgeText = 'Overstocked';
                }
            ?>
            <tr>
                <td>
                    <strong><?php echo e($p->title); ?></strong>
                    <?php if($p->variants->isNotEmpty()): ?>
                        <div style="font-size: 7.5px; color: #64748b;"><?php echo e($p->variants->count()); ?> Variants</div>
                    <?php endif; ?>
                </td>
                <td style="font-family: monospace; font-size: 8px;"><?php echo e($p->sku ?: '—'); ?></td>
                <td><?php echo e($p->category?->name ?? 'Uncategorized'); ?></td>
                <td class="text-center"><strong><?php echo e($stock); ?></strong></td>
                <td><span class="badge <?php echo e($badgeClass); ?>"><?php echo e($badgeText); ?></span></td>
                <td class="text-right">৳<?php echo e(number_format($sellPrice, 0)); ?></td>
                <?php if($financialAccess->canViewCostPrice): ?>
                <td class="text-right"><?php echo e($costPrice > 0 ? '৳'.number_format($costPrice, 0) : '—'); ?></td>
                <?php endif; ?>
                <td class="text-center"><?php echo e(number_format($units)); ?></td>
                <td class="text-right">৳<?php echo e(number_format($revenue, 0)); ?></td>
                <?php if($financialAccess->canViewProductProfit()): ?>
                <td class="text-right">
                    <?php if($profit !== null): ?>
                        <span class="<?php echo e($profit >= 0 ? 'text-emerald' : 'text-rose'); ?>">৳<?php echo e(number_format($profit, 0)); ?></span>
                    <?php else: ?>
                        <span style="color: #94a3b8;">—</span>
                    <?php endif; ?>
                </td>
                <?php endif; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="10" class="text-center" style="padding: 16px; color: #94a3b8;">
                    No product records matching current filter selection.
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>


<div class="notes-box">
    <strong>Data & Business Logic Notes:</strong><br>
    1. <em>Inventory Snapshot:</em> Current stock quantities and inventory valuations reflect the present system state as of <?php echo e($generatedAt); ?> and are not reconstructed historical records.<br>
    2. <em>Net Sales & Orders:</em> Net sales include valid orders only and exclude cancelled, refunded, and returned orders.<br>
    3. <em>Profitability & Cost Data:</em> Gross profit and cost valuation are computed strictly from confirmed purchase/cost prices recorded on products. Items lacking recorded cost are labeled as unavailable rather than assuming zero cost.
</div>

</body>
</html>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/admin/advanced-analytics/pdf-report.blade.php ENDPATH**/ ?>