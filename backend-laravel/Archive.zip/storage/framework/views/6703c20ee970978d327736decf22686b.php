<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($headerTitle ?? ($title ?? 'Dashboard')); ?> — Mama Bazar Admin</title>
    <link rel="icon" type="image/png" href="/brandlogo.png">
    <link rel="preload" href="/fonts/inter-400-normal.woff2" as="font" type="font/woff2" crossorigin>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="admin-shell flex h-screen overflow-hidden font-body antialiased"
      x-data="adminShell()"
      x-init="init()"
      @keydown.window="onKey($event)"
      @keydown.escape.window="mobileOpen = false">

    <?php
        $adminNavSections = \App\Support\AdminNav::sections();
        $allAdminNavItems = \App\Support\AdminNav::allItems();
    ?>

    
    <div x-show="mobileOpen" x-cloak
         class="fixed inset-0 z-[200] bg-black/50 md:hidden"
         @click="mobileOpen = false"
         x-transition.opacity></div>

    
    <aside class="admin-sidebar fixed inset-y-0 left-0 z-[201] transition-transform duration-200 ease-out md:static md:translate-x-0"
           :class="[
               mobileOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0',
               collapsed ? 'is-collapsed' : '',
           ]"
           :style="collapsed ? 'width: var(--admin-sidebar-collapsed)' : 'width: var(--admin-sidebar-w)'"
           aria-label="Admin navigation">

        
        <div class="admin-sidebar__brand relative">
            <button type="button" @click="mobileOpen = false"
                    class="absolute right-2.5 top-1/2 -translate-y-1/2 rounded-[6px] p-1.5 text-slate-400 hover:bg-slate-100 md:hidden"
                    aria-label="Close sidebar">
                <svg width="16" height="16" class="admin-sidebar-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                </svg>
            </button>
            <div class="admin-sidebar__logo">
                <?php if (isset($component)) { $__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icon','data' => ['name' => 'store','size' => 18]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'store','size' => 18]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd)): ?>
<?php $attributes = $__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd; ?>
<?php unset($__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd)): ?>
<?php $component = $__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd; ?>
<?php unset($__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd); ?>
<?php endif; ?>
            </div>
            <div class="min-w-0" x-show="!collapsed">
                <p class="truncate text-sm font-bold leading-tight text-slate-900">MamaBazar</p>
                <div class="mt-0.5 flex items-center gap-1.5">
                    <?php $isSuper = in_array(auth()->user()->role ?? '', ['super_admin', 'admin']); ?>
                    <span class="inline-block h-1.5 w-1.5 rounded-full <?php echo e($isSuper ? 'bg-amber-500' : 'bg-emerald-500'); ?>"></span>
                    <p class="truncate text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                        <?php echo e(auth()->user()->custom_role ?? auth()->user()->role ?? 'Admin'); ?>

                    </p>
                </div>
            </div>
        </div>

        
        <nav class="admin-sidebar__nav">
            <?php $__currentLoopData = $adminNavSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $sectionActive = collect($section['items'])->contains(fn($item) => request()->routeIs($item['match'])); ?>
                <div class="admin-sidebar__section" x-data="{ open: true }">
                    <button type="button"
                            @click="if(!collapsed) open = !open"
                            class="admin-sidebar__section-label"
                            :class="{
                                'justify-center': collapsed,
                                'is-active': <?php echo e($sectionActive ? 'true' : 'false'); ?>

                            }">
                        <span class="flex-1 text-left" x-show="!collapsed"><?php echo e($section['label']); ?></span>
                        <svg x-show="!collapsed" width="12" height="12" class="admin-sidebar-icon transition-transform" :class="open && 'rotate-180'" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                        </svg>
                        <?php if($sectionActive): ?>
                            <span x-show="collapsed" class="block h-1.5 w-1.5 rounded-full bg-brand-green-500"></span>
                        <?php endif; ?>
                    </button>

                    <div x-show="open || collapsed" class="mt-0.5 space-y-0.5">
                        <?php $__currentLoopData = $section['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $active = request()->routeIs($item['match']);
                                if (($item['params']['tab'] ?? null) === 'profit') {
                                    $active = $active && request('tab') === 'profit';
                                } elseif (($item['label'] ?? '') === 'Expense Reports') {
                                    $active = $active && request('tab') !== 'profit';
                                } elseif (($item['label'] ?? '') === 'Returns & Refunds') {
                                    $active = $active && in_array(request('status'), ['cancelled', 'refunded', 'returned'], true);
                                } elseif (($item['label'] ?? '') === 'Orders') {
                                    $active = $active && !in_array(request('status'), ['cancelled', 'refunded', 'returned'], true);
                                }
                                $url = route($item['route'], $item['params'] ?? []);
                                if (!empty($item['fragment'])) {
                                    $url .= '#' . $item['fragment'];
                                }
                            ?>
                            <a href="<?php echo e($url); ?>"
                               title="<?php echo e($item['label']); ?>"
                               @click="mobileOpen = false"
                               class="admin-sidebar__link <?php echo e($active ? 'is-active' : ''); ?>">
                                <?php if (isset($component)) { $__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.icon','data' => ['name' => $item['icon'],'size' => 18]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item['icon']),'size' => 18]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd)): ?>
<?php $attributes = $__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd; ?>
<?php unset($__attributesOriginal906aaa6a63a2f5f8b29c23c3195c96dd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd)): ?>
<?php $component = $__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd; ?>
<?php unset($__componentOriginal906aaa6a63a2f5f8b29c23c3195c96dd); ?>
<?php endif; ?>
                                <span class="truncate" x-show="!collapsed"><?php echo e($item['label']); ?></span>
                                <?php if(!empty($item['badge'])): ?>
                                    <span x-show="!collapsed" class="ml-auto inline-flex min-w-[1.25rem] items-center justify-center rounded-full bg-brand-orange-500 px-1.5 py-px text-[10px] font-bold leading-4 text-white"><?php echo e($item['badge'] > 99 ? '99+' : $item['badge']); ?></span>
                                <?php endif; ?>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>

        
        <div class="admin-sidebar__footer">
            <div class="admin-sidebar__footer-chip">
                <span x-show="!collapsed">MamaBazar Admin v1.0 · <a href="https://bornosoft.bd/" target="_blank" rel="noopener" class="underline decoration-slate-300 underline-offset-2 hover:text-slate-600">Bornosoft</a></span>
                <span x-show="collapsed">v1.0</span>
            </div>
        </div>
    </aside>

    
    <div class="admin-main">
        <header class="sticky top-0 z-40 flex h-14 shrink-0 items-center gap-2.5 border-b border-[var(--admin-border)] bg-white/95 px-3 backdrop-blur sm:px-5">
            <button type="button" @click="mobileOpen = true" class="rounded-[6px] p-2 text-slate-500 hover:bg-slate-100 md:hidden" aria-label="Open sidebar">
                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
            </button>
            <button type="button" @click="toggleCollapse()" class="hidden rounded-[6px] p-2 text-slate-500 hover:bg-slate-100 md:inline-flex" aria-label="Toggle sidebar">
                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
            </button>

            <div class="hidden items-center gap-1.5 text-sm md:flex">
                <span class="text-xs text-slate-400">Admin</span>
                <svg width="14" height="14" class="text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                <span class="text-sm font-semibold text-slate-800"><?php echo e($headerTitle ?? 'Dashboard'); ?></span>
            </div>

            <div class="flex-1 min-w-0"></div>

            <button type="button" @click="commandOpen = true"
                    class="hidden items-center gap-2 rounded-[6px] border border-[var(--admin-border)] bg-[var(--admin-muted)] px-2.5 py-1.5 text-sm text-slate-400 hover:bg-slate-100 sm:flex">
                <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                <span class="hidden text-xs lg:inline">Search…</span>
                <kbd class="ml-1 rounded border border-slate-200 bg-white px-1.5 py-0.5 font-mono text-[10px] text-slate-400">⌘K</kbd>
            </button>

            <?php
                $pendingNotifs = \App\Models\Order::whereIn('status', ['pending', 'payment_pending'])->orderByDesc('id')->limit(5)->get();
                $lowStockNotifs = \App\Models\Product::where('track_inventory', true)->where('stock', '>', 0)->where('stock', '<=', 10)->orderBy('stock')->limit(3)->get();
                $notifCount = $pendingNotifs->count() + $lowStockNotifs->count();
            ?>
            <div class="relative" x-data="{ notifOpen: false }">
                <button type="button" @click="notifOpen = !notifOpen" @click.away="notifOpen = false"
                        class="relative rounded-[6px] p-2 text-slate-500 hover:bg-slate-100">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
                    <?php if($notifCount > 0): ?>
                        <span class="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-red-500"></span>
                    <?php endif; ?>
                </button>
                <div x-show="notifOpen" x-cloak x-transition
                     class="absolute right-0 z-50 mt-2 w-80 overflow-hidden rounded-[10px] border border-[var(--admin-border)] bg-white shadow-panel">
                    <div class="flex h-11 items-center justify-between border-b border-[var(--admin-border)] px-3">
                        <span class="text-sm font-bold">Notifications</span>
                        <span class="rounded-[6px] bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-500"><?php echo e($notifCount); ?></span>
                    </div>
                    <div class="max-h-80 overflow-y-auto">
                        <?php $__empty_1 = true; $__currentLoopData = $pendingNotifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <a href="<?php echo e(route('admin.orders.show', $o->id)); ?>" class="flex gap-3 border-b border-slate-50 px-4 py-3 text-sm hover:bg-slate-50">
                                <span class="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-brand-green-500"></span>
                                <div>
                                    <p class="font-semibold">Order <?php echo e($o->order_id); ?></p>
                                    <p class="text-xs text-slate-500"><?php echo e($o->customer_name); ?> · <?php echo e($o->status); ?></p>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                        <?php $__currentLoopData = $lowStockNotifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('admin.inventory.index', ['filter' => 'low'])); ?>" class="flex gap-3 border-b border-slate-50 px-4 py-3 text-sm hover:bg-slate-50">
                                <span class="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-amber-500"></span>
                                <div>
                                    <p class="font-semibold">Low stock: <?php echo e(\Illuminate\Support\Str::limit($p->title, 28)); ?></p>
                                    <p class="text-xs text-slate-500"><?php echo e($p->stock); ?> left</p>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($notifCount === 0): ?>
                            <div class="px-4 py-6 text-center text-xs text-slate-400">No new notifications</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="relative" x-data="{ userMenu: false }">
                <button type="button" @click="userMenu = !userMenu" @click.away="userMenu = false"
                        class="flex h-8 w-8 items-center justify-center rounded-full bg-brand-green-500 text-xs font-bold text-white ring-2 ring-brand-green-100">
                    <?php echo e(strtoupper(substr(auth()->user()->name ?? 'A', 0, 1))); ?>

                </button>
                <div x-show="userMenu" x-cloak x-transition
                     class="absolute right-0 z-50 mt-2 w-56 overflow-hidden rounded-[10px] border border-[var(--admin-border)] bg-white py-1 shadow-panel">
                    <div class="border-b border-[var(--admin-border)] px-4 py-3">
                        <p class="text-sm font-bold"><?php echo e(auth()->user()->name ?? 'Admin'); ?></p>
                        <p class="truncate text-xs text-slate-400"><?php echo e(auth()->user()->phone ?? auth()->user()->email); ?></p>
                    </div>
                    <a href="<?php echo e(route('home')); ?>" target="_blank" class="flex items-center gap-3 px-4 py-2.5 text-sm text-slate-600 hover:bg-slate-50">View Storefront</a>
                    <a href="<?php echo e(route('admin.settings.index')); ?>" class="flex items-center gap-3 px-4 py-2.5 text-sm text-slate-600 hover:bg-slate-50">Settings</a>
                    <a href="<?php echo e(route('admin.profile.password')); ?>" class="flex items-center gap-3 px-4 py-2.5 text-sm text-slate-600 hover:bg-slate-50">
                        <svg class="h-4 w-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/></svg>
                        <span>Change Password</span>
                    </a>
                    <div class="my-1 border-t border-[var(--admin-border)]"></div>
                    <form action="<?php echo e(route('admin.logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="flex w-full items-center gap-3 px-4 py-2.5 text-sm text-red-600 hover:bg-red-50">Logout</button>
                    </form>
                </div>
            </div>
        </header>

        <main class="flex-1 overflow-y-auto p-3 sm:p-5 min-w-0">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    
    <div x-show="commandOpen" x-cloak class="fixed inset-0 z-[300] flex items-start justify-center bg-black/40 pt-[12%] px-4"
         @click.self="commandOpen = false">
        <div class="w-full max-w-lg overflow-hidden rounded-[10px] border border-[var(--admin-border)] bg-white shadow-panel"
             x-data="{ q: '', selected: 0 }"
             @keydown.escape.window="commandOpen = false">
            <div class="flex h-12 items-center gap-2 border-b border-[var(--admin-border)] px-4">
                <svg width="16" height="16" class="text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                <input x-model="q" x-ref="cmdInput" type="text" placeholder="Search pages..."
                       class="h-full flex-1 bg-transparent text-sm outline-none min-w-0"
                       @keydown.enter.prevent="const links = [...$el.closest('div').parentElement.querySelectorAll('[data-cmd-link]')].filter(a => !a.classList.contains('hidden')); if(links[selected]) location.href = links[selected].href">
            </div>
            <div class="max-h-80 overflow-y-auto p-2">
                <?php $__currentLoopData = $allAdminNavItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a data-cmd-link href="<?php echo e(route($item['route'], $item['params'] ?? [])); ?>"
                       x-show="!q || '<?php echo e(strtolower($item['label'].' '.$item['section'])); ?>'.includes(q.toLowerCase())"
                       class="flex items-center gap-3 rounded-[6px] px-3 py-2 text-sm text-slate-700 hover:bg-brand-green-50 hover:text-brand-green-700"
                       @click="commandOpen = false">
                        <span class="text-[10px] font-bold uppercase tracking-wider text-slate-400"><?php echo e($item['section']); ?></span>
                        <span class="font-medium"><?php echo e($item['label']); ?></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal30b09ba64d8f9e6b0023e860875d7bb6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal30b09ba64d8f9e6b0023e860875d7bb6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.toast','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.toast'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal30b09ba64d8f9e6b0023e860875d7bb6)): ?>
<?php $attributes = $__attributesOriginal30b09ba64d8f9e6b0023e860875d7bb6; ?>
<?php unset($__attributesOriginal30b09ba64d8f9e6b0023e860875d7bb6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30b09ba64d8f9e6b0023e860875d7bb6)): ?>
<?php $component = $__componentOriginal30b09ba64d8f9e6b0023e860875d7bb6; ?>
<?php unset($__componentOriginal30b09ba64d8f9e6b0023e860875d7bb6); ?>
<?php endif; ?>

    <script>
        function adminShell() {
            return {
                collapsed: false,
                mobileOpen: false,
                commandOpen: false,
                init() {
                    try { this.collapsed = localStorage.getItem('mamabazar:admin_sidebar_collapsed') === 'true'; } catch (e) {}
                    this.$watch('commandOpen', (v) => {
                        if (v) this.$nextTick(() => this.$refs.cmdInput?.focus());
                    });
                },
                toggleCollapse() {
                    this.collapsed = !this.collapsed;
                    try { localStorage.setItem('mamabazar:admin_sidebar_collapsed', String(this.collapsed)); } catch (e) {}
                },
                onKey(e) {
                    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
                        e.preventDefault();
                        this.commandOpen = !this.commandOpen;
                    }
                }
            }
        }
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/layouts/admin.blade.php ENDPATH**/ ?>