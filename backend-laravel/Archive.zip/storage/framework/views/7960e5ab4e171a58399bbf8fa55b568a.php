<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <style>
        table { border-collapse: collapse; width: 100%; font-family: sans-serif; }
        th { background-color: #0f4d2c; color: #ffffff; font-weight: bold; border: 1px solid #cbd5e1; padding: 6px 8px; text-align: left; }
        td { border: 1px solid #e2e8f0; padding: 5px 8px; vertical-align: top; }
        tr:nth-child(even) { background-color: #f8fafc; }
        .success { color: #15803d; font-weight: bold; }
        .failure { color: #b91c1c; font-weight: bold; }
    </style>
</head>
<body>
    <h2>Mama Bazar — Super Admin Activity & Audit Report</h2>
    <p>Generated: <?php echo e($generatedAt); ?></p>

    <table>
        <thead>
            <tr>
                <th>UUID</th>
                <th>Date & Time</th>
                <th>Actor</th>
                <th>Actor Role</th>
                <th>Actor Type</th>
                <th>Event Name</th>
                <th>Module</th>
                <th>Target Type</th>
                <th>Target ID</th>
                <th>Status</th>
                <th>Source</th>
                <th>IP Address</th>
                <th>Location</th>
                <th>Description</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($log->uuid); ?></td>
                    <td><?php echo e(optional($log->occurred_at)->format('Y-m-d H:i:s')); ?></td>
                    <td><?php echo e($log->actor_name ?: 'System'); ?></td>
                    <td><?php echo e($log->actor_role ?: '—'); ?></td>
                    <td><?php echo e($log->actor_type); ?></td>
                    <td><?php echo e($log->event_name); ?></td>
                    <td><?php echo e($log->module); ?></td>
                    <td><?php echo e($log->subject_type ?: '—'); ?></td>
                    <td><?php echo e($log->subject_id ?: '—'); ?></td>
                    <td class="<?php echo e($log->status); ?>"><?php echo e(strtoupper($log->status)); ?></td>
                    <td><?php echo e($log->source); ?></td>
                    <td><?php echo e($log->ip_address ?: '—'); ?></td>
                    <td><?php echo e($log->location ?: 'Location unavailable'); ?></td>
                    <td><?php echo e($log->description ?: '—'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/admin/reports/activity-excel.blade.php ENDPATH**/ ?>