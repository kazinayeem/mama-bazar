<?php
    $type = $field['type'] ?? 'text';
    $name = $field['name'];
    $label = $field['label'];
    $required = !empty($field['required']);
    $modelPrefix = $modelPrefix ?? null;
    $hasModel = !empty($modelPrefix);
    $modelRef = $hasModel ? "{$modelPrefix}['{$name}']" : null;
    $value = $value ?? null;
?>

<?php if($type === 'checkbox'): ?>
    <label class="flex h-10 items-center justify-between rounded-lg border border-[var(--admin-border)] px-3 text-xs bg-white cursor-pointer hover:bg-slate-50/70 transition">
        <span class="font-medium text-slate-700"><?php echo e($label); ?></span>
        <?php if($hasModel): ?>
            <input type="checkbox" name="<?php echo e($name); ?>" value="1" x-model="<?php echo e($modelRef); ?>" class="rounded text-brand-green-600 focus:ring-brand-green-500 h-4 w-4">
        <?php else: ?>
            <input type="checkbox" name="<?php echo e($name); ?>" value="1" <?php if($value): echo 'checked'; endif; ?> class="rounded text-brand-green-600 focus:ring-brand-green-500 h-4 w-4">
        <?php endif; ?>
    </label>
<?php else: ?>
    <label class="mb-1 block text-xs font-semibold text-slate-700"><?php echo e($label); ?><?php if($required): ?> <span class="text-red-500">*</span> <?php endif; ?></label>

    <?php if($type === 'textarea'): ?>
        <?php if($hasModel): ?>
            <textarea name="<?php echo e($name); ?>" rows="3" x-model="<?php echo e($modelRef); ?>" <?php if($required): ?> required <?php endif; ?>
                      class="w-full rounded-lg border border-[var(--admin-border)] px-3 py-2 text-xs focus:border-brand-green-500 focus:outline-none focus:ring-2 focus:ring-brand-green-500/20"></textarea>
        <?php else: ?>
            <textarea name="<?php echo e($name); ?>" rows="3" <?php if($required): ?> required <?php endif; ?>
                      class="w-full rounded-lg border border-[var(--admin-border)] px-3 py-2 text-xs focus:border-brand-green-500 focus:outline-none focus:ring-2 focus:ring-brand-green-500/20"><?php echo e($value); ?></textarea>
        <?php endif; ?>

    <?php elseif($type === 'select'): ?>
        <?php if($hasModel): ?>
            <select name="<?php echo e($name); ?>" x-model="<?php echo e($modelRef); ?>" <?php if($required): ?> required <?php endif; ?>
                    class="admin-control w-full text-xs bg-white">
                <?php $__currentLoopData = ($field['options'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optVal => $optLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($optVal); ?>"><?php echo e($optLabel); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php else: ?>
            <select name="<?php echo e($name); ?>" <?php if($required): ?> required <?php endif; ?>
                    class="admin-control w-full text-xs bg-white">
                <?php $__currentLoopData = ($field['options'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optVal => $optLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($optVal); ?>" <?php if((string)$value === (string)$optVal): echo 'selected'; endif; ?>><?php echo e($optLabel); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php endif; ?>

    <?php elseif($type === 'hex'): ?>
        <div class="flex items-center gap-2">
            <?php if($hasModel): ?>
                <input type="color" x-model="<?php echo e($modelRef); ?>"
                       class="h-9 w-9 cursor-pointer rounded-lg border border-[var(--admin-border)] p-0.5 bg-white shrink-0">
                <input type="text" name="<?php echo e($name); ?>" x-model="<?php echo e($modelRef); ?>" placeholder="#176B3A"
                       class="admin-control flex-1 font-mono uppercase text-xs">
                <div class="h-9 w-9 rounded-lg border border-slate-200 shrink-0 shadow-xs flex items-center justify-center text-[10px]"
                     :style="{ backgroundColor: <?php echo e($modelRef); ?> || '#ffffff' }"></div>
            <?php else: ?>
                <input type="color" value="<?php echo e($value ?: '#176B3A'); ?>"
                       oninput="this.nextElementSibling.value = this.value; this.nextElementSibling.nextElementSibling.style.backgroundColor = this.value"
                       class="h-9 w-9 cursor-pointer rounded-lg border border-[var(--admin-border)] p-0.5 bg-white shrink-0">
                <input type="text" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>" placeholder="#176B3A"
                       oninput="this.previousElementSibling.value = this.value; this.nextElementSibling.style.backgroundColor = this.value"
                       class="admin-control flex-1 font-mono uppercase text-xs">
                <div class="h-9 w-9 rounded-lg border border-slate-200 shrink-0 shadow-xs"
                     style="background-color: <?php echo e($value ?: '#176B3A'); ?>"></div>
            <?php endif; ?>
        </div>

    <?php elseif($type === 'number'): ?>
        <?php if($hasModel): ?>
            <input type="number" name="<?php echo e($name); ?>" x-model="<?php echo e($modelRef); ?>" <?php if($required): ?> required <?php endif; ?>
                   class="admin-control w-full text-xs">
        <?php else: ?>
            <input type="number" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>" <?php if($required): ?> required <?php endif; ?>
                   class="admin-control w-full text-xs">
        <?php endif; ?>

    <?php elseif(in_array($name, ['logo', 'image', 'banner'], true)): ?>
        <div class="space-y-1.5">
            <div class="flex items-center gap-2">
                <?php if($hasModel): ?>
                    <input type="text" name="<?php echo e($name); ?>" x-model="<?php echo e($modelRef); ?>" placeholder="https://..." <?php if($required): ?> required <?php endif; ?>
                           class="admin-control flex-1 text-xs">
                    <template x-if="<?php echo e($modelRef); ?> && (<?php echo e($modelRef); ?>.startsWith('http') || <?php echo e($modelRef); ?>.startsWith('/'))">
                        <div class="h-9 w-9 shrink-0 overflow-hidden rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-center p-0.5">
                            <img :src="<?php echo e($modelRef); ?>" class="h-full w-full object-contain" x-on:error="$el.style.display='none'">
                        </div>
                    </template>
                <?php else: ?>
                    <input type="text" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>" placeholder="https://..." <?php if($required): ?> required <?php endif; ?>
                           class="admin-control flex-1 text-xs">
                    <?php if($value): ?>
                        <div class="h-9 w-9 shrink-0 overflow-hidden rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-center p-0.5">
                            <img src="<?php echo e($value); ?>" class="h-full w-full object-contain">
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

    <?php else: ?>
        <?php if($hasModel): ?>
            <input type="text" name="<?php echo e($name); ?>" x-model="<?php echo e($modelRef); ?>" <?php if($required): ?> required <?php endif; ?>
                   class="admin-control w-full text-xs">
        <?php else: ?>
            <input type="text" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>" <?php if($required): ?> required <?php endif; ?>
                   class="admin-control w-full text-xs">
        <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/admin/catalog/_field.blade.php ENDPATH**/ ?>