<?php $__env->startSection('content'); ?>
<div class="mx-auto w-full max-w-[1400px] space-y-5">
    <!-- Header -->
    <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div class="flex items-center gap-3">
            <a
                href="<?php echo e(route('admin.products.index')); ?>"
                class="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition shrink-0"
                title="Back to products"
            >
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
            </a>
            <div>
                <h1 class="admin-page-title"><?php echo e($product['title']); ?></h1>
                <p class="flex items-center gap-2 text-xs text-slate-500">
                    <span>SKU: <?php echo e($product['sku'] ?: '—'); ?></span>
                    <span>·</span>
                    <span>Created <?php echo e(!empty($product['createdAt']) ? \Carbon\Carbon::parse($product['createdAt'])->format('M d, Y') : '—'); ?></span>
                </p>
            </div>
        </div>

        <div class="flex items-center gap-2">
            <?php if(!empty($product['slug'])): ?>
                <a
                    href="<?php echo e(url('/products/' . $product['slug'])); ?>"
                    target="_blank"
                    class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg shadow-xs transition"
                >
                    <svg class="w-3.5 h-3.5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                    View on storefront
                </a>
            <?php endif; ?>

            <a
                href="<?php echo e(route('admin.products.edit', $product['id'])); ?>"
                class="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-sm transition"
            >
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                Edit
            </a>
        </div>
    </div>

    <!-- Status + Badges Card -->
    <div class="rounded-xl border border-slate-200 bg-white p-4 shadow-xs flex flex-wrap items-center gap-2">
        <?php
            $status = $product['productStatus'] ?? ($product['status'] ?? 'draft');
            $statusVariant = match($status) {
                'published', 'active' => 'bg-emerald-50 text-emerald-700 border-emerald-200',
                'draft' => 'bg-slate-100 text-slate-600 border-slate-200',
                'hidden' => 'bg-amber-50 text-amber-700 border-amber-200',
                'archived' => 'bg-slate-200 text-slate-700 border-slate-300',
                default => 'bg-slate-100 text-slate-600 border-slate-200',
            };
        ?>
        <span class="inline-flex items-center px-2.5 py-0.5 rounded text-xs font-bold border capitalize <?php echo e($statusVariant); ?>">
            <?php echo e($status); ?>

        </span>

        <span class="inline-flex items-center px-2.5 py-0.5 rounded text-xs font-semibold <?php echo e((int)$product['stock'] > 0 ? 'bg-slate-100 text-slate-700 border border-slate-200' : 'bg-red-50 text-red-700 border border-red-200'); ?>">
            Stock: <?php echo e($product['stock']); ?>

        </span>

        <span class="inline-flex items-center px-2.5 py-0.5 rounded text-xs font-medium bg-slate-50 text-slate-600 border border-slate-200">
            Stock status: <?php echo e($product['stockStatus'] ?? 'in_stock'); ?>

        </span>

        <?php
            $flagMap = [
                'isFeatured' => 'Featured',
                'isTrending' => 'Trending',
                'isFlashSale' => 'Flash Sale',
                'isNewArrival' => 'New Arrival',
                'isBestSeller' => 'Best Seller',
                'isLimitedEdition' => 'Limited Edition',
                'isOfficial' => 'Official',
                'isHotDeal' => 'Hot Deal',
                'emiAvailable' => 'EMI Available',
            ];
        ?>
        <?php $__currentLoopData = $flagMap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!empty($product[$key])): ?>
                <span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
                    <?php echo e($label); ?>

                </span>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Images + Details Grid -->
    <div class="grid gap-5 lg:grid-cols-3">
        <!-- Images Card -->
        <div class="lg:col-span-1 rounded-2xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
            <h2 class="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">Images</h2>
            <?php if(empty($product['images'])): ?>
                <p class="text-xs text-slate-400">No images uploaded</p>
            <?php else: ?>
                <div class="grid grid-cols-2 gap-2">
                    <?php $__currentLoopData = $product['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img
                            src="<?php echo e($img); ?>"
                            alt="<?php echo e($product['title']); ?>"
                            class="aspect-square w-full rounded-xl border border-slate-200 object-cover bg-slate-50"
                        />
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Details Card -->
        <div class="lg:col-span-2 rounded-2xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
            <h2 class="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">Details</h2>
            <div class="divide-y divide-slate-100 text-xs">
                <div class="flex items-center justify-between py-2">
                    <span class="font-medium text-slate-500">Price</span>
                    <span class="font-bold text-slate-900">৳<?php echo e(number_format((float)($product['price'] ?? 0), 2)); ?></span>
                </div>
                <div class="flex items-center justify-between py-2">
                    <span class="font-medium text-slate-500">Sale price</span>
                    <span class="font-semibold text-slate-900"><?php echo e(!empty($product['salePrice']) ? '৳' . number_format((float)$product['salePrice'], 2) : '—'); ?></span>
                </div>
                <div class="flex items-center justify-between py-2">
                    <span class="font-medium text-slate-500">Discount</span>
                    <span class="text-slate-700"><?php echo e((float)($product['discount'] ?? 0) > 0 ? '-' . $product['discount'] . '%' : '—'); ?></span>
                </div>
                <?php if(isset($product['costPrice'])): ?>
                <div class="flex items-center justify-between py-2">
                    <span class="font-medium text-slate-500">Cost price</span>
                    <span class="text-slate-700"><?php echo e((float) $product['costPrice'] > 0 ? '৳' . number_format((float)$product['costPrice'], 2) : '—'); ?></span>
                </div>
                <?php endif; ?>
                <?php if(isset($product['profitMargin'])): ?>
                <div class="flex items-center justify-between py-2">
                    <span class="font-medium text-slate-500">Profit margin</span>
                    <span class="text-slate-700"><?php echo e((float) $product['profitMargin'] != 0 ? $product['profitMargin'] . '%' : '—'); ?></span>
                </div>
                <?php endif; ?>
                <div class="flex items-center justify-between py-2">
                    <span class="font-medium text-slate-500">Category</span>
                    <span class="text-slate-900 font-semibold"><?php echo e($product['category']['name'] ?? '—'); ?></span>
                </div>
                <div class="flex items-center justify-between py-2">
                    <span class="font-medium text-slate-500">Sub-category</span>
                    <span class="text-slate-700"><?php echo e($product['subCategory']['name'] ?? '—'); ?></span>
                </div>
                <div class="flex items-center justify-between py-2">
                    <span class="font-medium text-slate-500">Child category</span>
                    <span class="text-slate-700"><?php echo e($product['childCategory']['name'] ?? '—'); ?></span>
                </div>
                <div class="flex items-center justify-between py-2">
                    <span class="font-medium text-slate-500">Brand</span>
                    <span class="text-slate-900 font-semibold"><?php echo e($product['brandInfo']['name'] ?? ($product['brand'] ?: '—')); ?></span>
                </div>
                <div class="flex items-center justify-between py-2">
                    <span class="font-medium text-slate-500">Collection</span>
                    <span class="text-slate-700"><?php echo e($product['collection']['name'] ?? '—'); ?></span>
                </div>
                <div class="flex items-center justify-between py-2">
                    <span class="font-medium text-slate-500">Vendor</span>
                    <span class="text-slate-700"><?php echo e($product['vendor']['name'] ?? '—'); ?></span>
                </div>
                <div class="flex items-center justify-between py-2">
                    <span class="font-medium text-slate-500">Supplier</span>
                    <span class="text-slate-700"><?php echo e($product['supplierInfo']['name'] ?? ($product['supplier'] ?: '—')); ?></span>
                </div>
                <div class="flex items-center justify-between py-2">
                    <span class="font-medium text-slate-500">Country of origin</span>
                    <span class="text-slate-700"><?php echo e($product['countryOfOrigin'] ?: '—'); ?></span>
                </div>
                <div class="flex items-center justify-between py-2">
                    <span class="font-medium text-slate-500">Weight</span>
                    <span class="text-slate-700"><?php echo e($product['weight'] ?: '—'); ?></span>
                </div>
                <div class="flex items-center justify-between py-2">
                    <span class="font-medium text-slate-500">Dimensions</span>
                    <span class="text-slate-700"><?php echo e($product['dimensions'] ?: '—'); ?></span>
                </div>
                <div class="flex items-center justify-between py-2">
                    <span class="font-medium text-slate-500">Warranty</span>
                    <span class="text-slate-700"><?php echo e($product['warranty'] ?: '—'); ?></span>
                </div>
                <div class="flex items-center justify-between py-2">
                    <span class="font-medium text-slate-500">Tags</span>
                    <span class="text-slate-700"><?php echo e(!empty($product['tags']) ? implode(', ', $product['tags']) : '—'); ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Description Card -->
    <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs space-y-3">
        <h2 class="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">Description</h2>
        <?php if(!empty($product['description'])): ?>
            <div class="product-description text-xs">
                <?php echo \App\Services\HtmlSanitizer::forDisplay($product['description']); ?>

            </div>
        <?php else: ?>
            <p class="text-xs text-slate-400">No description provided</p>
        <?php endif; ?>
    </div>

    <!-- Specs & Variants 2-col Grid -->
    <div class="grid gap-5 lg:grid-cols-2">
        <!-- Specifications -->
        <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs space-y-3">
            <h2 class="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">Specifications</h2>
            <?php if(empty($product['specs'])): ?>
                <p class="text-xs text-slate-400">No specifications defined</p>
            <?php else: ?>
                <div class="divide-y divide-slate-100 text-xs">
                    <?php $__currentLoopData = $product['specs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center justify-between py-2">
                            <span class="font-medium text-slate-500"><?php echo e($spec['label']); ?></span>
                            <span class="font-semibold text-slate-800 text-right"><?php echo e($spec['value']); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Variants -->
        <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs space-y-3">
            <h2 class="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">Variants</h2>
            <?php if(empty($product['variants'])): ?>
                <p class="text-xs text-slate-400">No variants for this product (simple product)</p>
            <?php else: ?>
                <div class="space-y-2">
                    <?php $__currentLoopData = $product['variants']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center justify-between gap-3 rounded-xl border border-slate-200 p-3 text-xs bg-slate-50/50">
                            <div class="min-w-0">
                                <p class="font-bold text-slate-900 truncate"><?php echo e($v['name']); ?></p>
                                <p class="text-[11px] font-mono text-slate-500"><?php echo e($v['sku'] ?: 'No SKU'); ?></p>
                            </div>
                            <div class="text-right shrink-0">
                                <p class="font-bold text-slate-900">৳<?php echo e(number_format((float)($v['price'] ?: $product['price']), 2)); ?></p>
                                <p class="text-[11px] text-slate-500">Qty: <?php echo e($v['stock']); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Related Products -->
    <?php if(!empty($product['relations'])): ?>
        <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs space-y-3">
            <h2 class="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">Related Products</h2>
            <div class="flex flex-wrap gap-2">
                <?php $__currentLoopData = $product['relations']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs border border-slate-200 bg-slate-50 text-slate-700">
                        <span class="font-semibold capitalize"><?php echo e(str_replace('_', ' ', $rel['type'] ?? '')); ?>:</span>
                        <span>#<?php echo e($rel['relatedProductId'] ?? ($rel['relatedProduct']['id'] ?? '')); ?></span>
                        <?php if(!empty($rel['relatedProduct']['title'])): ?>
                            <span class="text-slate-500 font-medium">(<?php echo e($rel['relatedProduct']['title']); ?>)</span>
                        <?php endif; ?>
                    </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- SEO Card -->
    <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs space-y-3">
        <h2 class="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">SEO &amp; Metadata</h2>
        <div class="divide-y divide-slate-100 text-xs">
            <div class="flex items-center justify-between py-2">
                <span class="font-medium text-slate-500">SEO title</span>
                <span class="text-slate-800"><?php echo e($product['seoTitle'] ?: '—'); ?></span>
            </div>
            <div class="flex items-center justify-between py-2">
                <span class="font-medium text-slate-500">SEO description</span>
                <span class="text-slate-800 max-w-md text-right"><?php echo e($product['seoDescription'] ?: '—'); ?></span>
            </div>
            <div class="flex items-center justify-between py-2">
                <span class="font-medium text-slate-500">SEO keywords</span>
                <span class="text-slate-800"><?php echo e($product['seoKeywords'] ?: '—'); ?></span>
            </div>
            <div class="flex items-center justify-between py-2">
                <span class="font-medium text-slate-500">Canonical URL</span>
                <span class="text-slate-800 font-mono"><?php echo e($product['canonicalUrl'] ?: '—'); ?></span>
            </div>
        </div>
    </div>

    <?php if(($financialAccess ?? null)?->canViewCostHistory && ($financialAccess->canViewCostPrice || $financialAccess->canViewProfitMargin)): ?>
        <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs space-y-3" id="cost-history">
            <h2 class="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">Buying Price History</h2>
            <?php if(($costHistory ?? collect())->isEmpty()): ?>
                <p class="text-xs text-slate-400">No buying price changes recorded yet.</p>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="w-full text-xs">
                        <thead>
                            <tr class="text-left text-slate-500 border-b border-slate-100">
                                <th class="py-2 pr-3 font-semibold">When</th>
                                <th class="py-2 pr-3 font-semibold">Field</th>
                                <th class="py-2 pr-3 font-semibold text-right">Old</th>
                                <th class="py-2 pr-3 font-semibold text-right">New</th>
                                <th class="py-2 pr-3 font-semibold">Changed by</th>
                                <th class="py-2 font-semibold">Source</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            <?php $__currentLoopData = $costHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php ($isMargin = $entry->field === 'profit_margin'); ?>
                                <tr>
                                    <td class="py-2 pr-3 text-slate-600 whitespace-nowrap"><?php echo e($entry->created_at?->format('d M Y, h:i A')); ?></td>
                                    <td class="py-2 pr-3 text-slate-700"><?php echo e($isMargin ? 'Profit margin' : 'Buying price'); ?></td>
                                    <td class="py-2 pr-3 text-right text-slate-500">
                                        <?php echo e($entry->old_value === null ? '—' : ($isMargin ? $entry->old_value.'%' : '৳'.number_format($entry->old_value, 2))); ?>

                                    </td>
                                    <td class="py-2 pr-3 text-right font-semibold text-slate-900">
                                        <?php echo e($entry->new_value === null ? '—' : ($isMargin ? $entry->new_value.'%' : '৳'.number_format($entry->new_value, 2))); ?>

                                    </td>
                                    <td class="py-2 pr-3 text-slate-700"><?php echo e($entry->user_name ?: 'System'); ?></td>
                                    <td class="py-2 text-slate-500 capitalize"><?php echo e($entry->source); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', [
    'title' => 'View Product: ' . ($product['title'] ?? 'Product'),
    'headerTitle' => 'Product Details'
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/admin/products/show.blade.php ENDPATH**/ ?>