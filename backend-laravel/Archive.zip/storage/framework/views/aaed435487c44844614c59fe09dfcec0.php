<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['variant' => 'default']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['variant' => 'default']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $variants = [
        'default' => 'bg-brand-green-50 text-brand-green-700 border-brand-green-100',
        'secondary' => 'bg-slate-100 text-slate-600 border-slate-200',
        'success' => 'bg-emerald-50 text-emerald-700 border-emerald-100',
        'warning' => 'bg-amber-50 text-amber-800 border-amber-100',
        'destructive' => 'bg-red-50 text-red-700 border-red-100',
        'orange' => 'bg-brand-orange-50 text-brand-orange-700 border-brand-orange-100',
        'muted' => 'bg-slate-50 text-slate-500 border-slate-100',
    ];
?>

<span <?php echo e($attributes->merge([
    'class' => 'inline-flex items-center rounded-[6px] border px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide '.($variants[$variant] ?? $variants['default'])
])); ?>><?php echo e($slot); ?></span>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/components/admin/badge.blade.php ENDPATH**/ ?>