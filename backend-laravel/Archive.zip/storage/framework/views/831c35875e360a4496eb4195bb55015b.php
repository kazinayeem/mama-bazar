<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['paginator']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['paginator']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if($paginator && method_exists($paginator, 'hasPages') && $paginator->hasPages()): ?>
    <div <?php echo e($attributes->merge(['class' => 'flex flex-col gap-3 border-t border-[var(--admin-border)] px-4 py-3 sm:flex-row sm:items-center sm:justify-between'])); ?>>
        <p class="text-xs text-slate-500">
            Page <?php echo e($paginator->currentPage()); ?> of <?php echo e($paginator->lastPage()); ?>

            · <?php echo e(number_format($paginator->total())); ?> items
        </p>
        <div class="overflow-x-auto">
            <?php echo e($paginator->onEachSide(1)->links()); ?>

        </div>
    </div>
<?php endif; ?>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/components/admin/pagination.blade.php ENDPATH**/ ?>