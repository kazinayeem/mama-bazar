
<?php ($pdfBrand = \App\Support\PdfBranding::attribution()); ?>
<div style="margin-top: 18px; border-top: 1px solid #e2e8f0; padding-top: 8px; text-align: center; font-size: 9px; color: #94a3b8; line-height: 1.6;">
    <span><?php echo e($pdfBrand['tagline']); ?> &middot; <?php echo e($pdfBrand['subline']); ?></span><br>
    <a href="<?php echo e($pdfBrand['url']); ?>" style="color: #64748b; text-decoration: none;"><?php echo e($pdfBrand['domain']); ?></a>
</div>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/pdf/branding-footer.blade.php ENDPATH**/ ?>