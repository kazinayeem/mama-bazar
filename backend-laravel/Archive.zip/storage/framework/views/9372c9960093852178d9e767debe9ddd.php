<?php $__env->startSection('content'); ?>
<div class="admin-page max-w-3xl">
    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Email Management','subtitle' => 'One-time database setup is required before the email system can be used.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Email Management','subtitle' => 'One-time database setup is required before the email system can be used.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <div class="admin-surface p-5 space-y-4">
        <div class="rounded-[8px] border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800">
            The email system database migrations have not been run on this database yet. Email pages are disabled until they are applied.
        </div>

        <div class="space-y-2 text-xs text-slate-700">
            <p class="font-semibold text-slate-900">Run these steps on the server, from the Laravel project folder:</p>
            <ol class="list-decimal space-y-1 pl-5">
                <li>Back up the database (cPanel › Backup, or <code>mysqldump</code>).</li>
                <li>Check what is pending: <code class="rounded bg-slate-100 px-1">php artisan migrate:status</code></li>
                <li>Apply the migrations: <code class="rounded bg-slate-100 px-1">php artisan migrate --force</code></li>
                <li>Reload this page.</li>
            </ol>
        </div>

        <?php if(!empty($missing)): ?>
            <div class="text-xs text-slate-500">
                <p class="font-semibold text-slate-700">Missing database objects</p>
                <ul class="mt-1 list-disc pl-5">
                    <?php $__currentLoopData = $missing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><code><?php echo e($item); ?></code></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', ['headerTitle' => 'Email Management'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/admin/email/setup-required.blade.php ENDPATH**/ ?>