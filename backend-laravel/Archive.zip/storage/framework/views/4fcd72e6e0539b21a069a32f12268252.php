<?php
    $type = $type ?? ($section['type'] ?? '');
    $data = $data ?? ($section['data'] ?? []);
    $items = $items ?? ($data['items'] ?? []);
?>

<?php switch($type):
    case ('hero'): ?>
        <?php echo $__env->make('web.homepage.partials.hero', [
            'slides' => $data['slides'] ?? ($homepageData['heroSlides'] ?? []),
            'popularSearches' => $homepageData['popularSearches'] ?? ($config['popularSearches'] ?? []),
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    <?php case ('trust_strip'): ?>
        <?php echo $__env->make('web.homepage.partials.trust-strip', [
            'items' => !empty($items) ? $items : ($homepageData['trustStrip'] ?? []),
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    <?php case ('categories'): ?>
        <?php if (isset($component)) { $__componentOriginal177a6a1584d25b709c6540858fb05732 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal177a6a1584d25b709c6540858fb05732 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.homepage.section-shell','data' => ['section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('homepage.section-shell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
            <?php
                $cols = (int) ($section['columns'] ?? 4);
                $gridClass = match (true) {
                    $cols >= 6 => 'grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6',
                    $cols === 5 => 'grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5',
                    default => 'grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4',
                };
            ?>
            <div class="<?php echo e($gridClass); ?>">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $c = is_array($cat) ? $cat : (array) $cat;
                        $slug = $c['slug'] ?? '';
                        $name = $c['name'] ?? '';
                        $image = $c['image'] ?? $c['thumbnail'] ?? null;
                        $count = $c['productCount'] ?? $c['products_count'] ?? null;
                    ?>
                    <a href="<?php echo e(route('shop', ['category' => $slug])); ?>" class="group flex flex-col items-center rounded-[10px] border border-brand-green-100 bg-white px-2.5 py-3.5 text-center transition duration-200 hover:-translate-y-0.5 hover:border-brand-green-300 hover:shadow-soft">
                        <div class="mb-2.5 flex h-14 w-14 items-center justify-center rounded-full bg-brand-green-50 p-2 sm:h-16 sm:w-16">
                            <?php if($image): ?>
                                <img src="<?php echo e($image); ?>" alt="<?php echo e($name); ?>" class="h-10 w-10 object-contain sm:h-12 sm:w-12" loading="lazy">
                            <?php else: ?>
                                <span class="text-lg font-black text-brand-green-600"><?php echo e(mb_substr($name, 0, 1)); ?></span>
                            <?php endif; ?>
                        </div>
                        <span class="max-w-full truncate text-xs font-bold text-slate-800 group-hover:text-brand-green-600"><?php echo e($name); ?></span>
                        <?php if($count !== null): ?>
                            <span class="mt-0.5 text-[10px] text-slate-400"><?php echo e($count); ?> items</span>
                        <?php endif; ?>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal177a6a1584d25b709c6540858fb05732)): ?>
<?php $attributes = $__attributesOriginal177a6a1584d25b709c6540858fb05732; ?>
<?php unset($__attributesOriginal177a6a1584d25b709c6540858fb05732); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal177a6a1584d25b709c6540858fb05732)): ?>
<?php $component = $__componentOriginal177a6a1584d25b709c6540858fb05732; ?>
<?php unset($__componentOriginal177a6a1584d25b709c6540858fb05732); ?>
<?php endif; ?>
        <?php break; ?>

    <?php case ('category_products'): ?>
    <?php case ('featured'): ?>
    <?php case ('best_sellers'): ?>
    <?php case ('trending'): ?>
    <?php case ('new_arrivals'): ?>
    <?php case ('limited_edition'): ?>
    <?php case ('official'): ?>
    <?php case ('hot_deals'): ?>
    <?php case ('emi_available'): ?>
    <?php case ('recommendations'): ?>
        <?php if (isset($component)) { $__componentOriginal177a6a1584d25b709c6540858fb05732 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal177a6a1584d25b709c6540858fb05732 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.homepage.section-shell','data' => ['section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('homepage.section-shell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
            <div class="store-product-grid">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product-card','data' => ['product' => $product,'index' => $i]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product),'index' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($i)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $attributes = $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $component = $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal177a6a1584d25b709c6540858fb05732)): ?>
<?php $attributes = $__attributesOriginal177a6a1584d25b709c6540858fb05732; ?>
<?php unset($__attributesOriginal177a6a1584d25b709c6540858fb05732); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal177a6a1584d25b709c6540858fb05732)): ?>
<?php $component = $__componentOriginal177a6a1584d25b709c6540858fb05732; ?>
<?php unset($__componentOriginal177a6a1584d25b709c6540858fb05732); ?>
<?php endif; ?>
        <?php break; ?>

    <?php case ('flash_deals'): ?>
        <?php echo $__env->make('web.homepage.partials.flash-deals', [
            'section' => $section,
            'items' => $items,
            'flashSaleWindow' => $homepageData['flashSaleWindow'] ?? [],
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    <?php case ('promo_banner'): ?>
        <?php
            $offset = ((int) ($promoIndex ?? 0)) * 2;
            $banners = array_slice(array_values($items), $offset, 2);
        ?>
        <?php if(!empty($banners)): ?>
            <section class="store-section !py-4">
                <div class="store-container grid gap-4 lg:grid-cols-2">
                    <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $b = is_array($banner) ? $banner : (array) $banner;
                            if (isset($banner->image)) {
                                $b = [
                                    'image' => $banner->image,
                                    'title' => $banner->title,
                                    'link' => $banner->link,
                                    'button_text' => $banner->button_text ?? null,
                                ];
                            }
                            $img = $b['image'] ?? $b['desktopImage'] ?? null;
                            $link = $b['link'] ?? $b['primaryButtonUrl'] ?? '#';
                            $title = $b['title'] ?? '';
                        ?>
                        <?php if($img): ?>
                            <a href="<?php echo e($link); ?>" class="group relative block overflow-hidden rounded-[12px]">
                                <img src="<?php echo e($img); ?>" alt="<?php echo e($title); ?>" class="h-40 w-full object-cover transition duration-500 group-hover:scale-[1.03] sm:h-52" loading="lazy">
                                <?php if($title): ?>
                                    <span class="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/60 to-transparent px-5 py-4 text-sm font-bold text-white"><?php echo e($title); ?></span>
                                <?php endif; ?>
                            </a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>
        <?php break; ?>

    <?php case ('brands'): ?>
        <?php if (isset($component)) { $__componentOriginal177a6a1584d25b709c6540858fb05732 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal177a6a1584d25b709c6540858fb05732 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.homepage.section-shell','data' => ['section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('homepage.section-shell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
            <div class="flex gap-3 overflow-x-auto pb-2 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $b = is_array($brand) ? $brand : (array) $brand;
                        $logo = $b['logo'] ?? null;
                        $name = $b['name'] ?? '';
                        $slug = $b['slug'] ?? '';
                    ?>
                    <a href="<?php echo e(route('shop', ['brand' => $slug])); ?>" class="store-brand-chip flex h-16 w-28 shrink-0 items-center justify-center rounded-[10px] border border-slate-200 bg-white px-3 transition duration-200 hover:border-brand-green-300 sm:h-[72px] sm:w-32" title="<?php echo e($name); ?>">
                        <?php if($logo): ?>
                            <img src="<?php echo e($logo); ?>" alt="<?php echo e($name); ?>" class="store-brand-logo max-h-9 max-w-full object-contain sm:max-h-10" loading="lazy">
                        <?php else: ?>
                            <span class="text-xs font-bold text-slate-600"><?php echo e($name); ?></span>
                        <?php endif; ?>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal177a6a1584d25b709c6540858fb05732)): ?>
<?php $attributes = $__attributesOriginal177a6a1584d25b709c6540858fb05732; ?>
<?php unset($__attributesOriginal177a6a1584d25b709c6540858fb05732); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal177a6a1584d25b709c6540858fb05732)): ?>
<?php $component = $__componentOriginal177a6a1584d25b709c6540858fb05732; ?>
<?php unset($__componentOriginal177a6a1584d25b709c6540858fb05732); ?>
<?php endif; ?>
        <?php break; ?>

    <?php case ('collections'): ?>
        <?php if (isset($component)) { $__componentOriginal177a6a1584d25b709c6540858fb05732 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal177a6a1584d25b709c6540858fb05732 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.homepage.section-shell','data' => ['section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('homepage.section-shell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
            <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $c = is_array($collection) ? $collection : [
                            'name' => $collection->name ?? '',
                            'slug' => $collection->slug ?? '',
                            'image' => $collection->image ?? $collection->banner ?? null,
                            'description' => $collection->description ?? '',
                        ];
                        $img = $c['image'] ?? $c['banner'] ?? null;
                    ?>
                    <a href="<?php echo e(route('shop', ['collection' => $c['slug'] ?? ''])); ?>" class="group relative overflow-hidden rounded-3xl border border-brand-green-100 bg-white">
                        <div class="aspect-[16/9] bg-brand-green-50">
                            <?php if($img): ?>
                                <img src="<?php echo e($img); ?>" alt="<?php echo e($c['name'] ?? ''); ?>" class="h-full w-full object-cover transition duration-500 group-hover:scale-105" loading="lazy">
                            <?php endif; ?>
                        </div>
                        <div class="p-4">
                            <h3 class="text-sm font-extrabold text-slate-900"><?php echo e($c['name'] ?? ''); ?></h3>
                            <?php if(!empty($c['description'])): ?>
                                <p class="mt-1 line-clamp-2 text-xs text-slate-500"><?php echo e($c['description']); ?></p>
                            <?php endif; ?>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal177a6a1584d25b709c6540858fb05732)): ?>
<?php $attributes = $__attributesOriginal177a6a1584d25b709c6540858fb05732; ?>
<?php unset($__attributesOriginal177a6a1584d25b709c6540858fb05732); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal177a6a1584d25b709c6540858fb05732)): ?>
<?php $component = $__componentOriginal177a6a1584d25b709c6540858fb05732; ?>
<?php unset($__componentOriginal177a6a1584d25b709c6540858fb05732); ?>
<?php endif; ?>
        <?php break; ?>

    <?php case ('reviews'): ?>
        <?php if (isset($component)) { $__componentOriginal177a6a1584d25b709c6540858fb05732 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal177a6a1584d25b709c6540858fb05732 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.homepage.section-shell','data' => ['section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('homepage.section-shell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
            <div class="grid gap-3 sm:gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $r = is_array($review) ? $review : (array) $review;
                        $rating = (int) ($r['rating'] ?? 5);
                        $name = $r['customerName'] ?? $r['customer_name'] ?? 'Customer';
                        $comment = $r['comment'] ?? '';
                        $productTitle = $r['productTitle'] ?? $r['product_title'] ?? '';
                    ?>
                    <div class="rounded-[10px] border border-brand-green-100 bg-white p-3.5 sm:p-4 min-w-0 overflow-hidden break-words">
                        <div class="flex gap-0.5 text-amber-400" aria-label="<?php echo e($rating); ?> out of 5 stars">
                            <?php for($i = 0; $i < 5; $i++): ?>
                                <span class="text-sm" aria-hidden="true"><?php echo e($i < $rating ? '★' : '☆'); ?></span>
                            <?php endfor; ?>
                        </div>
                        <p class="mt-2.5 line-clamp-3 text-sm leading-6 text-slate-600 break-words"><?php echo e($comment); ?></p>
                        <p class="mt-3 flex flex-wrap items-center gap-1.5 sm:gap-2 text-xs font-bold text-slate-900 break-words">— <?php echo e($name); ?>

                            <?php if(!empty($r['isVerifiedPurchase'] ?? $r['is_verified_purchase'] ?? false)): ?>
                                <span class="rounded-full bg-brand-green-50 px-2 py-0.5 text-[10px] font-bold text-brand-green-700">Verified Purchase</span>
                            <?php endif; ?>
                        </p>
                        <?php if($productTitle): ?>
                            <p class="mt-0.5 truncate text-[11px] text-slate-400"><?php echo e($productTitle); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal177a6a1584d25b709c6540858fb05732)): ?>
<?php $attributes = $__attributesOriginal177a6a1584d25b709c6540858fb05732; ?>
<?php unset($__attributesOriginal177a6a1584d25b709c6540858fb05732); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal177a6a1584d25b709c6540858fb05732)): ?>
<?php $component = $__componentOriginal177a6a1584d25b709c6540858fb05732; ?>
<?php unset($__componentOriginal177a6a1584d25b709c6540858fb05732); ?>
<?php endif; ?>
        <?php break; ?>

    <?php case ('why_choose_us'): ?>
        <?php echo $__env->make('web.homepage.partials.why-choose-us', [
            'section' => $section,
            'items' => !empty($items) ? $items : ($homepageData['whyChooseUs'] ?? []),
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    <?php case ('newsletter'): ?>
        <?php echo $__env->make('web.homepage.partials.newsletter', [
            'settings' => $data['settings'] ?? ($homepageData['newsletter'] ?? $config['newsletter'] ?? []),
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    <?php default: ?>
        
<?php endswitch; ?>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/web/homepage/section.blade.php ENDPATH**/ ?>