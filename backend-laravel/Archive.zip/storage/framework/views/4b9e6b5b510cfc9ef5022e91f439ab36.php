<?php $__env->startSection('content'); ?>
<?php
    $lucide = \App\Support\AdminNav::lucide();
    $chartColors = ['#16a34a', '#f97316', '#0284c7', '#eab308', '#dc2626', '#64748b', '#0d9488'];
?>

<div class="admin-page">
    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Dashboard','subtitle' => 'Business overview and performance metrics']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dashboard','subtitle' => 'Business overview and performance metrics']); ?>
         <?php $__env->slot('actions', null, []); ?> 
            <form method="GET" action="<?php echo e(route('admin.dashboard')); ?>" class="flex flex-wrap items-center gap-2">
                <select name="range" onchange="this.form.submit()" class="admin-control min-w-[9rem] sm:w-36">
                    <option value="7" <?php if($range === 7): echo 'selected'; endif; ?>>Last 7 days</option>
                    <option value="30" <?php if($range === 30): echo 'selected'; endif; ?>>Last 30 days</option>
                    <option value="365" <?php if($range === 365): echo 'selected'; endif; ?>>Last 365 days</option>
                </select>
                <?php if (isset($component)) { $__componentOriginal60a020e5340f3f52bbc4501dc9f93102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.button','data' => ['href' => route('admin.dashboard', ['range' => $range]),'variant' => 'outline','size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.dashboard', ['range' => $range])),'variant' => 'outline','size' => 'sm']); ?>Refresh <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $attributes = $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $component = $__componentOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
            </form>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    
    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
        <?php
            $kpiCards = [
                [
                    'label' => 'Total Revenue',
                    'value' => '৳'.number_format($kpis['totalRevenue'], 0),
                    'sub' => '৳'.number_format($kpis['periodRevenue'], 0).' this period',
                    'hint' => 'Delivered orders',
                    'icon' => 'wallet',
                    'iconBg' => 'bg-brand-green-50 text-brand-green-600',
                ],
                [
                    'label' => 'Total Orders',
                    'value' => number_format($kpis['totalOrders']),
                    'sub' => $kpis['periodOrders'].' in last '.$range.' days',
                    'hint' => 'Delivered count',
                    'icon' => 'shopping-cart',
                    'iconBg' => 'bg-brand-orange-50 text-brand-orange-600',
                ],
                [
                    'label' => 'Avg Order Value',
                    'value' => '৳'.number_format($kpis['avgOrderValue'], 0),
                    'sub' => 'Per delivered order',
                    'hint' => '',
                    'icon' => 'credit-card',
                    'iconBg' => 'bg-slate-100 text-slate-600',
                ],
                [
                    'label' => 'Customers',
                    'value' => number_format($kpis['totalCustomers']),
                    'sub' => 'Registered accounts',
                    'hint' => '',
                    'icon' => 'users',
                    'iconBg' => 'bg-brand-green-50 text-brand-green-600',
                ],
                [
                    'label' => 'Products',
                    'value' => number_format($kpis['totalProducts']),
                    'sub' => $kpis['outOfStock'].' out of stock',
                    'hint' => $kpis['outOfStock'] > 0 ? 'Attention needed' : 'Healthy',
                    'icon' => 'package',
                    'iconBg' => 'bg-brand-orange-50 text-brand-orange-600',
                    'warn' => $kpis['outOfStock'] > 0,
                ],
                [
                    'label' => "Today's Orders",
                    'value' => number_format($kpis['todayOrders']),
                    'sub' => 'Orders placed today',
                    'hint' => 'Live',
                    'icon' => 'boxes',
                    'iconBg' => 'bg-brand-green-50 text-brand-green-600',
                ],
                [
                    'label' => 'Pending Reviews',
                    'value' => number_format($kpis['pendingReviews'] ?? 0),
                    'sub' => 'Avg rating '.($kpis['avgRating'] ?? 0).' ★ (approved)',
                    'hint' => ($kpis['pendingReviews'] ?? 0) > 0 ? 'Needs moderation' : 'All clear',
                    'icon' => 'star',
                    'iconBg' => 'bg-amber-50 text-amber-600',
                    'warn' => ($kpis['pendingReviews'] ?? 0) > 0,
                    'href' => route('admin.reviews.index', ['status' => 'pending']),
                ],
            ];
        ?>

        <?php $__currentLoopData = $kpiCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $cardTag = !empty($card['href']) ? 'a' : 'div'; ?>
            <<?php echo e($cardTag); ?> <?php if(!empty($card['href'])): ?> href="<?php echo e($card['href']); ?>" <?php endif; ?> class="admin-surface block p-4 transition-shadow hover:shadow-md">
                <div class="flex items-start justify-between gap-3">
                    <div class="min-w-0">
                        <p class="text-sm text-slate-500"><?php echo e($card['label']); ?></p>
                        <p class="mt-1 admin-page-title"><?php echo e($card['value']); ?></p>
                        <div class="mt-2 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs">
                            <?php if(!empty($card['hint'])): ?>
                                <span class="font-medium <?php echo e(!empty($card['warn']) ? 'text-brand-orange-600' : 'text-brand-green-600'); ?>"><?php echo e($card['hint']); ?></span>
                            <?php endif; ?>
                            <span class="text-slate-400"><?php echo e($card['sub']); ?></span>
                        </div>
                    </div>
                    <div class="shrink-0 rounded-lg p-2.5 <?php echo e($card['iconBg']); ?>">
                        <svg class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" aria-hidden="true">
                            <?php echo $lucide[$card['icon']] ?? $lucide['package']; ?>

                        </svg>
                    </div>
                </div>
            </<?php echo e($cardTag); ?>>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="grid grid-cols-1 gap-4 xl:grid-cols-3">
        
        <div class="admin-surface xl:col-span-2">
            <div class="flex items-center justify-between border-b border-slate-100 px-5 py-4">
                <h2 class="text-base font-bold text-slate-900">Revenue Overview</h2>
                <span class="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2.5 py-0.5 text-xs font-medium text-slate-600">
                    <svg class="h-3 w-3" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 3v16a2 2 0 0 0 2 2h16"/><path d="M18 17V9"/><path d="M13 17V5"/><path d="M8 17v-3"/></svg>
                    <?php echo e($range); ?> days
                </span>
            </div>
            <div class="p-5">
                <div class="relative h-64 w-full">
                    <canvas id="revenueChart" aria-label="Revenue over time"></canvas>
                </div>
            </div>
        </div>

        
        <div class="admin-surface">
            <div class="border-b border-slate-100 px-5 py-4">
                <h2 class="text-base font-bold text-slate-900">Order Status</h2>
            </div>
            <div class="p-5">
                <?php if(count($statusChart) === 0): ?>
                    <p class="py-16 text-center text-sm text-slate-500">No orders yet</p>
                <?php else: ?>
                    <div class="mx-auto flex max-w-xs flex-col items-center gap-4">
                        <div class="relative h-44 w-44">
                            <canvas id="statusChart" aria-label="Orders by status"></canvas>
                        </div>
                        <div class="grid w-full grid-cols-2 gap-1.5">
                            <?php $__currentLoopData = $statusChart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex items-center gap-2 text-xs">
                                    <span class="h-2.5 w-2.5 shrink-0 rounded-full" style="background-color: <?php echo e($chartColors[$i % count($chartColors)]); ?>"></span>
                                    <span class="min-w-0 flex-1 truncate text-slate-500"><?php echo e($entry['name']); ?></span>
                                    <span class="font-semibold text-slate-800"><?php echo e($entry['value']); ?></span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php if($expenses): ?>
        <div class="grid grid-cols-2 gap-3 xl:grid-cols-4">
            <?php
                $expenseCards = [
                    ['label' => 'Total Expenses', 'value' => $expenses['total'], 'sub' => 'All time'],
                    ['label' => 'This Month', 'value' => $expenses['thisMonth'], 'sub' => $expenses['thisMonthCount'].' expenses'],
                    ['label' => 'This Week', 'value' => $expenses['thisWeek'], 'sub' => $expenses['thisWeekCount'].' expenses'],
                    ['label' => 'Today', 'value' => $expenses['today'], 'sub' => $expenses['todayCount'].' expenses'],
                ];
            ?>
            <?php $__currentLoopData = $expenseCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="rounded-xl border border-slate-200 bg-white p-4 sm:p-5">
                    <div class="flex items-start justify-between gap-2">
                        <div>
                            <p class="text-xs text-slate-500 sm:text-sm"><?php echo e($ec['label']); ?></p>
                            <p class="mt-1 text-lg font-bold tracking-tight text-slate-900 sm:text-xl">৳<?php echo e(number_format($ec['value'], 0)); ?></p>
                            <p class="mt-1 text-[11px] text-slate-400 sm:text-xs"><?php echo e($ec['sub']); ?></p>
                        </div>
                        <div class="rounded-lg bg-red-50 p-2 text-red-600">
                            <svg class="h-4 w-4 sm:h-5 sm:w-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><?php echo $lucide['wallet']; ?></svg>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 gap-4 xl:grid-cols-3">
        
        <div class="admin-surface xl:col-span-2">
            <div class="flex items-center justify-between border-b border-slate-100 px-5 py-4">
                <h2 class="text-base font-bold text-slate-900">Recent Orders</h2>
                <a href="<?php echo e(route('admin.orders.index')); ?>" class="text-xs font-semibold text-brand-green-600 hover:text-brand-green-700">View all</a>
            </div>

            <?php if($recentOrders->isEmpty()): ?>
                <p class="p-6 text-sm text-slate-500">No orders yet</p>
            <?php else: ?>
                
                <div class="divide-y md:hidden">
                    <?php $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $badge = $statusBadges[$order->status] ?? 'bg-slate-100 text-slate-700 ring-slate-200';
                            $label = $statusLabels[$order->status] ?? ucfirst(str_replace('_', ' ', $order->status));
                            $initial = strtoupper(substr($order->customer_name ?? '?', 0, 1));
                            $created = \Carbon\Carbon::parse($order->created_at);
                        ?>
                        <a href="<?php echo e(route('admin.orders.show', $order->id)); ?>" class="flex items-center gap-3 px-4 py-3 transition hover:bg-slate-50">
                            <div class="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-slate-100 text-xs font-bold text-slate-600"><?php echo e($initial); ?></div>
                            <div class="min-w-0 flex-1">
                                <p class="truncate text-sm font-medium text-slate-900"><?php echo e($order->customer_name); ?></p>
                                <p class="text-xs text-slate-500"><?php echo e($order->order_id); ?> · <?php echo e($created->format('M j, Y')); ?></p>
                            </div>
                            <div class="flex shrink-0 flex-col items-end gap-1">
                                <span class="inline-flex rounded-full px-2 py-0.5 text-[10px] font-semibold ring-1 ring-inset <?php echo e($badge); ?>"><?php echo e($label); ?></span>
                                <span class="text-sm font-semibold text-slate-900">৳<?php echo e(number_format($order->total_price, 0)); ?></span>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                
                <div class="hidden overflow-x-auto md:block">
                    <table class="w-full text-left text-sm">
                        <thead class="border-b border-slate-100 bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                            <tr>
                                <th class="px-5 py-3">Customer</th>
                                <th class="px-5 py-3">Order</th>
                                <th class="px-5 py-3">Status</th>
                                <th class="px-5 py-3 text-right">Amount</th>
                                <th class="px-5 py-3 text-right">Date</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            <?php $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $badge = $statusBadges[$order->status] ?? 'bg-slate-100 text-slate-700 ring-slate-200';
                                    $label = $statusLabels[$order->status] ?? ucfirst(str_replace('_', ' ', $order->status));
                                    $initial = strtoupper(substr($order->customer_name ?? '?', 0, 1));
                                    $created = \Carbon\Carbon::parse($order->created_at);
                                ?>
                                <tr class="hover:bg-slate-50/80">
                                    <td class="px-5 py-3">
                                        <div class="flex items-center gap-3">
                                            <div class="flex h-8 w-8 items-center justify-center rounded-full bg-slate-100 text-xs font-bold text-slate-600"><?php echo e($initial); ?></div>
                                            <span class="font-medium text-slate-900"><?php echo e($order->customer_name); ?></span>
                                        </div>
                                    </td>
                                    <td class="px-5 py-3 font-mono text-xs text-brand-green-700"><?php echo e($order->order_id); ?></td>
                                    <td class="px-5 py-3">
                                        <span class="inline-flex rounded-full px-2.5 py-0.5 text-[10px] font-semibold ring-1 ring-inset <?php echo e($badge); ?>"><?php echo e($label); ?></span>
                                    </td>
                                    <td class="px-5 py-3 text-right font-semibold text-slate-900">৳<?php echo e(number_format($order->total_price, 0)); ?></td>
                                    <td class="px-5 py-3 text-right text-xs text-slate-500"><?php echo e($created->format('M j, Y')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        
        <div class="admin-surface">
            <div class="border-b border-slate-100 px-5 py-4">
                <h2 class="text-base font-bold text-slate-900">Top Products</h2>
            </div>
            <?php if(empty($topProducts)): ?>
                <p class="p-6 text-sm text-slate-500"><?php echo e($hasOrderItems ? 'No sales yet' : 'No order line items in database'); ?></p>
            <?php else: ?>
                <div class="divide-y divide-slate-100">
                    <?php $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center gap-3 px-5 py-2.5">
                            <span class="w-4 text-xs font-bold text-slate-400"><?php echo e($i + 1); ?></span>
                            <?php if($product['image']): ?>
                                <img src="<?php echo e($product['image']); ?>" alt="" class="h-9 w-9 shrink-0 rounded-md object-cover bg-slate-100" loading="lazy">
                            <?php else: ?>
                                <div class="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-slate-100 text-slate-400">
                                    <svg class="h-4 w-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><?php echo $lucide['package']; ?></svg>
                                </div>
                            <?php endif; ?>
                            <div class="min-w-0 flex-1">
                                <p class="truncate text-sm font-medium text-slate-900"><?php echo e($product['title']); ?></p>
                                <p class="text-xs text-slate-500"><?php echo e(number_format($product['quantity'])); ?> sold</p>
                            </div>
                            <span class="shrink-0 text-xs font-semibold text-slate-800">৳<?php echo e(number_format($product['revenue'], 0)); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="admin-surface">
        <div class="flex items-center justify-between border-b border-slate-100 px-5 py-4">
            <h2 class="text-base font-bold text-slate-900">Low Stock Alerts</h2>
            <a href="<?php echo e(route('admin.inventory.index')); ?>" class="text-xs font-semibold text-brand-green-600 hover:text-brand-green-700">Manage inventory</a>
        </div>
        <?php if(empty($lowStockProducts)): ?>
            <p class="p-6 text-sm text-slate-500">All products are well stocked</p>
        <?php else: ?>
            <div class="divide-y divide-slate-100">
                <?php $__currentLoopData = $lowStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center gap-3 px-4 py-3 sm:px-5">
                        <?php if($product['image']): ?>
                            <img src="<?php echo e($product['image']); ?>" alt="" class="h-9 w-9 shrink-0 rounded-md object-cover bg-slate-100" loading="lazy">
                        <?php else: ?>
                            <div class="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-slate-100 text-slate-400">
                                <svg class="h-4 w-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><?php echo $lucide['package']; ?></svg>
                            </div>
                        <?php endif; ?>
                        <div class="min-w-0 flex-1">
                            <p class="truncate text-sm font-medium text-slate-900"><?php echo e($product['title']); ?></p>
                            <p class="text-xs text-slate-500">৳<?php echo e(number_format($product['price'], 0)); ?></p>
                        </div>
                        <?php if(($product['stock'] ?? 0) <= 0): ?>
                            <span class="shrink-0 rounded-full bg-red-50 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-red-700 ring-1 ring-inset ring-red-200">Out of stock</span>
                        <?php else: ?>
                            <span class="shrink-0 rounded-full bg-amber-50 px-2.5 py-0.5 text-[10px] font-bold text-amber-800 ring-1 ring-inset ring-amber-200"><?php echo e($product['stock']); ?> left</span>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js" crossorigin="anonymous"></script>
<script>
(function () {
    const brandGreen = '#16a34a';
    const chartColors = <?php echo json_encode($chartColors, 15, 512) ?>;
    const revenueData = <?php echo json_encode($revenueChart, 15, 512) ?>;
    const statusData = <?php echo json_encode($statusChart, 15, 512) ?>;

    const fmtCurrency = (v) => '৳' + Number(v).toLocaleString(undefined, { maximumFractionDigits: 0 });

    const revEl = document.getElementById('revenueChart');
    if (revEl && revenueData.length) {
        const gradient = revEl.getContext('2d').createLinearGradient(0, 0, 0, 260);
        gradient.addColorStop(0, 'rgba(22, 163, 74, 0.25)');
        gradient.addColorStop(1, 'rgba(22, 163, 74, 0)');

        new Chart(revEl, {
            type: 'line',
            data: {
                labels: revenueData.map(d => d.label),
                datasets: [{
                    label: 'Revenue',
                    data: revenueData.map(d => d.revenue),
                    borderColor: brandGreen,
                    backgroundColor: gradient,
                    fill: true,
                    tension: 0.35,
                    pointRadius: revenueData.length > 60 ? 0 : 2,
                    pointHoverRadius: 4,
                    borderWidth: 2,
                }],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: (ctx) => fmtCurrency(ctx.parsed.y),
                        },
                    },
                },
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: { maxTicksLimit: 8, font: { size: 11 } },
                    },
                    y: {
                        grid: { color: 'rgba(148, 163, 184, 0.2)' },
                        ticks: {
                            font: { size: 11 },
                            callback: (v) => v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v,
                        },
                    },
                },
            },
        });
    }

    const statusEl = document.getElementById('statusChart');
    if (statusEl && statusData.length) {
        new Chart(statusEl, {
            type: 'doughnut',
            data: {
                labels: statusData.map(d => d.name),
                datasets: [{
                    data: statusData.map(d => d.value),
                    backgroundColor: statusData.map((_, i) => chartColors[i % chartColors.length]),
                    borderWidth: 0,
                    hoverOffset: 4,
                }],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '62%',
                plugins: {
                    legend: { display: false },
                },
            },
        });
    }
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', ['headerTitle' => 'Dashboard'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>