
<?php
    $sectionClass = 'rounded-[18px] border border-slate-100 bg-white p-4 shadow-soft sm:p-5';
    $titleClass = 'mb-3 text-xs font-extrabold uppercase tracking-[0.16em] text-slate-900';
    $rowClass = 'flex w-full items-center justify-between rounded-xl px-3 py-2 text-sm font-medium transition';
?>


<div class="<?php echo e($sectionClass); ?>" x-data="{ open: true }">
    <button type="button" class="flex w-full items-center justify-between" @click="open = !open">
        <h3 class="<?php echo e($titleClass); ?> mb-0">Categories</h3>
        <svg class="h-4 w-4 text-slate-400 transition" :class="open && 'rotate-180'" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
    </button>
    <div x-show="open" class="mt-3 space-y-0.5">
        <a href="<?php echo e($shopUrl([], ['category', 'subcategory'])); ?>"
           class="<?php echo e($rowClass); ?> <?php echo e(!$selectedCategory ? 'bg-brand-green-50 text-brand-green-700' : 'text-slate-600 hover:bg-slate-50'); ?>">
            All Products
        </a>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $isActive = $selectedCategory && $selectedCategory->id === $cat->id; ?>
            <div x-data="{ expanded: <?php echo e($isActive ? 'true' : 'false'); ?> }">
                <div class="flex items-center gap-1">
                    <a href="<?php echo e($shopUrl(['category' => $cat->slug], ['subcategory'])); ?>"
                       class="<?php echo e($rowClass); ?> flex-1 <?php echo e($isActive && !$selectedSubcategory ? 'bg-brand-green-50 text-brand-green-700' : ($isActive ? 'text-brand-green-700' : 'text-slate-600 hover:bg-slate-50')); ?>">
                        <span class="flex min-w-0 items-center gap-2.5">
                            <?php if($cat->image): ?>
                                <img src="<?php echo e($cat->image); ?>" alt="" class="h-5 w-5 rounded-md object-cover">
                            <?php else: ?>
                                <span class="flex h-5 w-5 shrink-0 items-center justify-center rounded-md bg-brand-green-50 text-[9px] font-black text-brand-green-700"><?php echo e(mb_substr($cat->name, 0, 1)); ?></span>
                            <?php endif; ?>
                            <span class="truncate"><?php echo e($cat->name); ?></span>
                        </span>
                        <span class="ml-2 shrink-0 text-[11px] text-slate-400"><?php echo e($cat->product_count ?? 0); ?></span>
                    </a>
                    <?php if($cat->children->isNotEmpty()): ?>
                        <button type="button" class="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100" @click="expanded = !expanded" :aria-expanded="expanded.toString()" aria-label="Toggle subcategories">
                            <svg class="h-3.5 w-3.5 transition" :class="expanded && 'rotate-180'" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                        </button>
                    <?php endif; ?>
                </div>
                <?php if($cat->children->isNotEmpty()): ?>
                    <div x-show="expanded" class="ml-4 space-y-0.5 border-l border-slate-100 pl-2">
                        <?php $__currentLoopData = $cat->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($shopUrl(['category' => $cat->slug, 'subcategory' => $child->slug])); ?>"
                               class="<?php echo e($rowClass); ?> <?php echo e(($selectedSubcategory->id ?? null) === $child->id ? 'bg-brand-green-50 text-brand-green-700' : 'text-slate-500 hover:bg-slate-50'); ?>">
                                <span class="truncate"><?php echo e($child->name); ?></span>
                                <span class="text-[11px] text-slate-400"><?php echo e($child->product_count ?? 0); ?></span>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


<?php if($selectedCategory && $subcategories->isNotEmpty()): ?>
<div class="<?php echo e($sectionClass); ?>" x-data="{ open: true }">
    <button type="button" class="flex w-full items-center justify-between" @click="open = !open">
        <h3 class="<?php echo e($titleClass); ?> mb-0">Subcategories</h3>
        <svg class="h-4 w-4 text-slate-400 transition" :class="open && 'rotate-180'" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
    </button>
    <div x-show="open" class="mt-3 space-y-0.5">
        <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($shopUrl(['category' => $selectedCategory->slug, 'subcategory' => $child->slug])); ?>"
               class="<?php echo e($rowClass); ?> <?php echo e(($selectedSubcategory->id ?? null) === $child->id ? 'bg-brand-green-50 text-brand-green-700' : 'text-slate-600 hover:bg-slate-50'); ?>">
                <span><?php echo e($child->name); ?></span>
                <span class="text-[11px] text-slate-400"><?php echo e($child->product_count ?? 0); ?></span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?>


<div class="<?php echo e($sectionClass); ?>" x-data="{ open: true, brandQ: '', showAll: false }">
    <button type="button" class="flex w-full items-center justify-between" @click="open = !open">
        <h3 class="<?php echo e($titleClass); ?> mb-0">Brands</h3>
        <svg class="h-4 w-4 text-slate-400 transition" :class="open && 'rotate-180'" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
    </button>
    <div x-show="open" class="mt-3 space-y-2">
        <input type="search" x-model="brandQ" placeholder="Search brands…" class="w-full rounded-full border border-slate-200 px-3 py-2 text-xs outline-none focus:border-brand-green-500" aria-label="Search brands">
        <div class="max-h-56 space-y-0.5 overflow-y-auto">
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(($selectedBrand->slug ?? null) === $brand->slug ? $shopUrl([], ['brand']) : $shopUrl(['brand' => $brand->slug])); ?>"
                   x-show="(!brandQ || <?php echo e(json_encode(mb_strtolower($brand->name))); ?>.includes(brandQ.toLowerCase())) && (showAll || <?php echo e($i); ?> < 8)"
                   class="<?php echo e($rowClass); ?> <?php echo e(($selectedBrand->slug ?? null) === $brand->slug ? 'bg-brand-green-50 text-brand-green-700' : 'text-slate-600 hover:bg-slate-50'); ?>">
                    <span class="flex min-w-0 items-center gap-2.5">
                        <?php if($brand->logo): ?>
                            <img src="<?php echo e($brand->logo); ?>" alt="" class="h-5 w-5 rounded-md object-contain">
                        <?php else: ?>
                            <span class="flex h-5 w-5 shrink-0 items-center justify-center rounded-md bg-brand-green-50 text-[9px] font-black text-brand-green-700"><?php echo e(mb_substr($brand->name, 0, 1)); ?></span>
                        <?php endif; ?>
                        <span class="truncate"><?php echo e($brand->name); ?></span>
                    </span>
                    <span class="text-[11px] text-slate-400"><?php echo e($brand->products_count); ?></span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php if($brands->count() > 8): ?>
            <button type="button" class="text-xs font-bold text-brand-green-600 hover:underline" @click="showAll = !showAll" x-text="showAll ? 'Show less' : 'Show more'"></button>
        <?php endif; ?>
    </div>
</div>


<div class="<?php echo e($sectionClass); ?>" x-data="{ open: true }">
    <button type="button" class="flex w-full items-center justify-between" @click="open = !open">
        <h3 class="<?php echo e($titleClass); ?> mb-0">Price Range</h3>
        <svg class="h-4 w-4 text-slate-400 transition" :class="open && 'rotate-180'" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
    </button>
    <div x-show="open" class="mt-3 space-y-3">
        <form method="GET" action="<?php echo e(route('shop')); ?>" class="space-y-2">
            <?php $__currentLoopData = request()->except(['minPrice', 'maxPrice', 'min_price', 'max_price', 'page']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(is_scalar($val)): ?>
                    <input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($val); ?>">
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="flex gap-2">
                <label class="sr-only" for="minPrice">Min price</label>
                <input id="minPrice" type="number" name="minPrice" min="0" step="1"
                       value="<?php echo e($minPrice !== null ? (int) $minPrice : ''); ?>"
                       placeholder="Min ৳" class="w-full rounded-full border border-slate-200 px-3 py-2 text-sm outline-none focus:border-brand-green-500">
                <label class="sr-only" for="maxPrice">Max price</label>
                <input id="maxPrice" type="number" name="maxPrice" min="0" step="1"
                       value="<?php echo e($maxPrice !== null ? (int) $maxPrice : ''); ?>"
                       placeholder="Max ৳" class="w-full rounded-full border border-slate-200 px-3 py-2 text-sm outline-none focus:border-brand-green-500">
            </div>
            <button type="submit" class="w-full rounded-full bg-brand-green-600 py-2 text-xs font-bold text-white hover:bg-brand-green-700">Apply</button>
        </form>
        <div class="space-y-1">
            <?php $__currentLoopData = $quickRanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $range): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $active = (int) ($minPrice ?? -1) === (int) ($range['min'] ?? -1)
                        && (int) ($maxPrice ?? -1) === (int) ($range['max'] ?? -1);
                ?>
                <a href="<?php echo e($shopUrl(['minPrice' => $range['min'], 'maxPrice' => $range['max']])); ?>"
                   class="<?php echo e($rowClass); ?> <?php echo e($active ? 'bg-brand-green-50 text-brand-green-700' : 'text-slate-600 hover:bg-slate-50'); ?>">
                    <?php echo e($range['label']); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>


<div class="<?php echo e($sectionClass); ?>" x-data="{ open: true }">
    <button type="button" class="flex w-full items-center justify-between" @click="open = !open">
        <h3 class="<?php echo e($titleClass); ?> mb-0">Availability</h3>
        <svg class="h-4 w-4 text-slate-400 transition" :class="open && 'rotate-180'" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
    </button>
    <div x-show="open" class="mt-3 space-y-1">
        <?php $__currentLoopData = [
            'in_stock' => ['In Stock', $stockCounts['in_stock'] ?? 0],
            'low_stock' => ['Low Stock', $stockCounts['low_stock'] ?? 0],
            'out_of_stock' => ['Out of Stock', $stockCounts['out_of_stock'] ?? 0],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => [$label, $count]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($availability === $key ? $shopUrl([], ['availability', 'stock']) : $shopUrl(['availability' => $key], ['stock'])); ?>"
               class="<?php echo e($rowClass); ?> <?php echo e($availability === $key ? 'bg-brand-green-50 text-brand-green-700' : 'text-slate-600 hover:bg-slate-50'); ?>">
                <span><?php echo e($label); ?></span>
                <span class="text-[11px] text-slate-400"><?php echo e($count); ?></span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e($onSale ? $shopUrl([], ['sale']) : $shopUrl(['sale' => '1'])); ?>"
           class="<?php echo e($rowClass); ?> <?php echo e($onSale ? 'bg-brand-orange-50 text-brand-orange-700' : 'text-slate-600 hover:bg-slate-50'); ?>">
            <span>On Sale</span>
        </a>
    </div>
</div>


<?php if(!empty($hasReviews)): ?>
<div class="<?php echo e($sectionClass); ?>" x-data="{ open: true }">
    <button type="button" class="flex w-full items-center justify-between" @click="open = !open">
        <h3 class="<?php echo e($titleClass); ?> mb-0">Rating</h3>
        <svg class="h-4 w-4 text-slate-400 transition" :class="open && 'rotate-180'" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
    </button>
    <div x-show="open" class="mt-3 space-y-1">
        <?php $__currentLoopData = [4.5, 4, 3]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e((float) $rating === (float) $r ? $shopUrl([], ['rating']) : $shopUrl(['rating' => $r])); ?>"
               class="<?php echo e($rowClass); ?> <?php echo e((float) $rating === (float) $r ? 'bg-brand-green-50 text-brand-green-700' : 'text-slate-600 hover:bg-slate-50'); ?>">
                <span class="text-amber-400"><?php echo e(str_repeat('★', (int) floor($r))); ?><?php echo e($r != floor($r) ? '☆' : ''); ?></span>
                <span>& up</span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?>


<?php if(!empty($hasColorData) && $colorOptions->isNotEmpty()): ?>
<div class="<?php echo e($sectionClass); ?>" x-data="{ open: true }">
    <button type="button" class="flex w-full items-center justify-between" @click="open = !open">
        <h3 class="<?php echo e($titleClass); ?> mb-0">Color</h3>
        <svg class="h-4 w-4 text-slate-400 transition" :class="open && 'rotate-180'" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
    </button>
    <div x-show="open" class="mt-3 flex flex-wrap gap-2">
        <?php $__currentLoopData = $colorOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($color === $c->name ? $shopUrl([], ['color']) : $shopUrl(['color' => $c->name])); ?>"
               title="<?php echo e($c->display_name ?? $c->name); ?>"
               class="flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold <?php echo e($color === $c->name ? 'border-brand-green-500 bg-brand-green-50 text-brand-green-700' : 'border-slate-200 text-slate-600'); ?>">
                <span class="h-3 w-3 rounded-full ring-1 ring-slate-200" style="background-color: <?php echo e($c->hex ?? '#ccc'); ?>"></span>
                <?php echo e($c->display_name ?? $c->name); ?>

            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?>


<?php if(!empty($hasSizeData) && $sizeOptions->isNotEmpty()): ?>
<div class="<?php echo e($sectionClass); ?>" x-data="{ open: true }">
    <button type="button" class="flex w-full items-center justify-between" @click="open = !open">
        <h3 class="<?php echo e($titleClass); ?> mb-0">Size</h3>
        <svg class="h-4 w-4 text-slate-400 transition" :class="open && 'rotate-180'" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
    </button>
    <div x-show="open" class="mt-3 flex flex-wrap gap-2">
        <?php $__currentLoopData = $sizeOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($size === $s->name ? $shopUrl([], ['size']) : $shopUrl(['size' => $s->name])); ?>"
               class="rounded-full border px-3 py-1 text-xs font-semibold <?php echo e($size === $s->name ? 'border-brand-green-500 bg-brand-green-50 text-brand-green-700' : 'border-slate-200 text-slate-600'); ?>">
                <?php echo e($s->name); ?>

            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?>


<?php if(!empty($popularTags) && count($popularTags) > 0): ?>
<div class="<?php echo e($sectionClass); ?>" x-data="{ open: true, tagSearch: '', showAllTags: false }">
    <button type="button" class="flex w-full items-center justify-between" @click="open = !open">
        <h3 class="<?php echo e($titleClass); ?> mb-0">Tags</h3>
        <svg class="h-4 w-4 text-slate-400 transition" :class="open && 'rotate-180'" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
    </button>
    <div x-show="open" class="mt-3 space-y-2.5">
        <?php if(count($popularTags) > 8): ?>
            <input type="search" x-model="tagSearch" placeholder="Search tags…" class="w-full rounded-full border border-slate-200 px-3 py-1.5 text-xs outline-none focus:border-brand-green-500" aria-label="Search tags">
        <?php endif; ?>
        <div class="flex flex-wrap gap-1.5">
            <?php $__currentLoopData = $popularTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $isTagActive = ($selectedTag ?? '') !== '' && (mb_strtolower($selectedTag) === mb_strtolower($t['name']));
                ?>
                <a href="<?php echo e($isTagActive ? $shopUrl([], ['tag']) : $shopUrl(['tag' => $t['name']])); ?>"
                   x-show="(!tagSearch || <?php echo e(json_encode(mb_strtolower($t['name']))); ?>.includes(tagSearch.toLowerCase())) && (showAllTags || <?php echo e($idx); ?> < 12 || <?php echo e($isTagActive ? 'true' : 'false'); ?>)"
                   class="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold transition <?php echo e($isTagActive ? 'bg-brand-green-600 text-white shadow-xs' : 'border border-slate-200 bg-slate-50 text-slate-600 hover:border-brand-green-300 hover:text-brand-green-700 hover:bg-brand-green-50'); ?>">
                    <span><?php echo e($t['name']); ?></span>
                    <?php if($isTagActive): ?>
                        <span class="text-white/80 hover:text-white" aria-hidden="true">×</span>
                    <?php else: ?>
                        <span class="text-[10px] text-slate-400">(<?php echo e($t['count']); ?>)</span>
                    <?php endif; ?>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php if(count($popularTags) > 12): ?>
            <button type="button" class="text-xs font-bold text-brand-green-600 hover:underline" @click="showAllTags = !showAllTags" x-text="showAllTags ? 'Show less tags' : 'Show more tags'"></button>
        <?php endif; ?>
        <?php if(($selectedTag ?? '') !== ''): ?>
            <div class="pt-1">
                <a href="<?php echo e($shopUrl([], ['tag'])); ?>" class="text-[11px] font-bold text-slate-500 hover:text-brand-orange-600">
                    ✕ Clear active tag
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<?php if(count($activeFilters ?? [])): ?>
    <a href="<?php echo e(route('shop')); ?>" class="block w-full rounded-full border border-slate-200 bg-white px-4 py-3 text-center text-sm font-bold text-slate-600 transition hover:border-brand-orange-400 hover:text-brand-orange-600">
        Clear all filters (<?php echo e(count($activeFilters)); ?>)
    </a>
<?php endif; ?>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/web/products/partials/filters.blade.php ENDPATH**/ ?>