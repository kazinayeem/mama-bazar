<?php $__env->startSection('content'); ?>
<div
    class="admin-page"
    x-data="{
        editOpen: false,
        editMethod: {},
        editUrl: '',
        failedEditId: <?php echo e(old('edit_id') ? (int) old('edit_id') : 'null'); ?>,
        itemsMap: <?php echo \Illuminate\Support\Js::from($methods->keyBy('id'))->toHtml() ?>,
        openEdit(m) {
            this.editMethod = { ...m };
            this.editUrl = '<?php echo e(route('admin.shipping.update', ':id')); ?>'.replace(':id', m.id);
            this.editOpen = true;
        }
    }"
    x-init="if (failedEditId && itemsMap[failedEditId]) openEdit(itemsMap[failedEditId])"
>
    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Shipping & Delivery','subtitle' => $methods->count().' methods · charges controlled here, never hardcoded at checkout']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Shipping & Delivery','subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($methods->count().' methods · charges controlled here, never hardcoded at checkout')]); ?>
         <?php $__env->slot('actions', null, []); ?> 
            <span class="hidden text-[11px] text-slate-400 sm:inline">Display order = Priority (low shows first)</span>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <?php if($errors->any()): ?>
        <div role="alert" class="rounded-[8px] border border-red-200 bg-red-50 px-4 py-3 text-xs text-red-700">
            <p class="font-bold">Please fix the following:</p>
            <ul class="mt-1 list-disc pl-5"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 gap-4 lg:grid-cols-3">
        
        <div class="admin-surface h-fit space-y-3 p-4">
            <h3 class="border-b border-[var(--admin-border)] pb-2.5 text-sm font-bold text-slate-900">Add Shipping Method</h3>
            <form action="<?php echo e(route('admin.shipping.store')); ?>" method="POST" class="space-y-3">
                <?php echo csrf_field(); ?>
                <div>
                    <label class="mb-1 block text-xs font-bold text-slate-700">Method Name *</label>
                    <input type="text" name="name" required value="<?php echo e(old('name')); ?>" placeholder="e.g. Standard Delivery (Inside Dhaka)" class="admin-control w-full text-xs">
                </div>
                <div class="grid grid-cols-2 gap-2">
                    <div>
                        <label class="mb-1 block text-xs font-bold text-slate-700">Charge (৳) *</label>
                        <input type="number" step="0.01" min="0" name="charge" required value="<?php echo e(old('charge', 60)); ?>" class="admin-control w-full text-xs">
                    </div>
                    <div>
                        <label class="mb-1 block text-xs font-bold text-slate-700">Priority</label>
                        <input type="number" name="priority" value="<?php echo e(old('priority', ($methods->max('priority') ?? 0) + 10)); ?>" class="admin-control w-full text-xs">
                    </div>
                </div>
                <div>
                    <label class="mb-1 block text-xs font-bold text-slate-700">Estimated Delivery Time</label>
                    <input type="text" name="estimated_delivery" value="<?php echo e(old('estimated_delivery')); ?>" placeholder="e.g. 24–48 hours" class="admin-control w-full text-xs">
                </div>
                <div>
                    <label class="mb-1 block text-xs font-bold text-slate-700">Description</label>
                    <textarea name="description" rows="2" placeholder="Short customer-facing description" class="admin-control w-full text-xs"><?php echo e(old('description')); ?></textarea>
                </div>
                <div>
                    <label class="mb-1 block text-xs font-bold text-slate-700">Applicable Areas <span class="font-normal text-slate-400">(blank = nationwide)</span></label>
                    <input type="text" name="applicable_areas" value="<?php echo e(old('applicable_areas')); ?>" placeholder="e.g. Dhaka, Gazipur — or: inside_dhaka" class="admin-control w-full text-xs">
                    <p class="mt-1 text-[11px] text-slate-400">Comma-separated districts. Use <code>inside_dhaka</code> / <code>outside_dhaka</code> for zone rules.</p>
                </div>
                <div class="grid grid-cols-2 gap-2">
                    <div>
                        <label class="mb-1 block text-xs font-bold text-slate-700">Free above (৳)</label>
                        <input type="number" step="0.01" min="0" name="free_shipping_min_amount" value="<?php echo e(old('free_shipping_min_amount')); ?>" placeholder="Optional" class="admin-control w-full text-xs">
                    </div>
                    <div>
                        <label class="mb-1 block text-xs font-bold text-slate-700">Status</label>
                        <select name="status" class="admin-control w-full text-xs bg-white">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                <label class="flex items-center gap-2 text-xs font-semibold text-slate-600 cursor-pointer">
                    <input type="checkbox" name="cod_available" value="1" checked class="rounded border-slate-300 text-brand-green-600 focus:ring-brand-green-500"> COD available for this method
                </label>
                <?php if (isset($component)) { $__componentOriginal60a020e5340f3f52bbc4501dc9f93102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.button','data' => ['type' => 'submit','size' => 'sm','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','size' => 'sm','class' => 'w-full']); ?>Create Shipping Method <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $attributes = $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $component = $__componentOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
            </form>
        </div>

        
        <div class="admin-table-wrap lg:col-span-2">
            <div class="flex flex-wrap items-center justify-between gap-2 border-b border-[var(--admin-border)] px-4 py-3">
                <p class="text-xs font-bold uppercase tracking-wider text-slate-600">Configured Methods (<?php echo e($methods->count()); ?>)</p>
                <?php if($methods->count() > 1): ?>
                <form action="<?php echo e(route('admin.shipping.reorder')); ?>" method="POST" class="flex items-center gap-1.5" id="reorderForm">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="order" id="reorderInput" value="">
                    <p class="text-[11px] text-slate-400">Drag with ↑ ↓ buttons, then</p>
                    <?php if (isset($component)) { $__componentOriginal60a020e5340f3f52bbc4501dc9f93102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.button','data' => ['type' => 'button','variant' => 'outline','size' => 'sm','onclick' => 'submitShippingOrder()']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'button','variant' => 'outline','size' => 'sm','onclick' => 'submitShippingOrder()']); ?>Save order <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $attributes = $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $component = $__componentOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
                </form>
                <?php endif; ?>
            </div>
            <?php if($methods->isEmpty()): ?>
                <?php if (isset($component)) { $__componentOriginal99089f8e2ef4184d7d35db81d60c6521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.empty-state','data' => ['title' => 'No shipping methods configured','description' => 'Add your first method — checkout will show a clear message until at least one is active.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'No shipping methods configured','description' => 'Add your first method — checkout will show a clear message until at least one is active.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $attributes = $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $component = $__componentOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
            <?php else: ?>
                <div class="divide-y divide-slate-100" id="shippingList">
                    <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-4" data-id="<?php echo e($m->id); ?>">
                        <div class="flex flex-wrap items-start justify-between gap-3">
                            <div class="min-w-0 flex-1">
                                <div class="flex flex-wrap items-center gap-2">
                                    <p class="text-sm font-bold text-slate-900"><?php echo e($m->name); ?></p>
                                    <?php if (isset($component)) { $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.badge','data' => ['variant' => $m->status === 'active' ? 'default' : 'muted']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($m->status === 'active' ? 'default' : 'muted')]); ?><?php echo e($m->status); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $attributes = $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $component = $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
                                    <?php if(!$m->cod_available): ?><?php if (isset($component)) { $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.badge','data' => ['variant' => 'warning']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'warning']); ?>No COD <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $attributes = $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $component = $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?><?php endif; ?>
                                </div>
                                <p class="mt-1 text-xs text-slate-500">
                                    <span class="font-extrabold text-brand-green-700">৳<?php echo e(number_format($m->charge, 0)); ?></span>
                                    · <?php echo e($m->estimated_delivery ?: 'Standard time'); ?>

                                    · Priority <?php echo e($m->priority); ?>

                                    <?php if($m->free_shipping_min_amount): ?><span class="text-brand-orange-600">· Free ≥ ৳<?php echo e(number_format($m->free_shipping_min_amount, 0)); ?></span><?php endif; ?>
                                </p>
                                <?php if($m->description): ?><p class="mt-0.5 text-xs text-slate-400"><?php echo e($m->description); ?></p><?php endif; ?>
                                <p class="mt-0.5 text-[11px] text-slate-400">Areas: <?php echo e($m->applicable_areas ?: 'Nationwide (all districts)'); ?></p>
                            </div>
                            <div class="flex shrink-0 items-center gap-1">
                                <span class="inline-flex flex-col gap-0.5 mr-0.5">
                                    <button type="button" onclick="moveShippingRow(this, -1)" title="Move up" class="rounded border border-slate-200 px-1 text-[10px] leading-4 text-slate-500 hover:bg-slate-100">▲</button>
                                    <button type="button" onclick="moveShippingRow(this, 1)" title="Move down" class="rounded border border-slate-200 px-1 text-[10px] leading-4 text-slate-500 hover:bg-slate-100">▼</button>
                                </span>
                                <form action="<?php echo e(route('admin.shipping.toggle', $m->id)); ?>" method="POST" class="inline"><?php echo csrf_field(); ?>
                                    <?php if (isset($component)) { $__componentOriginal60a020e5340f3f52bbc4501dc9f93102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.button','data' => ['type' => 'submit','variant' => 'outline','size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','variant' => 'outline','size' => 'sm']); ?><?php echo e($m->status === 'active' ? 'Disable' : 'Enable'); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $attributes = $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $component = $__componentOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
                                </form>
                                <button type="button" @click="openEdit(<?php echo \Illuminate\Support\Js::from($m)->toHtml() ?>)" class="inline-flex items-center justify-center gap-1.5 font-medium transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--admin-ring)] disabled:cursor-not-allowed disabled:opacity-50 whitespace-nowrap h-8 rounded-[6px] px-2.5 text-xs text-slate-600 hover:bg-slate-100">Edit</button>
                                <form action="<?php echo e(route('admin.shipping.destroy', $m->id)); ?>" method="POST" class="inline" onsubmit="return confirm('Delete/deactivate this method? Orders keep history.')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <?php if (isset($component)) { $__componentOriginal60a020e5340f3f52bbc4501dc9f93102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.button','data' => ['type' => 'submit','variant' => 'ghost','size' => 'sm','class' => 'text-red-600 hover:bg-red-50']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','variant' => 'ghost','size' => 'sm','class' => 'text-red-600 hover:bg-red-50']); ?>Delete <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $attributes = $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $component = $__componentOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    
    <?php if (isset($component)) { $__componentOriginal883972b03e56cea0994a1aaccc5761f0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal883972b03e56cea0994a1aaccc5761f0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.modal','data' => ['name' => 'editOpen','xTitle' => '\'Edit Shipping Method: \' + (editMethod ? editMethod.name : \'\')','maxWidth' => 'lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'editOpen','x-title' => '\'Edit Shipping Method: \' + (editMethod ? editMethod.name : \'\')','maxWidth' => 'lg']); ?>
        <form :action="editUrl" method="POST" class="grid gap-3.5 sm:grid-cols-2">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <input type="hidden" name="edit_id" :value="editMethod && editMethod.id ? editMethod.id : ''">
            <div class="sm:col-span-2">
                <label class="mb-1 block text-xs font-semibold text-slate-700">Method Name <span class="text-red-500">*</span></label>
                <input type="text" name="name" required x-model="editMethod.name" class="admin-control w-full text-xs">
            </div>
            <div>
                <label class="mb-1 block text-xs font-semibold text-slate-700">Charge (৳) <span class="text-red-500">*</span></label>
                <input type="number" step="0.01" min="0" name="charge" required x-model="editMethod.charge" class="admin-control w-full text-xs">
            </div>
            <div>
                <label class="mb-1 block text-xs font-semibold text-slate-700">Priority</label>
                <input type="number" name="priority" x-model="editMethod.priority" class="admin-control w-full text-xs">
            </div>
            <div>
                <label class="mb-1 block text-xs font-semibold text-slate-700">Estimated Delivery Time</label>
                <input type="text" name="estimated_delivery" x-model="editMethod.estimated_delivery" placeholder="e.g. 24–48 hours" class="admin-control w-full text-xs">
            </div>
            <div>
                <label class="mb-1 block text-xs font-semibold text-slate-700">Free Above (৳)</label>
                <input type="number" step="0.01" min="0" name="free_shipping_min_amount" x-model="editMethod.free_shipping_min_amount" placeholder="Optional" class="admin-control w-full text-xs">
            </div>
            <div class="sm:col-span-2">
                <label class="mb-1 block text-xs font-semibold text-slate-700">Description</label>
                <textarea name="description" rows="2" class="admin-control w-full text-xs" x-model="editMethod.description"></textarea>
            </div>
            <div class="sm:col-span-2">
                <label class="mb-1 block text-xs font-semibold text-slate-700">Applicable Areas (blank = nationwide)</label>
                <input type="text" name="applicable_areas" x-model="editMethod.applicable_areas" class="admin-control w-full text-xs">
            </div>
            <div>
                <label class="mb-1 block text-xs font-semibold text-slate-700">Status</label>
                <select name="status" class="admin-control w-full text-xs bg-white" x-model="editMethod.status">
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>
            <div class="flex items-center pt-5">
                <label class="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                    <input type="checkbox" name="cod_available" value="1" x-model="editMethod.cod_available" class="rounded border-slate-300 text-brand-green-600 focus:ring-brand-green-500">
                    <span>COD Available</span>
                </label>
            </div>
            <div class="flex items-center justify-end gap-2 pt-3 sm:col-span-2 border-t border-slate-100">
                <?php if (isset($component)) { $__componentOriginal60a020e5340f3f52bbc4501dc9f93102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.button','data' => ['type' => 'button','variant' => 'outline','size' => 'sm','@click' => 'editOpen = false']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'button','variant' => 'outline','size' => 'sm','@click' => 'editOpen = false']); ?>Cancel <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $attributes = $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $component = $__componentOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal60a020e5340f3f52bbc4501dc9f93102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.button','data' => ['type' => 'submit','size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','size' => 'sm']); ?>Save Changes <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $attributes = $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $component = $__componentOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
            </div>
        </form>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal883972b03e56cea0994a1aaccc5761f0)): ?>
<?php $attributes = $__attributesOriginal883972b03e56cea0994a1aaccc5761f0; ?>
<?php unset($__attributesOriginal883972b03e56cea0994a1aaccc5761f0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal883972b03e56cea0994a1aaccc5761f0)): ?>
<?php $component = $__componentOriginal883972b03e56cea0994a1aaccc5761f0; ?>
<?php unset($__componentOriginal883972b03e56cea0994a1aaccc5761f0); ?>
<?php endif; ?>
</div>
<?php $__env->startPush('scripts'); ?>
<script>
function moveShippingRow(btn, dir) {
    const row = btn.closest('#shippingList [data-id]');
    if (!row) return;
    const sibling = dir < 0 ? row.previousElementSibling : row.nextElementSibling;
    if (!sibling) return;
    if (dir < 0) row.parentNode.insertBefore(row, sibling);
    else row.parentNode.insertBefore(sibling, row);
}
function submitShippingOrder() {
    const ids = [...document.querySelectorAll('#shippingList [data-id]')].map(el => el.dataset.id);
    const form = document.getElementById('reorderForm');
    const body = new FormData();
    ids.forEach(id => body.append('order[]', id));
    fetch(form.action, { method: 'POST', headers: { 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>', 'Accept': 'application/json' }, body })
        .then(async (res) => {
            if (!res.ok) {
                let msg = 'Could not save the new order.';
                try { const j = await res.json(); if (j.message) msg = j.message; } catch (e) {}
                alert(msg);
                return;
            }
            window.location.reload();
        })
        .catch(() => alert('Network error while saving the order.'));
}
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', ['headerTitle' => 'Shipping & Delivery'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/admin/settings/shipping.blade.php ENDPATH**/ ?>