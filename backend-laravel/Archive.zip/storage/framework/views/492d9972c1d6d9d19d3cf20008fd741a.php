<?php $__env->startSection('account-title', 'Order ' . $order->order_id); ?>

<?php $__env->startSection('account-content'); ?>
<div class="space-y-6">

    
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div class="flex items-center gap-3">
            <a href="<?php echo e(route('account.orders')); ?>" class="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-600 shadow-xs hover:border-slate-300 hover:bg-slate-50 transition" title="Back to Orders">
                <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
            </a>
            <div>
                <div class="flex flex-wrap items-center gap-2">
                    <h2 class="text-xl font-extrabold text-slate-900 tracking-tight">Order #<?php echo e($order->order_id); ?></h2>
                    <?php
                        $statusStyles = match(strtolower($order->status)) {
                            'delivered' => 'bg-emerald-100 text-emerald-800 border-emerald-200',
                            'shipped', 'out_for_delivery' => 'bg-purple-100 text-purple-800 border-purple-200',
                            'processing', 'confirmed' => 'bg-blue-100 text-blue-800 border-blue-200',
                            'cancelled', 'returned' => 'bg-rose-100 text-rose-800 border-rose-200',
                            default => 'bg-amber-100 text-amber-800 border-amber-200',
                        };
                    ?>
                    <span class="inline-flex items-center rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider <?php echo e($statusStyles); ?>">
                        <?php echo e(str_replace('_', ' ', $order->status)); ?>

                    </span>
                </div>
                <p class="text-xs text-slate-500 mt-0.5">
                    Placed on <?php echo e($order->created_at?->format('l, F j, Y · h:i A')); ?>

                </p>
            </div>
        </div>

        <div class="flex items-center gap-2">
            <a href="<?php echo e(route('order.invoice', $order->order_id)); ?>" target="_blank"
               class="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 shadow-xs hover:border-brand-green-300 hover:bg-brand-green-50 transition">
                <svg class="h-4 w-4 text-brand-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                <span>Download Invoice</span>
            </a>

            <a href="<?php echo e(route('track', ['order_id' => $order->order_id, 'phone' => $order->phone])); ?>"
               class="inline-flex items-center gap-1.5 rounded-xl bg-brand-green-600 hover:bg-brand-green-700 px-3.5 py-2 text-xs font-bold text-white shadow-xs transition">
                <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/></svg>
                <span>Live Tracker</span>
            </a>
        </div>
    </div>

    
    <?php if(in_array(strtolower($order->status), ['cancelled', 'returned'])): ?>
        <div class="rounded-2xl border border-rose-200 bg-rose-50/70 p-4 sm:p-5 flex items-center gap-3">
            <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-rose-100 text-rose-700 font-bold">
                ✕
            </div>
            <div>
                <h3 class="text-sm font-bold text-rose-900">Order <?php echo e(ucfirst($order->status)); ?></h3>
                <p class="text-xs text-rose-700">This order has been <?php echo e(strtolower($order->status)); ?>. If you have any inquiries or need a refund verification, please reach out to customer helpline.</p>
            </div>
        </div>
    <?php else: ?>
        <div class="rounded-2xl border border-brand-green-100 bg-white p-5 sm:p-6 shadow-xs space-y-4">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold uppercase tracking-wider text-slate-500">Delivery Status Timeline</span>
                <?php if($order->courier_tracking_number): ?>
                    <span class="text-xs font-semibold text-brand-green-700 bg-brand-green-50 px-2.5 py-1 rounded-lg border border-brand-green-200">
                        Courier Tracking #: <?php echo e($order->courier_tracking_number); ?>

                    </span>
                <?php endif; ?>
            </div>

            <div class="py-2">
                <div class="grid grid-cols-5 text-center text-xs gap-1">
                    <?php $__currentLoopData = $milestones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $done = ($currentIdx >= $idx); ?>
                        <div class="flex flex-col items-center gap-2">
                            <div class="h-9 w-9 rounded-full flex items-center justify-center font-black text-xs transition <?php echo e($done ? 'bg-brand-green-500 text-white shadow-sm ring-4 ring-brand-green-100' : 'bg-slate-100 text-slate-400'); ?>">
                                <?php if($done && $currentIdx > $idx): ?>
                                    <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/></svg>
                                <?php else: ?>
                                    <?php echo e($idx + 1); ?>

                                <?php endif; ?>
                            </div>
                            <span class="font-bold text-[11px] leading-tight <?php echo e($done ? 'text-slate-900' : 'text-slate-400'); ?>">
                                <?php echo e($m['label']); ?>

                            </span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                
                <div class="flex mt-[-32px] mb-8 px-[10%]">
                    <?php $__currentLoopData = $milestones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($idx < count($milestones) - 1): ?>
                            <div class="flex-1 h-1 mt-4 mx-1 rounded-full <?php echo e($idx < $currentIdx ? 'bg-brand-green-500' : 'bg-slate-200'); ?>"></div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">

        
        <div class="lg:col-span-8 rounded-2xl border border-slate-200/80 bg-white shadow-xs overflow-hidden space-y-0">
            <div class="bg-slate-50/70 p-4 border-b border-slate-100 flex items-center justify-between">
                <h3 class="text-xs font-bold uppercase tracking-wider text-slate-700">
                    Ordered Products (<?php echo e($order->items->count()); ?>)
                </h3>
                <span class="text-xs font-semibold text-slate-500">Unit Price & Subtotal</span>
            </div>

            <div class="divide-y divide-slate-100">
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-4 sm:p-5 flex items-center gap-4 hover:bg-slate-50/50 transition">
                        <div class="flex h-16 w-16 shrink-0 items-center justify-center rounded-xl border border-slate-100 bg-slate-50 p-1">
                            <?php if($item->product && $item->product->featured_image): ?>
                                <img src="<?php echo e(asset('storage/' . $item->product->featured_image)); ?>" alt="<?php echo e($item->product_title); ?>" class="h-full w-full object-contain rounded-lg">
                            <?php else: ?>
                                <svg class="h-7 w-7 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
                            <?php endif; ?>
                        </div>

                        <div class="flex-1 min-w-0 space-y-1">
                            <h4 class="text-sm font-bold text-slate-900 truncate">
                                <?php echo e($item->product_title); ?>

                            </h4>
                            <div class="flex flex-wrap items-center gap-x-3 text-xs text-slate-500">
                                <?php if($item->product_sku): ?>
                                    <span>SKU: <strong class="text-slate-700"><?php echo e($item->product_sku); ?></strong></span>
                                <?php endif; ?>
                                <?php if($item->size): ?>
                                    <span>Size: <strong class="text-slate-700"><?php echo e($item->size); ?></strong></span>
                                <?php endif; ?>
                                <?php if($item->color): ?>
                                    <span>Color: <strong class="text-slate-700"><?php echo e($item->color); ?></strong></span>
                                <?php endif; ?>
                                <?php if($item->variant_name): ?>
                                    <span>Variant: <strong class="text-slate-700"><?php echo e($item->variant_name); ?></strong></span>
                                <?php endif; ?>
                            </div>
                            <div class="text-xs text-slate-600">
                                <span>৳<?php echo e(number_format($item->price, 0)); ?> &times; <?php echo e($item->quantity); ?></span>
                            </div>
                        </div>

                        <div class="text-right shrink-0">
                            <div class="text-sm font-black text-slate-900">
                                ৳<?php echo e(number_format($item->price * $item->quantity, 0)); ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            <div class="p-5 bg-slate-50/60 border-t border-slate-100 space-y-2 text-xs">
                <div class="flex items-center justify-between text-slate-600">
                    <span>Subtotal:</span>
                    <span class="font-bold text-slate-800">৳<?php echo e(number_format($order->subtotal, 0)); ?></span>
                </div>
                <div class="flex items-center justify-between text-slate-600">
                    <span>Delivery Charge:</span>
                    <span class="font-bold text-slate-800">৳<?php echo e(number_format($order->shipping_cost, 0)); ?></span>
                </div>
                <?php if($order->discount > 0): ?>
                    <div class="flex items-center justify-between text-emerald-700">
                        <span>Discount Coupon <?php if($order->coupon_code): ?> (<?php echo e($order->coupon_code); ?>) <?php endif; ?>:</span>
                        <span class="font-bold">-৳<?php echo e(number_format($order->discount, 0)); ?></span>
                    </div>
                <?php endif; ?>
                <?php if($order->tax > 0): ?>
                    <div class="flex items-center justify-between text-slate-600">
                        <span>Estimated Tax / VAT:</span>
                        <span class="font-bold text-slate-800">৳<?php echo e(number_format($order->tax, 0)); ?></span>
                    </div>
                <?php endif; ?>
                <div class="pt-2 border-t border-slate-200 flex items-center justify-between text-sm font-extrabold text-slate-900">
                    <span>Grand Total:</span>
                    <span class="text-base text-brand-green-700">৳<?php echo e(number_format($order->total_price, 0)); ?></span>
                </div>
            </div>
        </div>

        
        <div class="lg:col-span-4 space-y-5">

            
            <div class="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-xs space-y-3">
                <h3 class="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                    <svg class="h-4 w-4 text-brand-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/></svg>
                    <span>Shipping Address</span>
                </h3>
                <div class="space-y-1.5 text-xs text-slate-600">
                    <p class="font-bold text-slate-900 text-sm"><?php echo e($order->customer_name); ?></p>
                    <p class="text-slate-800 font-medium"><?php echo e($order->address); ?></p>
                    <?php if($order->apartment): ?>
                        <p class="text-[11px] text-slate-500">Apartment / House: <?php echo e($order->apartment); ?></p>
                    <?php endif; ?>
                    <p class="text-[11px] text-slate-500">
                        <?php echo e(implode(', ', array_filter([$order->area, $order->district, $order->division, $order->postal_code]))); ?>

                    </p>
                    <p class="pt-2 text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                        <svg class="h-3.5 w-3.5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                        <?php echo e($order->phone); ?>

                    </p>
                    <?php if($order->display_alternative_phone): ?>
                        <p class="text-xs text-slate-500">Alt Phone: <?php echo e($order->display_alternative_phone); ?></p>
                    <?php endif; ?>
                </div>
            </div>

            
            <div class="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-xs space-y-3">
                <h3 class="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                    <svg class="h-4 w-4 text-brand-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/></svg>
                    <span>Payment Information</span>
                </h3>
                <div class="space-y-2 text-xs">
                    <div class="flex items-center justify-between">
                        <span class="text-slate-500">Payment Method:</span>
                        <span class="font-bold text-slate-800 uppercase"><?php echo e($order->payment_method); ?></span>
                    </div>
                    <div class="flex items-center justify-between">
                        <span class="text-slate-500">Payment Status:</span>
                        <span class="font-bold text-slate-800 capitalize"><?php echo e($order->payment_status); ?></span>
                    </div>
                    <?php if($order->transaction_id): ?>
                        <div class="flex items-center justify-between">
                            <span class="text-slate-500">Transaction ID:</span>
                            <span class="font-mono text-slate-800"><?php echo e($order->transaction_id); ?></span>
                        </div>
                    <?php endif; ?>
                    <?php if($order->sender_number): ?>
                        <div class="flex items-center justify-between">
                            <span class="text-slate-500">Sender Number:</span>
                            <span class="text-slate-800"><?php echo e($order->sender_number); ?></span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            
            <?php if($order->shipping_method_name): ?>
                <div class="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-xs space-y-2 text-xs">
                    <h3 class="text-xs font-bold uppercase tracking-wider text-slate-500">Shipping Option</h3>
                    <p class="font-bold text-slate-800"><?php echo e($order->shipping_method_name); ?></p>
                    <?php if($order->order_note): ?>
                        <div class="pt-2 border-t border-slate-100">
                            <span class="text-[11px] text-slate-400 block">Customer Delivery Note:</span>
                            <p class="text-slate-600 italic mt-0.5"><?php echo e($order->order_note); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            
            <?php if($order->statusHistory->isNotEmpty()): ?>
                <div class="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-xs space-y-2">
                    <h3 class="text-xs font-bold uppercase tracking-wider text-slate-500">Activity History</h3>
                    <div class="space-y-2 pt-1 text-[11px]">
                        <?php $__currentLoopData = $order->statusHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex items-start gap-2 text-slate-600">
                                <span class="h-1.5 w-1.5 rounded-full bg-brand-green-500 mt-1.5 shrink-0"></span>
                                <div>
                                    <span class="font-bold capitalize text-slate-800"><?php echo e(str_replace('_', ' ', $hist->status)); ?></span>
                                    <span class="text-slate-400 ml-1">&bull; <?php echo e($hist->created_at?->format('M d, Y · h:i A')); ?></span>
                                    <?php if($hist->note): ?>
                                        <p class="text-slate-500 italic mt-0.5"><?php echo e($hist->note); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.account.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/web/account/order-details.blade.php ENDPATH**/ ?>