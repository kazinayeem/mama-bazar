<?php $items = $items ?? []; ?>
<?php if(count($items) > 0): ?>
<?php if (isset($component)) { $__componentOriginal177a6a1584d25b709c6540858fb05732 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal177a6a1584d25b709c6540858fb05732 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.homepage.section-shell','data' => ['section' => $section]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('homepage.section-shell'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($section)]); ?>
    <div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $title = $item['title'] ?? '';
                $text = $item['text'] ?? $item['description'] ?? '';
            ?>
            <div class="rounded-[10px] border border-brand-green-100 bg-white p-4 transition duration-200 hover:border-brand-green-300">
                <span class="flex h-10 w-10 items-center justify-center rounded-[8px] bg-brand-green-50 text-sm font-bold text-brand-green-700" aria-hidden="true">
                    <?php echo e(mb_substr($title, 0, 1)); ?>

                </span>
                <h3 class="mt-3 text-sm font-extrabold text-slate-900"><?php echo e($title); ?></h3>
                <?php if($text): ?>
                    <p class="mt-1.5 text-xs leading-5 text-slate-500"><?php echo e($text); ?></p>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal177a6a1584d25b709c6540858fb05732)): ?>
<?php $attributes = $__attributesOriginal177a6a1584d25b709c6540858fb05732; ?>
<?php unset($__attributesOriginal177a6a1584d25b709c6540858fb05732); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal177a6a1584d25b709c6540858fb05732)): ?>
<?php $component = $__componentOriginal177a6a1584d25b709c6540858fb05732; ?>
<?php unset($__componentOriginal177a6a1584d25b709c6540858fb05732); ?>
<?php endif; ?>
<?php endif; ?>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/web/homepage/partials/why-choose-us.blade.php ENDPATH**/ ?>