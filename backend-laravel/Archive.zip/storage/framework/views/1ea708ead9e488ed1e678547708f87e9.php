<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.products.partials.product-form', [
        'product' => null,
        'categories' => $categories,
        'brands' => $brands,
        'collections' => $collections,
        'vendors' => $vendors,
        'suppliers' => $suppliers,
        'colors' => $colors,
        'sizes' => $sizes,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', [
    'title' => 'Create Product',
    'headerTitle' => 'Create Product'
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/admin/products/create.blade.php ENDPATH**/ ?>