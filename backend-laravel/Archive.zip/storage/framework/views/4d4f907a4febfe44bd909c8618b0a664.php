<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
    @page { size: A4; margin: 12mm 11mm; }
    
    body { font-family: 'Hind Siliguri', 'DejaVu Sans', sans-serif; font-size: 11px; color: #1e293b; line-height: 1.45; }
    .header { width: 100%; border-bottom: 3px solid #0f4d2c; padding-bottom: 10px; }
    .header td { vertical-align: top; }
    .brand { font-size: 20px; font-weight: bold; }
    .meta { font-size: 10px; color: #475569; }
    .title { text-align: right; }
    .title h1 { font-size: 24px; color: #0f4d2c; letter-spacing: 2px; margin: 0; }
    .invno { font-size: 12px; font-weight: bold; color: #15803d; }
    .cols { width: 100%; margin-top: 12px; }
    .cols td { vertical-align: top; width: 50%; }
    .label { font-size: 9px; font-weight: bold; text-transform: uppercase; color: #94a3b8; letter-spacing: 1px; }
    table.items { width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 10.5px; }
    table.items th { background: #0f4d2c; color: #fff; padding: 7px 8px; text-align: left; font-size: 9px; text-transform: uppercase; }
    table.items td { padding: 7px 8px; border-bottom: 1px solid #e5e7eb; }
    table.totals { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 11px; }
    table.totals td { padding: 4px 8px; }
    table.totals .r { text-align: right; }
    .grand td { font-size: 14px; font-weight: bold; color: #0f4d2c; border-top: 2px solid #0f4d2c; padding-top: 8px; }
    .foot { margin-top: 16px; border-top: 1px solid #e2e8f0; padding-top: 10px; text-align: center; font-size: 10px; color: #64748b; }
    thead { display: table-header-group; }
    tr { page-break-inside: avoid; }
</style>
</head>
<body>

<table class="header">
    <tr>
        <td>
            <?php if(!empty($store['logo_base64'])): ?>
                <img src="<?php echo e($store['logo_base64']); ?>" style="height:40px;width:40px;" alt="">
            <?php endif; ?>
            <div class="brand"><?php echo e($store['name']); ?></div>
            <div class="meta"><?php echo e($store['tagline']); ?><br>
            <?php echo e($store['address']); ?><br>
            Phone: <?php echo e($store['phone']); ?> | Email: <?php echo e($store['email']); ?><br>
            Web: <?php echo e($store['website']); ?><?php if($store['tax_id']): ?> | Reg: <?php echo e($store['tax_id']); ?><?php endif; ?></div>
        </td>
        <td class="title">
            <h1>INVOICE</h1>
            <div class="invno"><?php echo e($order->invoice_number ?: $order->order_id); ?></div>
            <div class="meta">Order <?php echo e($order->order_id); ?><br><?php echo e($order->created_at?->format('F d, Y h:i A')); ?><br>Status: <?php echo e(ucfirst(str_replace('_', ' ', $order->status))); ?></div>
        </td>
    </tr>
</table>

<table class="cols">
    <tr>
        <td>
            <div class="label">Billed / Ship To</div>
            <strong><?php echo e($order->customer_name); ?></strong><br>
            <?php echo e($order->address); ?><?php if($order->apartment): ?>, <?php echo e($order->apartment); ?><?php endif; ?><br>
            <?php if($order->area): ?><?php echo e($order->area); ?>,<?php endif; ?> <?php if($order->upazila): ?><?php echo e($order->upazila); ?>,<?php endif; ?> <?php echo e($order->district); ?><?php if($order->postal_code): ?> — <?php echo e($order->postal_code); ?><?php endif; ?><br>
            Phone: <?php echo e($order->phone); ?><br>
            <?php if($order->display_alternative_phone): ?>Alternative Phone: <?php echo e($order->display_alternative_phone); ?><br><?php endif; ?>
            <?php if($order->email): ?>Email: <?php echo e($order->email); ?><br><?php endif; ?>
            <span style="color:#94a3b8;"><?php echo e($order->user_id ? 'Registered' : 'Guest'); ?></span>
        </td>
        <td style="text-align:right;">
            <div class="label">Payment &amp; Shipping</div>
            Payment: <strong><?php echo e(strtoupper($order->payment_method)); ?></strong><br>
            Pay status: <?php echo e(ucfirst(str_replace('_', ' ', $order->payment_status))); ?><br>
            Shipping: <?php echo e($order->shipping_method_name ?: 'Standard'); ?><br>
            <?php if($order->transaction_id): ?>Trx: <?php echo e($order->transaction_id); ?><br><?php endif; ?>
            <?php if($order->sender_number): ?>Sender: <?php echo e($order->sender_number); ?><br><?php endif; ?>
        </td>
    </tr>
</table>

<table class="items">
    <thead>
        <tr><th>Product</th><th>SKU</th><th>Variant</th><th style="text-align:center;">Qty</th><th style="text-align:right;">Unit</th><th style="text-align:right;">Total</th></tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><strong><?php echo e($item->product_title ?: ($item->product?->title ?: 'Product')); ?></strong><?php if($item->size || $item->color): ?><br><span style="color:#64748b;"><?php echo e(trim(($item->size ?: '') . ' / ' . ($item->color ?: ''), ' /')); ?></span><?php endif; ?></td>
            <td><?php echo e($item->product_sku ?: 'MB-' . $item->product_id); ?></td>
            <td><?php echo e($item->variant_name ?: ($item->variant?->name ?: '-')); ?></td>
            <td style="text-align:center;"><?php echo e($item->quantity); ?></td>
            <td style="text-align:right;">Tk <?php echo e(number_format($item->price, 0)); ?></td>
            <td style="text-align:right;"><strong>Tk <?php echo e(number_format($item->price * $item->quantity, 0)); ?></strong></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<table class="totals">
    <tr><td class="r" style="width:78%;">Subtotal</td><td class="r"><strong>Tk <?php echo e(number_format($order->subtotal, 0)); ?></strong></td></tr>
    <?php if((float) $order->discount > 0): ?>
    <tr><td class="r">Discount <?php if($order->coupon_code): ?>(<?php echo e($order->coupon_code); ?>)<?php endif; ?></td><td class="r">- Tk <?php echo e(number_format($order->discount, 0)); ?></td></tr>
    <?php endif; ?>
    <tr><td class="r">Delivery</td><td class="r">Tk <?php echo e(number_format($order->shipping_cost, 0)); ?></td></tr>
    <?php if((float) $order->tax > 0): ?>
    <tr><td class="r">VAT / Tax</td><td class="r">Tk <?php echo e(number_format($order->tax, 0)); ?></td></tr>
    <?php endif; ?>
    <tr class="grand"><td class="r">Total Payable</td><td class="r">Tk <?php echo e(number_format($order->total_price, 0)); ?></td></tr>
</table>

<div class="foot">
    <strong>Thank you for shopping with <?php echo e($store['name']); ?>!</strong><br>
    <?php echo e($store['return_policy']); ?><br>
    Helpline: <?php echo e($store['phone']); ?> | <?php echo e($store['email']); ?>

</div>

<?php echo $__env->make('pdf.branding-footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>
</html>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/admin/orders/invoice-pdf.blade.php ENDPATH**/ ?>