<?php
    $isArchived = ($product['productStatus'] ?? '') === 'archived';
    $status = $product['productStatus'] ?? ($product['status'] ?? 'draft');
    $variantsCount = isset($product['variants']) ? count($product['variants']) : 0;
    $stock = (int) ($product['stock'] ?? 0);
    $lowStockAlert = (int) ($product['lowStockAlert'] ?? 10);
    $firstImage = !empty($product['images'][0]) ? $product['images'][0] : null;
    $brandName = $product['brandInfo']['name'] ?? ($product['brand'] ?: null);
    $categoryName = $product['category']['name'] ?? null;
    $statusBadge = match($status) {
        'published', 'active' => 'bg-brand-green-50 text-brand-green-700 border-brand-green-200',
        'draft' => 'bg-slate-100 text-slate-600 border-slate-200',
        'hidden' => 'bg-amber-50 text-amber-700 border-amber-200',
        'archived' => 'bg-slate-200 text-slate-600 border-slate-300',
        default => 'bg-slate-100 text-slate-600 border-slate-200',
    };
?>
<tr class="h-[68px] hover:bg-slate-50/80 transition <?php echo e($isArchived ? 'opacity-50' : ''); ?>">
    <td class="px-3 py-2">
        <input type="checkbox" :value="<?php echo e($product['id']); ?>" x-model="selected"
               class="h-4 w-4 rounded border-slate-300 text-brand-green-600 focus:ring-brand-green-500" />
    </td>

    
    <td class="px-3 py-2">
        <div class="flex items-center gap-3 min-w-0">
            <?php if($firstImage): ?>
                <img src="<?php echo e($firstImage); ?>" alt="" class="h-11 w-11 shrink-0 rounded-lg border border-slate-200 object-cover bg-slate-50" loading="lazy" />
            <?php else: ?>
                <div class="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-slate-200 bg-slate-100 text-slate-400">
                    <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                </div>
            <?php endif; ?>
            <div class="min-w-0">
                <a href="<?php echo e(route('admin.products.show', $product['id'])); ?>"
                   title="<?php echo e($product['title']); ?>"
                   class="line-clamp-2 break-words text-[13px] font-semibold leading-snug text-slate-900 hover:text-brand-green-700">
                    <?php echo e($product['title']); ?>

                </a>
                <p class="mt-0.5 line-clamp-1 break-all font-mono text-[11px] text-slate-400"><?php echo e($product['sku'] ?: '—'); ?></p>
                <p class="line-clamp-1 break-words text-[11px] text-slate-500">
                    <?php echo e($brandName ?: '—'); ?> · <?php echo e($categoryName ?: '—'); ?>

                </p>
            </div>
        </div>
    </td>

    <td class="px-2 py-2 text-right whitespace-nowrap">
        <p class="text-sm font-bold text-slate-900">৳<?php echo e(number_format((float)($product['price'] ?? 0), 2)); ?></p>
        <?php if((float)($product['discount'] ?? 0) > 0): ?>
            <p class="text-[10px] font-semibold text-red-600">-<?php echo e($product['discount']); ?>%</p>
        <?php endif; ?>
        <?php if(isset($product['costPrice']) && (float) $product['costPrice'] > 0): ?>
            <p class="text-[10px] text-slate-500">Cost ৳<?php echo e(number_format((float) $product['costPrice'], 2)); ?></p>
        <?php endif; ?>
    </td>

    <td class="px-2 py-2 text-center">
        <?php if($variantsCount > 0): ?>
            <span class="inline-flex items-center rounded px-2 py-0.5 text-[10px] font-bold bg-violet-50 text-violet-700 border border-violet-200"><?php echo e($variantsCount); ?></span>
        <?php else: ?>
            <span class="text-[11px] text-slate-400">—</span>
        <?php endif; ?>
    </td>

    <td class="px-2 py-2 text-center">
        <?php if($stock <= 0): ?>
            <span class="inline-flex items-center rounded px-2 py-0.5 text-[10px] font-bold bg-red-50 text-red-700 border border-red-200">0</span>
        <?php elseif($stock <= $lowStockAlert): ?>
            <span class="inline-flex items-center rounded px-2 py-0.5 text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200"><?php echo e($stock); ?></span>
        <?php else: ?>
            <span class="inline-flex items-center rounded px-2 py-0.5 text-[10px] font-semibold bg-brand-green-50 text-brand-green-700 border border-brand-green-200"><?php echo e($stock); ?></span>
        <?php endif; ?>
    </td>

    <td class="px-2 py-2">
        <span class="inline-flex items-center rounded px-2 py-0.5 text-[10px] font-bold border capitalize <?php echo e($statusBadge); ?>"><?php echo e($status); ?></span>
    </td>

    <td class="px-2 py-2 text-center" x-data="{ featured: <?php echo e(!empty($product['isFeatured']) ? 'true' : 'false'); ?>, loading: false }">
        <button type="button"
                @click="
                    loading = true;
                    fetch('<?php echo e(route('admin.products.toggle-featured', $product['id'])); ?>', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrfToken, 'Accept': 'application/json' },
                        body: JSON.stringify({ featured: !featured })
                    })
                    .then(r => { if (!r.ok) throw new Error('Request failed'); return r.json(); })
                    .then(d => { featured = !!d.isFeatured; })
                    .catch(() => { alert('Could not update featured status. Please try again.'); })
                    .finally(() => { loading = false; })
                "
                :disabled="loading"
                class="relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden"
                :class="featured ? 'bg-brand-green-600' : 'bg-slate-300'"
                role="switch"
                :aria-checked="featured">
            <span class="pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm transition duration-200 ease-in-out"
                  :class="featured ? 'translate-x-4' : 'translate-x-0'"></span>
        </button>
    </td>

    <td class="hidden px-3 py-2 text-[11px] text-slate-500 whitespace-nowrap xl:table-cell">
        <?php echo e(!empty($product['createdAt']) ? \Carbon\Carbon::parse($product['createdAt'])->format('M d, Y') : '—'); ?>

    </td>

    <td class="sticky right-0 z-10 bg-white px-3 py-2 text-right" x-data="{ open: false }">
        <div class="relative inline-block text-left">
            <button type="button" @click="open = !open" @click.outside="open = false"
                    class="rounded-md p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700" aria-label="Actions">
                <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z"/></svg>
            </button>
            <div x-show="open" x-cloak class="absolute right-0 z-20 mt-1 w-48 overflow-hidden rounded-xl border border-slate-200 bg-white py-1 shadow-lg ring-1 ring-black/5">
                <a href="<?php echo e(route('admin.products.show', $product['id'])); ?>" class="block px-3 py-2 text-xs text-slate-700 hover:bg-slate-50">View</a>
                <?php if (\Illuminate\Support\Facades\Blade::check('adminCan', 'products.update')): ?>
                    <a href="<?php echo e(route('admin.products.edit', $product['id'])); ?>" class="block px-3 py-2 text-xs text-slate-700 hover:bg-slate-50">Edit</a>
                <?php endif; ?>
                <?php if (\Illuminate\Support\Facades\Blade::check('adminCan', 'products.create')): ?>
                    <button type="button" @click="open = false; duplicateProduct(<?php echo e($product['id']); ?>)" class="block w-full px-3 py-2 text-left text-xs text-slate-700 hover:bg-slate-50">Duplicate</button>
                <?php endif; ?>
                <?php if(!empty($product['slug'])): ?>
                    <div class="my-1 border-t border-slate-100"></div>
                    <a href="<?php echo e(url('/products/' . $product['slug'])); ?>" target="_blank" class="block px-3 py-2 text-xs text-slate-700 hover:bg-slate-50">View on storefront</a>
                <?php endif; ?>
                <?php if (\Illuminate\Support\Facades\Blade::check('adminCan', 'products.delete')): ?>
                    <div class="my-1 border-t border-slate-100"></div>
                    <button type="button" @click="open = false; confirmDelete(<?php echo e($product['id']); ?>, <?php echo \Illuminate\Support\Js::from($product['title'])->toHtml() ?>)" class="block w-full px-3 py-2 text-left text-xs text-red-600 hover:bg-red-50">Delete</button>
                <?php endif; ?>
            </div>
        </div>
    </td>
</tr>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/admin/products/partials/row-table.blade.php ENDPATH**/ ?>