<?php $__env->startSection('content'); ?>
<?php
    $advancedKeys = [
        'payment_status', 'payment_method', 'customer_type', 'customer_name', 'email', 'phone',
        'min_amount', 'max_amount', 'shipping_method', 'delivery_area', 'order_id', 'invoice_number',
        'product_search', 'sku', 'failed_emails', 'missing_info', 'attention_required',
        'start_date', 'end_date', 'month', 'year'
    ];
    $hasAdvancedActive = false;
    $advancedCount = 0;
    foreach ($advancedKeys as $ak) {
        if (!empty($params[$ak])) {
            $hasAdvancedActive = true;
            $advancedCount++;
        }
    }
    $currentPreset = $params['preset'] ?? '';
    $currentSort = $params['sort'] ?? 'newest';
    $currentDateRange = $params['date_range'] ?? '';
    $currentStatus = $params['status'] ?? '';
?>

<div class="admin-page space-y-5" x-data="{
    advancedOpen: <?php echo e($hasAdvancedActive ? 'true' : 'false'); ?>,
    datePreset: '<?php echo e($currentDateRange); ?>'
}">

    
    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Orders','subtitle' => $orders->total().' orders'.($summaryStats['is_filtered'] ? ' (filtered from overall store data)' : '')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Orders','subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($orders->total().' orders'.($summaryStats['is_filtered'] ? ' (filtered from overall store data)' : ''))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    
    <div class="space-y-2">
        <div class="flex items-center justify-between text-xs text-slate-500">
            <span class="font-semibold uppercase tracking-wider text-[11px]">
                <?php echo e($summaryStats['is_filtered'] ? 'Summary for current filtered orders' : 'Overall Store Summary'); ?>

            </span>
            <span class="text-[11px] text-slate-400">
                Completed Revenue excludes unpaid, cancelled, and refunded orders
            </span>
        </div>
        <div class="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-7">
            <?php if (isset($component)) { $__componentOriginal6787d12cf91691b0002d6d0db371a00e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6787d12cf91691b0002d6d0db371a00e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.metric-card','data' => ['label' => 'Total Orders','value' => number_format($summaryStats['total']),'hint' => ''.e($summaryStats['is_filtered'] ? 'Matching filters' : 'All time').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.metric-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Total Orders','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format($summaryStats['total'])),'hint' => ''.e($summaryStats['is_filtered'] ? 'Matching filters' : 'All time').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6787d12cf91691b0002d6d0db371a00e)): ?>
<?php $attributes = $__attributesOriginal6787d12cf91691b0002d6d0db371a00e; ?>
<?php unset($__attributesOriginal6787d12cf91691b0002d6d0db371a00e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6787d12cf91691b0002d6d0db371a00e)): ?>
<?php $component = $__componentOriginal6787d12cf91691b0002d6d0db371a00e; ?>
<?php unset($__componentOriginal6787d12cf91691b0002d6d0db371a00e); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal6787d12cf91691b0002d6d0db371a00e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6787d12cf91691b0002d6d0db371a00e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.metric-card','data' => ['label' => 'Pending','value' => number_format($summaryStats['pending']),'tone' => 'warning','hint' => 'Awaiting processing']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.metric-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Pending','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format($summaryStats['pending'])),'tone' => 'warning','hint' => 'Awaiting processing']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6787d12cf91691b0002d6d0db371a00e)): ?>
<?php $attributes = $__attributesOriginal6787d12cf91691b0002d6d0db371a00e; ?>
<?php unset($__attributesOriginal6787d12cf91691b0002d6d0db371a00e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6787d12cf91691b0002d6d0db371a00e)): ?>
<?php $component = $__componentOriginal6787d12cf91691b0002d6d0db371a00e; ?>
<?php unset($__componentOriginal6787d12cf91691b0002d6d0db371a00e); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal6787d12cf91691b0002d6d0db371a00e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6787d12cf91691b0002d6d0db371a00e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.metric-card','data' => ['label' => 'Paid','value' => number_format($summaryStats['paid']),'tone' => 'success','hint' => 'Verified or successful']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.metric-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Paid','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format($summaryStats['paid'])),'tone' => 'success','hint' => 'Verified or successful']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6787d12cf91691b0002d6d0db371a00e)): ?>
<?php $attributes = $__attributesOriginal6787d12cf91691b0002d6d0db371a00e; ?>
<?php unset($__attributesOriginal6787d12cf91691b0002d6d0db371a00e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6787d12cf91691b0002d6d0db371a00e)): ?>
<?php $component = $__componentOriginal6787d12cf91691b0002d6d0db371a00e; ?>
<?php unset($__componentOriginal6787d12cf91691b0002d6d0db371a00e); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal6787d12cf91691b0002d6d0db371a00e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6787d12cf91691b0002d6d0db371a00e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.metric-card','data' => ['label' => 'Unpaid','value' => number_format($summaryStats['unpaid']),'tone' => 'danger','hint' => 'Pending payment / COD']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.metric-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Unpaid','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format($summaryStats['unpaid'])),'tone' => 'danger','hint' => 'Pending payment / COD']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6787d12cf91691b0002d6d0db371a00e)): ?>
<?php $attributes = $__attributesOriginal6787d12cf91691b0002d6d0db371a00e; ?>
<?php unset($__attributesOriginal6787d12cf91691b0002d6d0db371a00e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6787d12cf91691b0002d6d0db371a00e)): ?>
<?php $component = $__componentOriginal6787d12cf91691b0002d6d0db371a00e; ?>
<?php unset($__componentOriginal6787d12cf91691b0002d6d0db371a00e); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal6787d12cf91691b0002d6d0db371a00e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6787d12cf91691b0002d6d0db371a00e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.metric-card','data' => ['label' => 'Delivered','value' => number_format($summaryStats['delivered']),'tone' => 'success','hint' => 'Completed orders']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.metric-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Delivered','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format($summaryStats['delivered'])),'tone' => 'success','hint' => 'Completed orders']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6787d12cf91691b0002d6d0db371a00e)): ?>
<?php $attributes = $__attributesOriginal6787d12cf91691b0002d6d0db371a00e; ?>
<?php unset($__attributesOriginal6787d12cf91691b0002d6d0db371a00e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6787d12cf91691b0002d6d0db371a00e)): ?>
<?php $component = $__componentOriginal6787d12cf91691b0002d6d0db371a00e; ?>
<?php unset($__componentOriginal6787d12cf91691b0002d6d0db371a00e); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal6787d12cf91691b0002d6d0db371a00e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6787d12cf91691b0002d6d0db371a00e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.metric-card','data' => ['label' => 'Cancelled / Ref.','value' => number_format($summaryStats['cancelled']),'tone' => 'danger','hint' => 'Returned or cancelled']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.metric-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Cancelled / Ref.','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format($summaryStats['cancelled'])),'tone' => 'danger','hint' => 'Returned or cancelled']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6787d12cf91691b0002d6d0db371a00e)): ?>
<?php $attributes = $__attributesOriginal6787d12cf91691b0002d6d0db371a00e; ?>
<?php unset($__attributesOriginal6787d12cf91691b0002d6d0db371a00e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6787d12cf91691b0002d6d0db371a00e)): ?>
<?php $component = $__componentOriginal6787d12cf91691b0002d6d0db371a00e; ?>
<?php unset($__componentOriginal6787d12cf91691b0002d6d0db371a00e); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal6787d12cf91691b0002d6d0db371a00e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6787d12cf91691b0002d6d0db371a00e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.metric-card','data' => ['label' => 'Completed Revenue','value' => '৳'.number_format($summaryStats['completed_revenue'], 0),'tone' => 'accent','hint' => 'Paid & delivered orders']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.metric-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Completed Revenue','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('৳'.number_format($summaryStats['completed_revenue'], 0)),'tone' => 'accent','hint' => 'Paid & delivered orders']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6787d12cf91691b0002d6d0db371a00e)): ?>
<?php $attributes = $__attributesOriginal6787d12cf91691b0002d6d0db371a00e; ?>
<?php unset($__attributesOriginal6787d12cf91691b0002d6d0db371a00e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6787d12cf91691b0002d6d0db371a00e)): ?>
<?php $component = $__componentOriginal6787d12cf91691b0002d6d0db371a00e; ?>
<?php unset($__componentOriginal6787d12cf91691b0002d6d0db371a00e); ?>
<?php endif; ?>
        </div>
    </div>

    
    <div class="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
        <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-1 shrink-0">Presets:</span>
        <?php
            $presets = [
                '' => 'All Orders',
                'today' => "Today's Orders",
                'pending' => 'Pending',
                'unpaid' => 'Unpaid',
                'ready_to_ship' => 'Ready to Ship',
                'delivered' => 'Delivered',
                'cancelled' => 'Cancelled / Refunded',
                'failed_emails' => 'Failed Emails',
            ];
        ?>
        <?php $__currentLoopData = $presets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pkey => $plabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $isActivePreset = ($currentPreset === $pkey) || ($pkey === '' && empty($currentPreset) && !$summaryStats['is_filtered']);
                $presetParams = $pkey ? array_merge($params, ['preset' => $pkey, 'page' => 1]) : ['sort' => $currentSort];
                if ($pkey === '') {
                    unset($presetParams['preset']);
                }
            ?>
            <a href="<?php echo e(route('admin.orders.index', $presetParams)); ?>"
               class="shrink-0 px-3 py-1.5 rounded-full font-semibold transition border <?php echo e($isActivePreset ? 'bg-brand-green-700 text-white border-brand-green-700 shadow-sm' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50 hover:text-slate-900'); ?>">
                <?php echo e($plabel); ?>

            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <form method="GET" action="<?php echo e(route('admin.orders.index')); ?>" class="space-y-3 bg-white p-4 rounded-xl border border-slate-200 shadow-sm" id="orderFilterForm">
        
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-3 items-center">
            
            <div class="lg:col-span-4">
                <div class="relative">
                    <input type="text"
                           name="search"
                           value="<?php echo e($params['search'] ?? ''); ?>"
                           placeholder="Search Order ID, customer, phone, email, SKU..."
                           class="admin-control w-full pl-9 text-xs" />
                    <svg class="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                </div>
            </div>

            
            <div class="lg:col-span-2">
                <select name="status" class="admin-control w-full text-xs">
                    <option value="">All Statuses</option>
                    <?php $__currentLoopData = \App\Services\OrderFilterService::VALID_STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stKey => $stLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($stKey); ?>" <?php if($currentStatus === $stKey): echo 'selected'; endif; ?>><?php echo e($stLabel); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <div class="lg:col-span-2">
                <select name="date_range" x-model="datePreset" class="admin-control w-full text-xs">
                    <option value="">All Time</option>
                    <?php $__currentLoopData = \App\Services\OrderFilterService::DATE_PRESETS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dKey => $dLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($dKey); ?>" <?php if($currentDateRange === $dKey): echo 'selected'; endif; ?>><?php echo e($dLabel); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <div class="lg:col-span-2">
                <select name="sort" class="admin-control w-full text-xs">
                    <?php $__currentLoopData = \App\Services\OrderFilterService::SORTS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sKey => $sLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sKey); ?>" <?php if($currentSort === $sKey): echo 'selected'; endif; ?>><?php echo e($sLabel); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <div class="lg:col-span-2 flex items-center gap-2">
                <button type="button"
                        @click="advancedOpen = !advancedOpen"
                        class="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg border text-xs font-bold transition <?php echo e($advancedCount > 0 ? 'border-brand-green-300 bg-brand-green-50 text-brand-green-800' : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'); ?>">
                    <svg class="w-3.5 h-3.5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"/></svg>
                    <span>Filters</span>
                    <?php if($advancedCount > 0): ?>
                        <span class="inline-flex items-center justify-center w-4 h-4 rounded-full bg-brand-green-700 text-white text-[10px] font-bold">
                            <?php echo e($advancedCount); ?>

                        </span>
                    <?php endif; ?>
                </button>

                <?php if (isset($component)) { $__componentOriginal60a020e5340f3f52bbc4501dc9f93102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.button','data' => ['type' => 'submit','size' => 'sm','class' => 'px-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','size' => 'sm','class' => 'px-4']); ?>Apply <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $attributes = $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $component = $__componentOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
                <?php if($summaryStats['is_filtered'] || !empty($params['search']) || !empty($params['sort']) && $params['sort'] !== 'newest'): ?>
                    <a href="<?php echo e(route('admin.orders.index', ['clear' => 1])); ?>"
                       class="px-2 py-2 rounded-lg text-xs font-semibold text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition"
                       title="Clear all filters">
                        ✕
                    </a>
                <?php endif; ?>
            </div>
        </div>

        
        <div x-show="datePreset === 'custom' || datePreset === 'month_year'" x-cloak class="pt-3 border-t border-slate-100 flex flex-wrap items-center gap-3">
            <template x-if="datePreset === 'custom'">
                <div class="flex flex-wrap items-center gap-3 text-xs">
                    <div>
                        <label class="block text-[11px] font-semibold text-slate-500 mb-1">Start Date</label>
                        <input type="date" name="start_date" value="<?php echo e($params['start_date'] ?? ''); ?>" class="admin-control text-xs" />
                    </div>
                    <div>
                        <label class="block text-[11px] font-semibold text-slate-500 mb-1">End Date</label>
                        <input type="date" name="end_date" value="<?php echo e($params['end_date'] ?? ''); ?>" class="admin-control text-xs" />
                    </div>
                </div>
            </template>
            <template x-if="datePreset === 'month_year'">
                <div class="flex flex-wrap items-center gap-3 text-xs">
                    <div>
                        <label class="block text-[11px] font-semibold text-slate-500 mb-1">Month</label>
                        <select name="month" class="admin-control text-xs">
                            <option value="">Select Month</option>
                            <?php for($m = 1; $m <= 12; $m++): ?>
                                <option value="<?php echo e($m); ?>" <?php if(($params['month'] ?? '') == $m): echo 'selected'; endif; ?>><?php echo e(date('F', mktime(0, 0, 0, $m, 1))); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-[11px] font-semibold text-slate-500 mb-1">Year</label>
                        <input type="number" name="year" value="<?php echo e($params['year'] ?? date('Y')); ?>" min="2020" max="2030" class="admin-control text-xs w-24" />
                    </div>
                </div>
            </template>
        </div>

        
        <div x-show="advancedOpen" x-cloak class="pt-4 mt-2 border-t border-slate-200/80 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
                
                <div class="space-y-2.5">
                    <h4 class="font-bold uppercase tracking-wider text-[11px] text-slate-500">Payment</h4>
                    <div>
                        <label class="block text-[11px] font-semibold text-slate-600 mb-1">Payment Status</label>
                        <select name="payment_status" class="admin-control w-full text-xs">
                            <option value="">All Payment Statuses</option>
                            <?php $__currentLoopData = \App\Services\OrderFilterService::VALID_PAYMENT_STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pKey => $pLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pKey); ?>" <?php if(($params['payment_status'] ?? '') === $pKey): echo 'selected'; endif; ?>><?php echo e($pLabel); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-[11px] font-semibold text-slate-600 mb-1">Payment Method</label>
                        <select name="payment_method" class="admin-control w-full text-xs">
                            <option value="">All Payment Methods</option>
                            <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pmKey => $pmLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pmKey); ?>" <?php if(($params['payment_method'] ?? '') === $pmKey): echo 'selected'; endif; ?>><?php echo e($pmLabel); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                
                <div class="space-y-2.5">
                    <h4 class="font-bold uppercase tracking-wider text-[11px] text-slate-500">Customer</h4>
                    <div>
                        <label class="block text-[11px] font-semibold text-slate-600 mb-1">Customer Account</label>
                        <select name="customer_type" class="admin-control w-full text-xs">
                            <option value="">All (Registered & Guest)</option>
                            <option value="registered" <?php if(($params['customer_type'] ?? '') === 'registered'): echo 'selected'; endif; ?>>Registered Customer</option>
                            <option value="guest" <?php if(($params['customer_type'] ?? '') === 'guest'): echo 'selected'; endif; ?>>Guest Checkout</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-[11px] font-semibold text-slate-600 mb-1">Customer Phone</label>
                        <input type="text" name="phone" value="<?php echo e($params['phone'] ?? ''); ?>" placeholder="Phone or alt phone" class="admin-control w-full text-xs" />
                    </div>
                    <div>
                        <label class="block text-[11px] font-semibold text-slate-600 mb-1">Customer Email</label>
                        <input type="text" name="email" value="<?php echo e($params['email'] ?? ''); ?>" placeholder="Email address" class="admin-control w-full text-xs" />
                    </div>
                </div>

                
                <div class="space-y-2.5">
                    <h4 class="font-bold uppercase tracking-wider text-[11px] text-slate-500">Amount & Shipping</h4>
                    <div class="grid grid-cols-2 gap-2">
                        <div>
                            <label class="block text-[11px] font-semibold text-slate-600 mb-1">Min Price (৳)</label>
                            <input type="number" name="min_amount" value="<?php echo e($params['min_amount'] ?? ''); ?>" placeholder="0" class="admin-control w-full text-xs" />
                        </div>
                        <div>
                            <label class="block text-[11px] font-semibold text-slate-600 mb-1">Max Price (৳)</label>
                            <input type="number" name="max_amount" value="<?php echo e($params['max_amount'] ?? ''); ?>" placeholder="10000" class="admin-control w-full text-xs" />
                        </div>
                    </div>
                    <div>
                        <label class="block text-[11px] font-semibold text-slate-600 mb-1">Shipping Method</label>
                        <select name="shipping_method" class="admin-control w-full text-xs">
                            <option value="">All Shipping Methods</option>
                            <?php $__currentLoopData = $shippingMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sm->id); ?>" <?php if(($params['shipping_method'] ?? '') == $sm->id): echo 'selected'; endif; ?>><?php echo e($sm->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-[11px] font-semibold text-slate-600 mb-1">Delivery District / Area</label>
                        <input type="text" name="delivery_area" value="<?php echo e($params['delivery_area'] ?? ''); ?>" placeholder="e.g. Dhaka, Chittagong, Mirpur" class="admin-control w-full text-xs" />
                    </div>
                </div>

                
                <div class="space-y-2.5">
                    <h4 class="font-bold uppercase tracking-wider text-[11px] text-slate-500">Products & Conditions</h4>
                    <div>
                        <label class="block text-[11px] font-semibold text-slate-600 mb-1">Contains Product or SKU</label>
                        <input type="text" name="product_search" value="<?php echo e($params['product_search'] ?? ''); ?>" placeholder="Product title or SKU" class="admin-control w-full text-xs" />
                    </div>
                    <div class="pt-2 space-y-2">
                        <label class="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-700">
                            <input type="checkbox" name="failed_emails" value="1" <?php if(!empty($params['failed_emails'])): echo 'checked'; endif; ?> class="rounded border-slate-300 text-brand-green-700 focus:ring-brand-green-600" />
                            <span>Failed email notifications</span>
                        </label>
                        <label class="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-700">
                            <input type="checkbox" name="missing_info" value="1" <?php if(!empty($params['missing_info'])): echo 'checked'; endif; ?> class="rounded border-slate-300 text-brand-green-700 focus:ring-brand-green-600" />
                            <span>Missing contact/address info</span>
                        </label>
                        <label class="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-700">
                            <input type="checkbox" name="attention_required" value="1" <?php if(!empty($params['attention_required'])): echo 'checked'; endif; ?> class="rounded border-slate-300 text-brand-green-700 focus:ring-brand-green-600" />
                            <span>Requires attention</span>
                        </label>
                    </div>
                </div>
            </div>

            
            <div class="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <a href="<?php echo e(route('admin.orders.index', ['clear' => 1])); ?>" class="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-100 transition">
                    Clear All Filters
                </a>
                <?php if (isset($component)) { $__componentOriginal60a020e5340f3f52bbc4501dc9f93102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.button','data' => ['type' => 'submit','size' => 'sm','class' => 'px-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','size' => 'sm','class' => 'px-5']); ?>
                    Apply Advanced Filters
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $attributes = $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $component = $__componentOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
            </div>
        </div>
    </form>

    
    <?php if(!empty($activeChips)): ?>
        <div class="flex flex-wrap items-center gap-2 bg-slate-50 p-3 rounded-xl border border-slate-200/80 text-xs">
            <span class="font-bold text-slate-500 uppercase text-[10px] tracking-wider">Active Filters:</span>
            <?php $__currentLoopData = $activeChips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                    <span><?php echo e($chip['label']); ?></span>
                    <a href="<?php echo e($chip['remove_url']); ?>" class="text-emerald-500 hover:text-emerald-800 font-bold ml-0.5" title="Remove filter">✕</a>
                </span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('admin.orders.index', ['clear' => 1])); ?>" class="text-xs font-bold text-rose-600 hover:text-rose-800 underline ml-2">
                Clear All
            </a>
            <span class="text-xs font-semibold text-slate-400 ml-auto">
                Found <?php echo e($orders->total()); ?> matching orders
            </span>
        </div>
    <?php endif; ?>

    
    <div class="admin-table-wrap">
        <?php if($orders->isEmpty()): ?>
            <div class="text-center py-12 px-4 bg-white rounded-xl border border-slate-200">
                <div class="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400 mb-3">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                </div>
                <h3 class="text-sm font-bold text-slate-900 mb-1">No orders found</h3>
                <p class="text-xs text-slate-500 max-w-sm mx-auto mb-4">No orders match your active search terms or filter criteria. Try adjusting or clearing your filters.</p>
                <a href="<?php echo e(route('admin.orders.index', ['clear' => 1])); ?>" class="inline-flex items-center px-4 py-2 rounded-xl bg-brand-green-700 text-white text-xs font-bold hover:bg-brand-green-800 transition">
                    Reset All Filters
                </a>
            </div>
        <?php else: ?>
            
            <div class="md:hidden space-y-3">
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $statusVariant = match(true) {
                            $ord->status === 'delivered' => 'success',
                            in_array($ord->status, ['pending', 'processing', 'confirmed'], true) => 'warning',
                            in_array($ord->status, ['cancelled', 'refunded'], true) => 'destructive',
                            $ord->status === 'shipped' => 'secondary',
                            default => 'muted',
                        };
                        $orderDetailUrl = route('admin.orders.show', array_merge(['id' => $ord->id], request()->query()));
                    ?>
                    <div class="admin-mobile-card">
                        <div class="flex items-start justify-between gap-3">
                            <div class="min-w-0">
                                <a href="<?php echo e($orderDetailUrl); ?>" class="text-sm font-bold text-brand-green-700 hover:underline"><?php echo e($ord->order_id); ?></a>
                                <p class="mt-0.5 truncate text-sm font-semibold text-slate-900"><?php echo e($ord->customer_name); ?></p>
                                <p class="text-xs text-slate-500"><?php echo e($ord->phone); ?></p>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.badge','data' => ['variant' => $statusVariant]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($statusVariant)]); ?><?php echo e($ord->status); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $attributes = $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $component = $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
                        </div>
                        <dl class="mt-3 grid grid-cols-2 gap-x-3 gap-y-2 text-xs">
                            <div>
                                <dt class="font-semibold uppercase tracking-wide text-slate-400">Items</dt>
                                <dd class="font-semibold text-slate-800"><?php echo e($ord->items->count()); ?></dd>
                            </div>
                            <div>
                                <dt class="font-semibold uppercase tracking-wide text-slate-400">Total</dt>
                                <dd class="font-bold text-slate-900">৳<?php echo e(number_format($ord->total_price, 0)); ?></dd>
                            </div>
                            <div>
                                <dt class="font-semibold uppercase tracking-wide text-slate-400">Payment</dt>
                                <dd class="text-slate-700">
                                    <span class="uppercase font-semibold"><?php echo e($ord->payment_method); ?></span>
                                    <span class="<?php echo e(in_array($ord->payment_status, ['success', 'verified'], true) ? 'text-emerald-600' : 'text-amber-600'); ?>"> · <?php echo e(ucfirst(str_replace('_', ' ', $ord->payment_status))); ?></span>
                                </dd>
                            </div>
                            <div>
                                <dt class="font-semibold uppercase tracking-wide text-slate-400">Date</dt>
                                <dd class="text-slate-600"><?php echo e($ord->created_at->format('M d, Y')); ?></dd>
                            </div>
                        </dl>
                        <div class="mt-3 flex gap-2">
                            <?php if (isset($component)) { $__componentOriginal60a020e5340f3f52bbc4501dc9f93102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.button','data' => ['href' => $orderDetailUrl,'variant' => 'outline','size' => 'sm','class' => 'flex-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($orderDetailUrl),'variant' => 'outline','size' => 'sm','class' => 'flex-1']); ?>Details <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $attributes = $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $component = $__componentOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal60a020e5340f3f52bbc4501dc9f93102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.button','data' => ['href' => route('admin.orders.invoice', $ord->id),'variant' => 'outline','size' => 'sm','class' => 'flex-1','target' => '_blank']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.orders.invoice', $ord->id)),'variant' => 'outline','size' => 'sm','class' => 'flex-1','target' => '_blank']); ?>Invoice <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $attributes = $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $component = $__componentOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            <div class="hidden overflow-x-auto md:block">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer</th>
                            <th>Items</th>
                            <th>Total</th>
                            <th class="admin-hide-sm">Payment</th>
                            <th>Status</th>
                            <th class="admin-hide-md">Date</th>
                            <th class="text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $statusVariant = match(true) {
                                    $ord->status === 'delivered' => 'success',
                                    in_array($ord->status, ['pending', 'processing', 'confirmed'], true) => 'warning',
                                    in_array($ord->status, ['cancelled', 'refunded'], true) => 'destructive',
                                    $ord->status === 'shipped' => 'secondary',
                                    default => 'muted',
                                };
                                $orderDetailUrl = route('admin.orders.show', array_merge(['id' => $ord->id], request()->query()));
                            ?>
                            <tr>
                                <td class="font-bold text-brand-green-700">
                                    <a href="<?php echo e($orderDetailUrl); ?>" class="hover:underline"><?php echo e($ord->order_id); ?></a>
                                </td>
                                <td>
                                    <span class="block font-semibold text-slate-900"><?php echo e($ord->customer_name); ?></span>
                                    <span class="text-[11px] text-slate-400"><?php echo e($ord->phone); ?></span>
                                </td>
                                <td class="text-slate-600"><?php echo e($ord->items->count()); ?></td>
                                <td class="font-bold text-slate-900">৳<?php echo e(number_format($ord->total_price, 0)); ?></td>
                                <td class="admin-hide-sm">
                                    <span class="block text-[10px] font-bold uppercase text-slate-700"><?php echo e($ord->payment_method); ?></span>
                                    <span class="text-[10px] font-semibold <?php echo e(in_array($ord->payment_status, ['success', 'verified'], true) ? 'text-emerald-600' : 'text-amber-600'); ?>"><?php echo e(ucfirst(str_replace('_', ' ', $ord->payment_status))); ?></span>
                                </td>
                                <td><?php if (isset($component)) { $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.badge','data' => ['variant' => $statusVariant]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($statusVariant)]); ?><?php echo e($ord->status); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $attributes = $__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__attributesOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33)): ?>
<?php $component = $__componentOriginal92e51077c3bdcbfa01c516c134fd0f33; ?>
<?php unset($__componentOriginal92e51077c3bdcbfa01c516c134fd0f33); ?>
<?php endif; ?></td>
                                <td class="admin-hide-md text-slate-500"><?php echo e($ord->created_at->format('M d, Y')); ?></td>
                                <td class="text-right">
                                    <div class="inline-flex items-center gap-1" x-data="{ open: false }">
                                        <?php if (isset($component)) { $__componentOriginal60a020e5340f3f52bbc4501dc9f93102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.button','data' => ['href' => $orderDetailUrl,'variant' => 'outline','size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($orderDetailUrl),'variant' => 'outline','size' => 'sm']); ?>Details <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $attributes = $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $component = $__componentOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal60a020e5340f3f52bbc4501dc9f93102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.button','data' => ['href' => route('admin.orders.invoice', $ord->id),'variant' => 'ghost','size' => 'sm','target' => '_blank']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.orders.invoice', $ord->id)),'variant' => 'ghost','size' => 'sm','target' => '_blank']); ?>Invoice <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $attributes = $__attributesOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__attributesOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102)): ?>
<?php $component = $__componentOriginal60a020e5340f3f52bbc4501dc9f93102; ?>
<?php unset($__componentOriginal60a020e5340f3f52bbc4501dc9f93102); ?>
<?php endif; ?>
                                        <div class="relative">
                                            <button @click="open = !open" @click.away="open = false" class="rounded-[6px] px-2 py-1.5 text-xs font-bold text-slate-500 hover:bg-slate-100">▾</button>
                                            <div x-show="open" x-cloak class="absolute right-0 z-50 mt-1 w-44 overflow-hidden rounded-lg border border-slate-200 bg-white shadow-xl py-1 text-left">
                                                <a href="<?php echo e(route('admin.orders.invoice.download', $ord->id)); ?>" class="block px-3 py-2 text-xs font-semibold hover:bg-slate-50">Download PDF</a>
                                                <a href="<?php echo e(route('admin.orders.packing-slip', $ord->id)); ?>" target="_blank" class="block px-3 py-2 text-xs font-semibold hover:bg-slate-50">Packing Slip</a>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php if (isset($component)) { $__componentOriginal1f9437379ffbb940ff05ba93353d3cd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9437379ffbb940ff05ba93353d3cd5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.pagination','data' => ['paginator' => $orders]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($orders)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9437379ffbb940ff05ba93353d3cd5)): ?>
<?php $attributes = $__attributesOriginal1f9437379ffbb940ff05ba93353d3cd5; ?>
<?php unset($__attributesOriginal1f9437379ffbb940ff05ba93353d3cd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9437379ffbb940ff05ba93353d3cd5)): ?>
<?php $component = $__componentOriginal1f9437379ffbb940ff05ba93353d3cd5; ?>
<?php unset($__componentOriginal1f9437379ffbb940ff05ba93353d3cd5); ?>
<?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', ['headerTitle' => 'Order Management'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/admin/orders/index.blade.php ENDPATH**/ ?>