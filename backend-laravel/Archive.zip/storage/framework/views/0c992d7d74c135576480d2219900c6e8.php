<?php
    $adminUrl = function (array $overrides = [], array $remove = []) {
        $query = request()->query();
        foreach ($remove as $key) {
            unset($query[$key]);
        }
        foreach ($overrides as $key => $value) {
            if ($value === null || $value === '' || $value === false) {
                unset($query[$key]);
            } else {
                $query[$key] = $value;
            }
        }
        if (! array_key_exists('page', $overrides)) {
            unset($query['page']);
        }
        unset($query['view']);
        return route('admin.products.index', $query);
    };

    $chips = [];
    if (request('search')) {
        $chips[] = ['keys' => ['search'], 'label' => 'Search: '.request('search')];
    }
    if (request('category')) {
        $cat = $categories->first(fn ($c) => ($c->slug ?: (string) $c->id) == request('category'));
        $chips[] = ['keys' => ['category'], 'label' => $cat?->name ?? request('category')];
    }
    if (request('brand')) {
        $b = $brands->first(fn ($x) => ($x->slug ?: (string) $x->id) == request('brand'));
        $chips[] = ['keys' => ['brand'], 'label' => $b?->name ?? request('brand')];
    }
    if (request('supplier')) {
        $s = $suppliers->first(fn ($x) => ($x->slug ?: (string) $x->id) == request('supplier'));
        $chips[] = ['keys' => ['supplier'], 'label' => 'Supplier: '.($s?->name ?? request('supplier'))];
    }
    if (request('vendor')) {
        $v = $vendors->first(fn ($x) => ($x->slug ?: (string) $x->id) == request('vendor'));
        $chips[] = ['keys' => ['vendor'], 'label' => 'Vendor: '.($v?->name ?? request('vendor'))];
    }
    if (request('collection')) {
        $col = $collections->first(fn ($x) => ($x->slug ?: (string) $x->id) == request('collection'));
        $chips[] = ['keys' => ['collection'], 'label' => $col?->name ?? request('collection')];
    }
    if (request('stock')) {
        $chips[] = ['keys' => ['stock'], 'label' => str_replace('_', ' ', ucfirst(request('stock')))];
    }
    if (request('productStatus')) {
        $chips[] = ['keys' => ['productStatus'], 'label' => 'Status: '.ucfirst(request('productStatus'))];
    }
    if (request('label')) {
        $chips[] = ['keys' => ['label'], 'label' => 'Label: '.str_replace('_', ' ', request('label'))];
    }
    if (request()->filled('minPrice') || request()->filled('maxPrice')) {
        $chips[] = ['keys' => ['minPrice', 'maxPrice'], 'label' => '৳'.(request('minPrice') ?: '0').'–৳'.(request('maxPrice') ?: '∞')];
    }
    if (request('dateFrom') || request('dateTo')) {
        $chips[] = ['keys' => ['dateFrom', 'dateTo'], 'label' => 'Date: '.(request('dateFrom') ?: '…').' → '.(request('dateTo') ?: '…')];
    }

    $from = $total === 0 ? 0 : (($page - 1) * ($pagination['limit'] ?? 20)) + 1;
    $to = min($page * ($pagination['limit'] ?? 20), $total);
    $startPage = max(1, min($page - 2, max(1, $totalPages - 4)));
    $endPage = min($totalPages, $startPage + 4);
?>

<?php $__env->startSection('content'); ?>
<style>[x-cloak]{display:none!important}</style>
<div
    class="admin-page"
    x-data="productList({
        products: <?php echo e(Js::from(collect($products)->map(fn ($p) => ['id' => $p['id']])->values())); ?>,
        csrfToken: '<?php echo e(csrf_token()); ?>',
        routes: {
            export: '<?php echo e(route('admin.products.export')); ?>',
            import: '<?php echo e(route('admin.products.import')); ?>',
            bulk: '<?php echo e(route('admin.products.bulk')); ?>',
            create: '<?php echo e(route('admin.products.create')); ?>',
        }
    })"
>
    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Products','subtitle' => number_format($total).' products · Manage your catalog']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Products','subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(number_format($total).' products · Manage your catalog')]); ?>
         <?php $__env->slot('actions', null, []); ?> 
            <input type="file" accept=".csv" class="hidden" x-ref="fileInput" @change="handleImport($event.target.files[0])" />
            <?php if (\Illuminate\Support\Facades\Blade::check('adminCan', 'products.export')): ?>
                <button type="button" @click="handleExport()"
                        class="hidden sm:inline-flex h-10 items-center gap-1.5 rounded-[6px] border border-[var(--admin-border)] bg-white px-3 text-xs font-semibold text-slate-700 hover:bg-[var(--admin-muted)]">
                    Export CSV
                </button>
            <?php endif; ?>
            <?php if (\Illuminate\Support\Facades\Blade::check('adminCan', 'products.import')): ?>
                <button type="button" @click="$refs.fileInput.click()" :disabled="importing"
                        class="hidden sm:inline-flex h-10 items-center gap-1.5 rounded-[6px] border border-[var(--admin-border)] bg-white px-3 text-xs font-semibold text-slate-700 hover:bg-[var(--admin-muted)] disabled:opacity-50">
                    <span x-text="importing ? 'Importing…' : 'Import CSV'"></span>
                </button>
            <?php endif; ?>
            <div class="relative sm:hidden" x-data="{ open: false }">
                <button type="button" @click="open = !open" @click.outside="open = false"
                        class="inline-flex h-9 w-9 items-center justify-center rounded-[6px] border border-[var(--admin-border)] bg-white text-slate-600" aria-label="More actions">
                    <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 5v.01M12 12v.01M12 19v.01"/></svg>
                </button>
                <div x-show="open" x-cloak class="absolute right-0 z-30 mt-1 w-40 overflow-hidden rounded-[8px] border border-[var(--admin-border)] bg-white py-1 shadow-panel">
                    <?php if (\Illuminate\Support\Facades\Blade::check('adminCan', 'products.export')): ?>
                        <button type="button" @click="open=false; handleExport()" class="block w-full px-3 py-2 text-left text-xs font-semibold text-slate-700 hover:bg-slate-50">Export CSV</button>
                    <?php endif; ?>
                    <?php if (\Illuminate\Support\Facades\Blade::check('adminCan', 'products.import')): ?>
                        <button type="button" @click="open=false; $refs.fileInput.click()" class="block w-full px-3 py-2 text-left text-xs font-semibold text-slate-700 hover:bg-slate-50">Import CSV</button>
                    <?php endif; ?>
                </div>
            </div>
            <?php if (\Illuminate\Support\Facades\Blade::check('adminCan', 'products.create')): ?>
                <a href="<?php echo e(route('admin.products.create')); ?>"
                   class="inline-flex h-10 items-center gap-1.5 rounded-[6px] bg-brand-green-500 px-3.5 text-sm font-medium text-white hover:bg-brand-green-600">
                    Add Product
                </a>
            <?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    
    <form method="GET" action="<?php echo e(route('admin.products.index')); ?>" id="filtersForm" class="space-y-3">
        <div class="flex flex-col gap-2 lg:flex-row lg:items-center">
            <div class="relative min-w-0 flex-1">
                <svg class="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                <input type="search" name="search" value="<?php echo e(request('search')); ?>"
                       placeholder="Search products, SKU, brand…"
                       class="w-full admin-control w-full pl-9 pr-9 text-sm"
                       @keydown.enter.prevent="$el.form.submit()" />
                <?php if(request('search')): ?>
                    <a href="<?php echo e($adminUrl([], ['search'])); ?>" class="absolute right-2.5 top-1/2 -translate-y-1/2 rounded-full p-1 text-slate-400 hover:bg-slate-100" aria-label="Clear search">
                        <svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                    </a>
                <?php endif; ?>
            </div>

            <div class="flex flex-wrap items-center gap-2">
                <select name="category" onchange="this.form.submit()" class="admin-control text-xs font-semibold">
                    <option value="">Category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->slug ?: $cat->id); ?>" <?php if(request('category') == ($cat->slug ?: $cat->id)): echo 'selected'; endif; ?>><?php echo e($cat->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <select name="brand" onchange="this.form.submit()" class="admin-control text-xs font-semibold">
                    <option value="">Brand</option>
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($b->slug ?: $b->id); ?>" <?php if(request('brand') == ($b->slug ?: $b->id)): echo 'selected'; endif; ?>><?php echo e($b->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <select name="productStatus" onchange="this.form.submit()" class="admin-control text-xs font-semibold">
                    <option value="">Status</option>
                    <option value="published" <?php if(request('productStatus') === 'published'): echo 'selected'; endif; ?>>Published</option>
                    <option value="draft" <?php if(request('productStatus') === 'draft'): echo 'selected'; endif; ?>>Draft</option>
                    <option value="hidden" <?php if(request('productStatus') === 'hidden'): echo 'selected'; endif; ?>>Hidden</option>
                    <option value="archived" <?php if(request('productStatus') === 'archived'): echo 'selected'; endif; ?>>Archived</option>
                </select>
                <select name="stock" onchange="this.form.submit()" class="hidden sm:block admin-control text-xs font-semibold">
                    <option value="">Stock</option>
                    <option value="in_stock" <?php if(request('stock') === 'in_stock'): echo 'selected'; endif; ?>>In stock</option>
                    <option value="low_stock" <?php if(request('stock') === 'low_stock'): echo 'selected'; endif; ?>>Low stock</option>
                    <option value="out_of_stock" <?php if(request('stock') === 'out_of_stock'): echo 'selected'; endif; ?>>Out of stock</option>
                    <option value="on_backorder" <?php if(request('stock') === 'on_backorder'): echo 'selected'; endif; ?>>On backorder</option>
                </select>
                <select name="sort" onchange="this.form.submit()" class="admin-control text-xs font-semibold">
                    <option value="newest" <?php if(request('sort', 'newest') === 'newest'): echo 'selected'; endif; ?>>Newest</option>
                    <option value="oldest" <?php if(request('sort') === 'oldest'): echo 'selected'; endif; ?>>Oldest</option>
                    <option value="title_asc" <?php if(request('sort') === 'title_asc'): echo 'selected'; endif; ?>>Name A–Z</option>
                    <option value="title_desc" <?php if(request('sort') === 'title_desc'): echo 'selected'; endif; ?>>Name Z–A</option>
                    <option value="price_asc" <?php if(request('sort') === 'price_asc'): echo 'selected'; endif; ?>>Price ↑</option>
                    <option value="price_desc" <?php if(request('sort') === 'price_desc'): echo 'selected'; endif; ?>>Price ↓</option>
                    <option value="stock_asc" <?php if(request('sort') === 'stock_asc'): echo 'selected'; endif; ?>>Stock ↑</option>
                    <option value="stock_desc" <?php if(request('sort') === 'stock_desc'): echo 'selected'; endif; ?>>Stock ↓</option>
                </select>

                <button type="button" @click="moreFilters = true"
                        class="inline-flex items-center gap-1.5 admin-control text-xs font-semibold hover:bg-slate-50">
                    <svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4h18M6 12h12M10 20h4"/></svg>
                    More
                </button>

            </div>
        </div>

        
        <input type="hidden" name="supplier" value="<?php echo e(request('supplier')); ?>" id="filter-supplier">
        <input type="hidden" name="vendor" value="<?php echo e(request('vendor')); ?>" id="filter-vendor">
        <input type="hidden" name="collection" value="<?php echo e(request('collection')); ?>" id="filter-collection">
        <input type="hidden" name="label" value="<?php echo e(request('label')); ?>" id="filter-label">
        <input type="hidden" name="minPrice" value="<?php echo e(request('minPrice')); ?>" id="filter-minPrice">
        <input type="hidden" name="maxPrice" value="<?php echo e(request('maxPrice')); ?>" id="filter-maxPrice">
        <input type="hidden" name="dateFrom" value="<?php echo e(request('dateFrom')); ?>" id="filter-dateFrom">
        <input type="hidden" name="dateTo" value="<?php echo e(request('dateTo')); ?>" id="filter-dateTo">
    </form>

    
    <?php if(count($chips)): ?>
        <div class="flex flex-wrap items-center gap-2">
            <span class="text-[11px] font-bold uppercase tracking-wider text-slate-400">Filters:</span>
            <?php $__currentLoopData = $chips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($adminUrl([], $chip['keys'])); ?>"
                   class="inline-flex items-center gap-1 rounded-full border border-brand-green-200 bg-brand-green-50 px-2.5 py-1 text-[11px] font-semibold text-brand-green-700 hover:bg-brand-green-100">
                    <?php echo e($chip['label']); ?> <span aria-hidden="true">×</span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('admin.products.index')); ?>" class="text-[11px] font-bold text-slate-500 hover:text-brand-orange-600 hover:underline">Clear all</a>
        </div>
    <?php endif; ?>

    
    <div x-show="selected.length > 0" x-cloak
         class="flex flex-wrap items-center gap-2 rounded-xl border border-slate-200 bg-slate-900 px-3 py-2.5 text-white shadow-sm">
        <span class="rounded-full bg-white/15 px-2.5 py-0.5 text-xs font-bold"><span x-text="selected.length"></span> selected</span>
        <button type="button" @click="executeBulk('publish')" :disabled="bulkBusy" class="rounded-lg bg-emerald-500 px-2.5 py-1 text-xs font-semibold hover:bg-emerald-400 disabled:opacity-50">Activate</button>
        <button type="button" @click="executeBulk('draft')" :disabled="bulkBusy" class="rounded-lg bg-white/10 px-2.5 py-1 text-xs font-semibold hover:bg-white/20 disabled:opacity-50">Deactivate</button>
        <button type="button" @click="executeBulk('hide')" :disabled="bulkBusy" class="rounded-lg bg-white/10 px-2.5 py-1 text-xs font-semibold hover:bg-white/20 disabled:opacity-50">Hide</button>
        <button type="button" @click="executeBulk('archive')" :disabled="bulkBusy" class="rounded-lg bg-white/10 px-2.5 py-1 text-xs font-semibold hover:bg-white/20 disabled:opacity-50">Archive</button>
        <button type="button" @click="bulkDeleteOpen = true" :disabled="bulkBusy" class="rounded-lg bg-red-500 px-2.5 py-1 text-xs font-semibold hover:bg-red-400 disabled:opacity-50">Delete</button>
        <button type="button" @click="selected = []" class="ml-auto text-xs font-medium text-white/70 hover:text-white">Clear</button>
    </div>

    
    <div class="admin-table-wrap" data-products-view="responsive">
        <?php if(count($products) > 0): ?>
            <div class="flex items-center gap-2 border-b border-[var(--admin-border)] bg-[var(--admin-muted)] px-4 py-2.5 md:hidden">
                <input type="checkbox" :checked="allSelected" @change="toggleSelectAll($event.target.checked)"
                       class="h-4 w-4 rounded border-slate-300 text-brand-green-600" aria-label="Select all">
                <span class="text-xs font-semibold text-slate-600">Select all on this page</span>
            </div>
        <?php endif; ?>

        <div class="md:hidden">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php echo $__env->make('admin.products.partials.row-card', ['product' => $product], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php if (isset($component)) { $__componentOriginal99089f8e2ef4184d7d35db81d60c6521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.empty-state','data' => ['title' => count($chips) ? 'No products found' : 'No products yet','description' => count($chips) ? 'Try changing your filters or search.' : null,'actionLabel' => count($chips) ? 'Clear filters' : 'Add Product','actionHref' => count($chips) ? route('admin.products.index') : route('admin.products.create')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(count($chips) ? 'No products found' : 'No products yet'),'description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(count($chips) ? 'Try changing your filters or search.' : null),'action-label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(count($chips) ? 'Clear filters' : 'Add Product'),'action-href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(count($chips) ? route('admin.products.index') : route('admin.products.create'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $attributes = $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $component = $__componentOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="hidden overflow-x-auto md:block">
            <table class="admin-table min-w-[720px]">
                <thead>
                    <tr>
                        <th class="w-10 !px-3">
                            <input type="checkbox" :checked="allSelected" @change="toggleSelectAll($event.target.checked)"
                                   class="h-4 w-4 rounded border-slate-300 text-brand-green-600 focus:ring-brand-green-500" aria-label="Select all">
                        </th>
                        <th class="min-w-[180px] !px-3">Product</th>
                        <th class="w-[88px] !px-2 text-right">Price</th>
                        <th class="w-[72px] !px-2 text-center">Variants</th>
                        <th class="w-16 !px-2 text-center">Stock</th>
                        <th class="w-20 !px-2">Status</th>
                        <th class="w-[76px] !px-2 text-center">Featured</th>
                        <th class="hidden w-24 !px-3 xl:table-cell">Created</th>
                        <th class="sticky right-0 z-10 w-12 !px-3 text-right"><span class="sr-only">Actions</span></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php echo $__env->make('admin.products.partials.row-table', ['product' => $product], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="!h-auto px-4 py-12">
                                <?php if (isset($component)) { $__componentOriginal99089f8e2ef4184d7d35db81d60c6521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.empty-state','data' => ['class' => 'border-0','title' => count($chips) ? 'No products found' : 'No products yet','description' => count($chips) ? 'Try changing your filters or search.' : null,'actionLabel' => count($chips) ? 'Clear filters' : 'Add Product','actionHref' => count($chips) ? route('admin.products.index') : route('admin.products.create')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'border-0','title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(count($chips) ? 'No products found' : 'No products yet'),'description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(count($chips) ? 'Try changing your filters or search.' : null),'action-label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(count($chips) ? 'Clear filters' : 'Add Product'),'action-href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(count($chips) ? route('admin.products.index') : route('admin.products.create'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $attributes = $__attributesOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__attributesOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521)): ?>
<?php $component = $__componentOriginal99089f8e2ef4184d7d35db81d60c6521; ?>
<?php unset($__componentOriginal99089f8e2ef4184d7d35db81d60c6521); ?>
<?php endif; ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>


    
    <div class="flex flex-col items-center justify-between gap-3 pt-1 sm:flex-row">
        <p class="text-xs text-slate-500">Showing <?php echo e(number_format($from)); ?>–<?php echo e(number_format($to)); ?> of <?php echo e(number_format($total)); ?></p>
        <?php if($totalPages > 1): ?>
            <div class="flex items-center gap-1">
                <a href="<?php echo e($page > 1 ? $adminUrl(['page' => $page - 1]) : '#'); ?>"
                   class="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-semibold <?php echo e($page <= 1 ? 'pointer-events-none opacity-40' : 'hover:bg-slate-50'); ?>">Previous</a>
                <div class="hidden items-center gap-1 sm:flex">
                    <?php for($p = $startPage; $p <= $endPage; $p++): ?>
                        <a href="<?php echo e($adminUrl(['page' => $p])); ?>"
                           class="flex h-8 w-8 items-center justify-center rounded-lg text-xs font-semibold <?php echo e($p == $page ? 'bg-brand-green-600 text-white' : 'border border-slate-200 bg-white hover:bg-slate-50'); ?>"><?php echo e($p); ?></a>
                    <?php endfor; ?>
                </div>
                <span class="px-2 text-xs font-semibold text-slate-600 sm:hidden"><?php echo e($page); ?>/<?php echo e($totalPages); ?></span>
                <a href="<?php echo e($page < $totalPages ? $adminUrl(['page' => $page + 1]) : '#'); ?>"
                   class="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-semibold <?php echo e($page >= $totalPages ? 'pointer-events-none opacity-40' : 'hover:bg-slate-50'); ?>">Next</a>
            </div>
        <?php endif; ?>
    </div>

    
    <div x-show="moreFilters" x-cloak class="fixed inset-0 z-[220]" role="dialog" aria-modal="true" aria-label="More filters">
        <div class="absolute inset-0 bg-slate-950/40" @click="moreFilters = false"></div>
        <div class="absolute inset-x-0 bottom-0 max-h-[85vh] overflow-y-auto rounded-t-2xl bg-white shadow-2xl sm:inset-y-0 sm:left-auto sm:right-0 sm:max-h-none sm:w-full sm:max-w-md sm:rounded-none sm:border-l sm:border-slate-200"
             x-show="moreFilters"
             x-transition:enter="transition transform duration-200 ease-out"
             x-transition:enter-start="translate-y-full sm:translate-y-0 sm:translate-x-full"
             x-transition:enter-end="translate-y-0 sm:translate-x-0"
             x-transition:leave="transition transform duration-150 ease-in"
             x-transition:leave-start="translate-y-0 sm:translate-x-0"
             x-transition:leave-end="translate-y-full sm:translate-y-0 sm:translate-x-full">
            <div class="sticky top-0 z-10 flex items-center justify-between border-b border-slate-100 bg-white px-4 py-3">
                <h2 class="text-sm font-bold text-slate-900">More filters</h2>
                <button type="button" @click="moreFilters = false" class="rounded-lg p-2 text-slate-400 hover:bg-slate-100" aria-label="Close">
                    <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
            </div>
            <div class="space-y-4 p-4" x-data="{
                supplier: <?php echo \Illuminate\Support\Js::from(request('supplier'))->toHtml() ?>,
                vendor: <?php echo \Illuminate\Support\Js::from(request('vendor'))->toHtml() ?>,
                collection: <?php echo \Illuminate\Support\Js::from(request('collection'))->toHtml() ?>,
                label: <?php echo \Illuminate\Support\Js::from(request('label'))->toHtml() ?>,
                minPrice: <?php echo \Illuminate\Support\Js::from(request('minPrice'))->toHtml() ?>,
                maxPrice: <?php echo \Illuminate\Support\Js::from(request('maxPrice'))->toHtml() ?>,
                dateFrom: <?php echo \Illuminate\Support\Js::from(request('dateFrom'))->toHtml() ?>,
                dateTo: <?php echo \Illuminate\Support\Js::from(request('dateTo'))->toHtml() ?>,
                stock: <?php echo \Illuminate\Support\Js::from(request('stock'))->toHtml() ?>,
            }">
                <div>
                    <label class="mb-1 block text-[11px] font-bold uppercase tracking-wider text-slate-400">Supplier</label>
                    <select x-model="supplier" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm">
                        <option value="">All suppliers</option>
                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s->slug ?: $s->id); ?>"><?php echo e($s->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="mb-1 block text-[11px] font-bold uppercase tracking-wider text-slate-400">Vendor</label>
                    <select x-model="vendor" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm">
                        <option value="">All vendors</option>
                        <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($v->slug ?: $v->id); ?>"><?php echo e($v->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="mb-1 block text-[11px] font-bold uppercase tracking-wider text-slate-400">Collection</label>
                    <select x-model="collection" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm">
                        <option value="">All collections</option>
                        <?php $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($col->slug ?: $col->id); ?>"><?php echo e($col->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="mb-1 block text-[11px] font-bold uppercase tracking-wider text-slate-400">Label</label>
                    <select x-model="label" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm">
                        <option value="">All labels</option>
                        <option value="featured">Featured</option>
                        <option value="trending">Trending</option>
                        <option value="flash_sale">Flash sale</option>
                        <option value="new_arrival">New arrival</option>
                        <option value="best_seller">Best seller</option>
                        <option value="hot_deal">Hot deal</option>
                    </select>
                </div>
                <div>
                    <label class="mb-1 block text-[11px] font-bold uppercase tracking-wider text-slate-400">Price range</label>
                    <div class="flex gap-2">
                        <input type="number" x-model="minPrice" placeholder="Min ৳" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm">
                        <input type="number" x-model="maxPrice" placeholder="Max ৳" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm">
                    </div>
                </div>
                <div>
                    <label class="mb-1 block text-[11px] font-bold uppercase tracking-wider text-slate-400">Created date</label>
                    <div class="flex gap-2">
                        <input type="date" x-model="dateFrom" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm">
                        <input type="date" x-model="dateTo" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm">
                    </div>
                </div>
                <div>
                    <label class="mb-1 block text-[11px] font-bold uppercase tracking-wider text-slate-400">Stock</label>
                    <select x-model="stock" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm sm:hidden">
                        <option value="">All</option>
                        <option value="in_stock">In stock</option>
                        <option value="low_stock">Low stock</option>
                        <option value="out_of_stock">Out of stock</option>
                        <option value="on_backorder">On backorder</option>
                    </select>
                    <p class="hidden text-xs text-slate-400 sm:block">Use the Stock dropdown in the toolbar.</p>
                </div>
                <div class="flex gap-2 border-t border-slate-100 pt-4">
                    <a href="<?php echo e(route('admin.products.index')); ?>" class="flex-1 rounded-[6px] border border-[var(--admin-border)] py-2.5 text-center text-xs font-bold text-slate-600">Clear</a>
                    <button type="button"
                            @click="
                                document.getElementById('filter-supplier').value = supplier || '';
                                document.getElementById('filter-vendor').value = vendor || '';
                                document.getElementById('filter-collection').value = collection || '';
                                document.getElementById('filter-label').value = label || '';
                                document.getElementById('filter-minPrice').value = minPrice || '';
                                document.getElementById('filter-maxPrice').value = maxPrice || '';
                                document.getElementById('filter-dateFrom').value = dateFrom || '';
                                document.getElementById('filter-dateTo').value = dateTo || '';
                                const stockSel = document.querySelector('#filtersForm select[name=stock]');
                                if (stockSel && stock) stockSel.value = stock;
                                else if (!stockSel && stock) {
                                    let h = document.getElementById('filter-stock-mobile');
                                    if (!h) {
                                        h = document.createElement('input');
                                        h.type = 'hidden';
                                        h.name = 'stock';
                                        h.id = 'filter-stock-mobile';
                                        document.getElementById('filtersForm').appendChild(h);
                                    }
                                    h.value = stock;
                                }
                                document.getElementById('filtersForm').submit();
                            "
                            class="flex-1 rounded-xl bg-brand-green-600 py-2.5 text-xs font-bold text-white hover:bg-brand-green-700">
                        Apply Filters
                    </button>
                </div>
            </div>
        </div>
    </div>

    
    <div x-show="deleteTarget !== null" x-cloak class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
        <div @click.outside="deleteTarget = null" class="w-full max-w-md space-y-4 rounded-2xl bg-white p-6 shadow-2xl">
            <h3 class="text-base font-bold text-slate-900">Delete product?</h3>
            <p class="text-xs text-slate-500">This will permanently delete “<span class="font-semibold text-slate-800" x-text="deleteTarget?.title"></span>”. This cannot be undone.</p>
            <div class="flex justify-end gap-2 pt-2">
                <button type="button" @click="deleteTarget = null" class="rounded-lg border border-slate-200 px-3.5 py-1.5 text-xs font-semibold text-slate-700">Cancel</button>
                <form :action="'/admin/products/' + deleteTarget?.id" method="POST">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="rounded-lg bg-red-600 px-3.5 py-1.5 text-xs font-bold text-white hover:bg-red-700">Delete</button>
                </form>
            </div>
        </div>
    </div>

    
    <div x-show="bulkDeleteOpen" x-cloak class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
        <div @click.outside="bulkDeleteOpen = false" class="w-full max-w-md space-y-4 rounded-2xl bg-white p-6 shadow-2xl">
            <h3 class="text-base font-bold text-slate-900">Delete <span x-text="selected.length"></span> product(s)?</h3>
            <p class="text-xs text-slate-500">This will permanently delete all selected products.</p>
            <div class="flex justify-end gap-2 pt-2">
                <button type="button" @click="bulkDeleteOpen = false" class="rounded-lg border border-slate-200 px-3.5 py-1.5 text-xs font-semibold">Cancel</button>
                <button type="button" @click="executeBulk('delete')" class="rounded-lg bg-red-600 px-3.5 py-1.5 text-xs font-bold text-white">Delete</button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('productList', (config) => ({
        selected: [],
        deleteTarget: null,
        bulkDeleteOpen: false,
        moreFilters: false,
        importing: false,
        bulkBusy: false,
        products: config.products,
        csrfToken: config.csrfToken,
        routes: config.routes,
        init() {
            this.$watch('moreFilters', (open) => {
                document.body.style.overflow = open ? 'hidden' : '';
            });
        },

        get allSelected() {
            return this.products.length > 0 && this.selected.length === this.products.length;
        },

        toggleSelectAll(checked) {
            this.selected = checked ? this.products.map(p => p.id) : [];
        },

        confirmDelete(id, title) {
            this.deleteTarget = { id, title };
        },

        duplicateProduct(id) {
            fetch(`/admin/products/${id}/duplicate`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': this.csrfToken, 'Accept': 'application/json' }
            }).then(r => r.json()).then(() => window.location.reload())
              .catch(() => alert('Failed to duplicate product'));
        },

        executeBulk(action) {
            if (this.selected.length === 0) return;
            this.bulkBusy = true;
            fetch(this.routes.bulk, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': this.csrfToken, 'Accept': 'application/json' },
                body: JSON.stringify({ action, ids: this.selected })
            }).then(r => r.json().then(d => ({ ok: r.ok, body: d })).catch(() => ({ ok: r.ok, body: {} })))
              .then(({ ok, body }) => {
                  if (!ok || body.success === false) throw new Error(body.message || 'Bulk action failed');
                  this.bulkDeleteOpen = false; window.location.reload();
              })
              .catch((e) => { alert(e.message || 'Bulk action failed'); this.bulkBusy = false; });
        },

        handleExport() {
            const form = document.getElementById('filtersForm');
            const params = new URLSearchParams(new FormData(form)).toString();
            window.location.href = `${this.routes.export}?${params}`;
        },

        handleImport(file) {
            if (!file) return;
            this.importing = true;
            const formData = new FormData();
            formData.append('file', file);
            formData.append('_token', this.csrfToken);
            fetch(this.routes.import, { method: 'POST', body: formData, headers: { 'Accept': 'application/json' } })
                .then(r => r.json())
                .then(res => { alert(`Successfully imported ${res.imported || 0} product(s).`); window.location.reload(); })
                .catch(() => alert('Import failed'))
                .finally(() => { this.importing = false; });
        }
    }));
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', [
    'title' => 'Products',
    'headerTitle' => 'Products',
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/admin/products/index.blade.php ENDPATH**/ ?>