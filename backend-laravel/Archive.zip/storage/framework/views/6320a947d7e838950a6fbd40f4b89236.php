<?php
    $emailTabs = [
        ['label' => 'Dashboard', 'route' => 'admin.email.dashboard', 'match' => 'admin.email.dashboard', 'perm' => 'email.view'],
        ['label' => 'SMTP Settings', 'route' => 'admin.email.settings', 'match' => 'admin.email.settings*', 'perm' => 'email.settings.manage'],
        ['label' => 'Templates', 'route' => 'admin.email.templates.index', 'match' => 'admin.email.templates.*', 'perm' => 'email.templates.manage'],
        ['label' => 'Campaigns', 'route' => 'admin.email.campaigns.index', 'match' => 'admin.email.campaigns.*', 'perm' => 'email.campaigns.manage|email.campaigns.send'],
        ['label' => 'Automation', 'route' => 'admin.email.automation', 'match' => 'admin.email.automation*', 'perm' => 'email.settings.manage'],
        ['label' => 'Logs', 'route' => 'admin.email.logs.index', 'match' => 'admin.email.logs.*', 'perm' => 'email.logs.view'],
    ];
?>
<nav class="flex gap-1 overflow-x-auto border-b border-[var(--admin-border)] text-sm" aria-label="Email management">
    <?php $__currentLoopData = $emailTabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(\App\Http\Middleware\EnsureAdminPermission::allows(auth()->user(), explode('|', $tab['perm']))): ?>
            <a href="<?php echo e(route($tab['route'])); ?>"
               class="whitespace-nowrap border-b-2 px-3 py-2 font-medium transition <?php echo e(request()->routeIs($tab['match']) ? 'border-brand-green-600 text-brand-green-700' : 'border-transparent text-slate-500 hover:text-slate-800'); ?>">
                <?php echo e($tab['label']); ?>

            </a>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</nav>

<?php if($errors->any()): ?>
    <div class="rounded-[8px] border border-red-200 bg-red-50 p-3 text-xs text-red-700 space-y-1" role="alert">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/admin/email/partials/tabs.blade.php ENDPATH**/ ?>