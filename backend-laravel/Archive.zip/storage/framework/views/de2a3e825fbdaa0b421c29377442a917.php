<?php
    $copy = [
        'review' => ['Payment received — under review', 'Your payment was received and is being reviewed by our team. We will confirm your order shortly.', 'bg-amber-100 text-amber-600'],
        'awaiting' => ['Confirming your payment…', 'We have not received confirmation from the payment gateway yet. If you completed the payment, refresh this page in a minute. Otherwise you can try again.', 'bg-sky-100 text-sky-600'],
        'closed' => ['Order closed', 'This order can no longer be paid online. Please contact us if you need help.', 'bg-slate-100 text-slate-500'],
        'unpaid' => ['Payment not completed', 'Your order is saved, but the online payment was not completed. You have not been charged for this attempt. You can try the payment again.', 'bg-red-100 text-red-600'],
    ];
    [$heading, $message, $iconClass] = $copy[$state];
?>

<?php $__env->startSection('content'); ?>
<div class="mx-auto max-w-2xl space-y-6 px-4 py-10 text-center sm:py-16" x-data x-init="$store.cart.clear()">
    <div class="mx-auto flex h-20 w-20 items-center justify-center rounded-full shadow-soft <?php echo e($iconClass); ?>">
        <?php if($state === 'unpaid' || $state === 'closed'): ?>
            <svg class="h-10 w-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/></svg>
        <?php else: ?>
            <svg class="h-10 w-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        <?php endif; ?>
    </div>

    <div class="space-y-2">
        <h1 class="text-2xl font-extrabold tracking-tight text-slate-900 sm:text-3xl"><?php echo e($heading); ?></h1>
        <p class="text-sm text-slate-600"><?php echo e($message); ?></p>
    </div>

    <?php if(session('error')): ?>
        <p role="alert" class="mx-auto max-w-md rounded-xl bg-red-50 px-4 py-3 text-sm font-semibold text-red-700"><?php echo e(session('error')); ?></p>
    <?php endif; ?>

    <div class="inline-block rounded-2xl border border-slate-200 bg-white p-4 shadow-soft">
        <span class="block text-xs font-semibold uppercase tracking-wider text-slate-500">Order Reference ID</span>
        <span class="text-xl font-black tracking-wider text-slate-800"><?php echo e($order->order_id); ?></span>
        <span class="mt-1 block text-xs text-slate-500">Amount: <strong class="text-slate-800">৳<?php echo e(number_format((float) $order->total_price, 2)); ?></strong></span>
    </div>

    <div class="flex flex-wrap items-center justify-center gap-3 pt-2">
        <?php if(in_array($state, ['unpaid', 'awaiting'], true)): ?>
            <form method="POST" action="<?php echo e(route('payment.sslcommerz.retry')); ?>" x-data="{ busy: false }" @submit="busy = true">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="orderId" value="<?php echo e($order->order_id); ?>">
                <input type="hidden" name="token" value="<?php echo e($token); ?>">
                <button type="submit" :disabled="busy" class="inline-flex min-h-[44px] items-center rounded-full bg-brand-orange-500 px-6 py-3 text-xs font-bold text-white shadow-md transition hover:bg-brand-orange-600 disabled:opacity-60">
                    <span x-text="busy ? 'Redirecting…' : 'Pay Now'">Pay Now</span>
                </button>
            </form>
        <?php endif; ?>
        <?php if($state === 'awaiting'): ?>
            <a href="<?php echo e(request()->fullUrl()); ?>" class="inline-flex min-h-[44px] items-center rounded-full border border-slate-300 px-6 py-3 text-xs font-bold text-slate-700 transition hover:bg-slate-50">Refresh Status</a>
        <?php endif; ?>
        <a href="<?php echo e(route('track', ['order_id' => $order->order_id])); ?>" class="inline-flex min-h-[44px] items-center rounded-full border border-slate-300 px-6 py-3 text-xs font-bold text-slate-700 transition hover:bg-slate-50">Track Order</a>
        <a href="<?php echo e(route('home')); ?>" class="inline-flex min-h-[44px] items-center rounded-full border border-slate-300 px-6 py-3 text-xs font-bold text-slate-700 transition hover:bg-slate-50">Continue Shopping</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/web/payment-status.blade.php ENDPATH**/ ?>