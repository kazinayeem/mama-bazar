<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'label' => null,
    'hint' => null,
    'error' => null,
    'rows' => 3,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'label' => null,
    'hint' => null,
    'error' => null,
    'rows' => 3,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="space-y-1.5">
    <?php if($label): ?>
        <label class="block text-xs font-semibold text-slate-700"><?php echo e($label); ?></label>
    <?php endif; ?>
    <textarea
        rows="<?php echo e($rows); ?>"
        <?php echo e($attributes->merge([
            'class' => 'w-full rounded-[6px] border border-[var(--admin-border)] bg-white px-3 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-brand-green-500 focus:outline-none focus:ring-[3px] focus:ring-[var(--admin-ring)] disabled:bg-slate-50 disabled:text-slate-400'.($error ? ' border-red-300' : '')
        ])); ?>

    ><?php echo e($slot); ?></textarea>
    <?php if($error): ?>
        <p class="text-[11px] font-medium text-red-600"><?php echo e($error); ?></p>
    <?php elseif($hint): ?>
        <p class="text-[11px] text-slate-400"><?php echo e($hint); ?></p>
    <?php endif; ?>
</div>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/components/admin/textarea.blade.php ENDPATH**/ ?>