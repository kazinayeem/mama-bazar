<?php
    /** @var array $homepageData */
    /** @var array $config */
    $sections = $homepageData['sections'] ?? [];
    $promoCounter = 0;
?>

<?php if(empty($sections)): ?>
    <div class="mx-auto max-w-7xl px-4 py-20 text-center">
        <h2 class="text-lg font-extrabold text-slate-900">Homepage not configured</h2>
        <p class="mt-2 text-sm text-slate-500">Open the Homepage Builder in admin and publish a layout.</p>
    </div>
<?php else: ?>
    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(($section['enabled'] ?? true) === false): ?>
            <?php continue; ?>
        <?php endif; ?>

        <?php
            $type = $section['type'] ?? '';
            $data = $section['data'] ?? [];
            $items = $data['items'] ?? [];
            if ($items instanceof \Illuminate\Support\Collection) {
                $items = $items->all();
            }

            $skip = false;
            $emptySkip = in_array($type, [
                'categories', 'category_products', 'featured', 'best_sellers', 'trending', 'new_arrivals',
                'limited_edition', 'official', 'hot_deals', 'emi_available', 'recommendations',
                'brands', 'collections', 'reviews', 'flash_deals', 'promo_banner',
            ], true);

            if ($emptySkip && empty($items)) {
                $skip = true;
            }

            if ($type === 'hero') {
                // Hero section always renders (carousel and/or popular searches) when enabled.
                $skip = false;
            }

            if ($type === 'trust_strip') {
                $items = !empty($items) ? $items : ($homepageData['trustStrip'] ?? $config['trustStrip'] ?? []);
                if (empty($items)) $skip = true;
            }

            if ($type === 'why_choose_us') {
                $items = !empty($items) ? $items : ($homepageData['whyChooseUs'] ?? $config['whyChooseUs'] ?? []);
                if (empty($items)) $skip = true;
            }

            if ($type === 'newsletter') {
                $newsletter = $data['settings'] ?? ($homepageData['newsletter'] ?? $config['newsletter'] ?? []);
                if (empty($newsletter['enabled'])) $skip = true;
            }

            $currentPromoIndex = 0;
            if (!$skip && $type === 'promo_banner') {
                $currentPromoIndex = $promoCounter++;
            }
        ?>

        <?php if(!$skip): ?>
            <?php echo $__env->make('web.homepage.section', [
                'section' => $section,
                'type' => $type,
                'data' => $data,
                'items' => $items ?? [],
                'homepageData' => $homepageData,
                'config' => $config,
                'promoIndex' => $currentPromoIndex,
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php if($loop->iteration === 3): ?>
                <?php if (isset($component)) { $__componentOriginalfd35d9949ff2a88881dd7e86b1c1a1ce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfd35d9949ff2a88881dd7e86b1c1a1ce = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ads.native-banner','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ads.native-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfd35d9949ff2a88881dd7e86b1c1a1ce)): ?>
<?php $attributes = $__attributesOriginalfd35d9949ff2a88881dd7e86b1c1a1ce; ?>
<?php unset($__attributesOriginalfd35d9949ff2a88881dd7e86b1c1a1ce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfd35d9949ff2a88881dd7e86b1c1a1ce)): ?>
<?php $component = $__componentOriginalfd35d9949ff2a88881dd7e86b1c1a1ce; ?>
<?php unset($__componentOriginalfd35d9949ff2a88881dd7e86b1c1a1ce); ?>
<?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/web/homepage/sections.blade.php ENDPATH**/ ?>