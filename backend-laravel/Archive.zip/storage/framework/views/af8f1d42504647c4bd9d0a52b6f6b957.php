<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['section']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['section']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $bg = match ($section['background'] ?? 'default') {
        'muted' => 'bg-brand-green-50/70',
        'dark' => 'bg-slate-100',
        default => 'bg-white',
    };
    $title = trim($section['title'] ?? '');
    $subtitle = trim($section['subtitle'] ?? '');
    $eyebrow = trim($section['eyebrow'] ?? '');
    $ctaText = trim($section['ctaText'] ?? '');
    $ctaUrl = trim($section['ctaUrl'] ?? '');
    $showHeader = $title || $subtitle || $eyebrow;
?>

<section <?php echo e($attributes->merge(['class' => "store-section {$bg}"])); ?>>
    <div class="store-container">
        <?php if($showHeader): ?>
            <div class="store-section-header mb-5 flex flex-col gap-3 sm:mb-6 sm:flex-row sm:items-end sm:justify-between sm:gap-4">
                <div class="min-w-0">
                    <?php if($eyebrow): ?>
                        <span class="mb-2 inline-flex items-center rounded-full border border-brand-orange-200 bg-brand-orange-50 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-[0.16em] text-brand-orange-600"><?php echo e($eyebrow); ?></span>
                    <?php endif; ?>
                    <?php if($title): ?>
                        <h2 class="text-xl font-extrabold tracking-tight text-slate-900 sm:text-2xl lg:text-[28px] lg:leading-tight"><?php echo e($title); ?></h2>
                    <?php endif; ?>
                    <?php if($subtitle): ?>
                        <p class="mt-1 max-w-2xl text-sm leading-6 text-slate-500"><?php echo e($subtitle); ?></p>
                    <?php endif; ?>
                </div>
                <?php if($ctaText && $ctaUrl): ?>
                    <a href="<?php echo e($ctaUrl); ?>" class="store-btn store-btn-ghost hidden shrink-0 sm:inline-flex">
                        <?php echo e($ctaText); ?>

                        <svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php echo e($slot); ?>


        <?php if($ctaText && $ctaUrl): ?>
            <div class="mt-5 text-center sm:hidden">
                <a href="<?php echo e($ctaUrl); ?>" class="store-btn store-btn-primary inline-flex">
                    <?php echo e($ctaText); ?>

                    <svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                </a>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/mama-bazar/backend-laravel/resources/views/components/homepage/section-shell.blade.php ENDPATH**/ ?>